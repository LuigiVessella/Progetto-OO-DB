package entity;

public class Nazionale {
	private String nome;
	private double gettone;
	


	public Nazionale() {};
	
	public Nazionale(String nome, double gettone) {
		super();
		this.nome = nome;
		this.gettone = gettone;
		
	}

	public boolean setNazionale(String nome, double gettone)
	{
		this.nome = nome.toUpperCase();
		this.gettone = gettone;
		return true;		
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getGettone() {
		return gettone;
	}

	public void setGettone(double gettone) {
		this.gettone = gettone;
	}
	
}
