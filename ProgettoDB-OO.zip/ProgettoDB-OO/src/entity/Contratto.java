package entity;

import java.util.Date;

public class Contratto {

	private Date inizioContratto;
	private Date fineContratto;
	private double compenso;
	private double percentualeProcuratore;
	private int codiceContratto; 
	
	private Club club = null;
	private Sponsor sponsor = null;
	private Atleta atleta;
	
	public boolean setContrattoClub(Date inizioContratto, Date fineContratto, double compenso,
			double percentualeProcuratore, Atleta atl, Club club) {
		

		this.inizioContratto = inizioContratto;
		this.fineContratto = fineContratto;
		this.compenso = compenso;
		this.percentualeProcuratore = percentualeProcuratore;
		this.atleta = atl;
		this.club = club;
		
		return true;
	}
	
	public boolean setContrattoSponsor(Date inizioContratto, Date fineContratto, double compenso,
			double percentualeProcuratore, Atleta atl, Sponsor sponsor) {

		this.inizioContratto = inizioContratto;
		this.fineContratto = fineContratto;
		this.compenso = compenso;
		this.percentualeProcuratore = percentualeProcuratore;
		this.atleta = atl;
		this.sponsor = sponsor;
		
		return true;
	}


	
	public int getCodiceContratto() {
		return codiceContratto;
	}

	public void setCodiceContratto(int codiceContratto) {
		this.codiceContratto = codiceContratto;
	}

	public Date getInizioContratto() {
		return inizioContratto;
	}

	public void setInizioContratto(Date inizioContratto) {
		this.inizioContratto = inizioContratto;
	}

	public Date getFineContratto() {
		return fineContratto;
	}

	public void setFineContratto(Date fineContratto) {
		this.fineContratto = fineContratto;
	}

	public double getCompenso() {
		return compenso;
	}

	public void setCompenso(double compenso) {
		this.compenso = compenso;
	}

	public double getPercentualeProcuratore() {
		return percentualeProcuratore;
	}

	public void setPercentualeProcuratore(double percentualeProcuratore) {
		this.percentualeProcuratore = percentualeProcuratore;
	}

	public Club getClub() {
		return club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	public Sponsor getSponsor() {
		return sponsor;
	}

	public void setSponsor(Sponsor sponsor) {
		this.sponsor = sponsor;
	}

	public Atleta getAtleta() {
		return atleta;
	}

	public void setAtleta(Atleta atleta) {
		this.atleta = atleta;
	}


}
