package entity;




import java.io.IOException;

import java.util.Date;


public class Persona {
	private String codiceFiscale;
	private String nome;
	private String cognome; 
	private Date dataDiNascita;
	private String cittaDiNascita;
	private String domicilio;
	private String email;
	private String nazionalita;
	private String sesso;
	
	public Persona() {}
	
	public boolean setPersona(String codiceFiscale,String nome, String cognome, Date dataDiNascita, String cittDiNascita,
			String domicilio, String email, String nazionalita, String sesso) throws IOException
	{
		
		this.codiceFiscale = codiceFiscale.toUpperCase();
		this.nome = nome.toUpperCase();
		this.cognome = cognome.toUpperCase();
		this.dataDiNascita = dataDiNascita;
		this.cittaDiNascita = cittDiNascita.toUpperCase();
		this.domicilio = domicilio.toUpperCase();
		this.email = email.toLowerCase();
		this.nazionalita = nazionalita;
		this.sesso = sesso;
			
		return true;

	}
	
	
	
	public String getSesso() {
		return sesso;
	}



	public void setSesso(String sesso) {
		this.sesso = sesso;
	}


	public String getNazionalita() {
		return nazionalita;
	}


	public void setNazionalita(String nazionalita) {
		this.nazionalita = nazionalita;
	}


	public String getCittaDiNascita() {
		return cittaDiNascita;
	}



	


	public String getCodiceFiscale() {
		return codiceFiscale;
	}

	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public Date getDataDiNascita() {
		return dataDiNascita;
	}

	public void setDataDiNascita(Date dataDiNascita) {
		this.dataDiNascita = dataDiNascita;
	}



	public void setCittaDiNascita(String cittaDiNascita) {
		this.cittaDiNascita = cittaDiNascita;
	}

	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	

}
