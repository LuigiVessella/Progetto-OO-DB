package entity;

import java.util.ArrayList;

public class Atleta extends Persona{
	
	private double totaleGuadagni = 0;
	private String descrizioneCarriera;
	private String ruolo;
	private int partiteGiocateNazionale;
	private Procuratore procuratore;
	private ArrayList<Contratto> contratti;
	
	public Atleta() {	
	}
	

	public ArrayList<Contratto> getContratti() {
		return contratti;
	}


	public void setContratti(ArrayList<Contratto> contratti) {
		this.contratti = contratti;
	}


	public Procuratore getProcuratore() {
		return procuratore;
	}



	public void setProcuratore(Procuratore procuratore) {
		this.procuratore = procuratore;
	}



	public double getTotaleGuadagni() {
		return totaleGuadagni;
	}

	public void setTotaleGuadagni(double totaleGuadagni) {
		this.totaleGuadagni = totaleGuadagni;
	}

	public String getDescrizioneCarriera() {
		return descrizioneCarriera;
	}

	public void setDescrizioneCarriera(String descrizioneCarriera) {
		this.descrizioneCarriera = descrizioneCarriera;
	}

	public String getRuolo() {
		return ruolo;
	}

	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}

	public int getPartiteGiocateNazionale() {
		return partiteGiocateNazionale;
	}

	public void setPartiteGiocateNazionale(int partiteGiocateNazionale) {
		this.partiteGiocateNazionale = partiteGiocateNazionale;
	}


}
 