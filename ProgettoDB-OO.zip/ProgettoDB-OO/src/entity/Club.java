package entity;

import java.util.ArrayList;
import java.util.Date;

public class Club {
	
	private String nome = "";
	private String presidente;
	private Date fondazione;
	private String citta;
	private String nazionale;
	private ArrayList<Contratto> contrattiClub;
	public Club() {}
	
	//IL CODICE LO METTE IL DB IN AUTOMATICO (AUTOINCREMENT)
	
	public boolean setClub(String nome, String presidente, Date fondazione, String citta, String nazionale) {
		
		this.nome = nome.toUpperCase();
		this.presidente = presidente.toUpperCase();
		this.fondazione = fondazione;
		this.citta = citta.toUpperCase();
		this.nazionale = nazionale.toUpperCase();
		return true;
	}
	
	public String getPresidente() {
		return presidente;
	}

	public void setPresidente(String presidente) {
		this.presidente = presidente;
	}

	public Date getFondazione() {
		return fondazione;
	}

	public void setFondazione(Date fondazione) {
		this.fondazione = fondazione;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCitta() {
		
		return citta;
	}

	public String getNazionale() {
		// TODO Auto-generated method stub
		return nazionale;
	}

	public void setNazionale(String string) {
		this.nazionale = string;
		
	}


	public void setCitta(String citta) {
		this.citta = citta;
	}
	
	
}
