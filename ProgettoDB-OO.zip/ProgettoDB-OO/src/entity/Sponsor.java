package entity;

import java.util.ArrayList;

public class Sponsor {

	private String nome = "";
	private String nazionale;
	private ArrayList<Contratto> contrattiSponsor;
	

	public Sponsor() {}

	public boolean setSponsor(String nome,String nazionale) {

		this.nome = nome.toUpperCase();
		this.nazionale= nazionale;
		return true;
		
	}	
	


	public String getNazionale() {
		return nazionale;
	}

	public void setNazionale(String nazionale) {
		this.nazionale = nazionale;
	}

	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


}
