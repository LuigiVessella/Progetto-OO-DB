package entity;

import java.util.ArrayList;

public class Procuratore extends Persona{
	
	
	private double totaleGuadagni = 0;
	private double percentualeGettone;
	private ArrayList<Atleta> atleti;
	
	public Procuratore() {};
	
	public boolean setProcuratore(String codiceFiscale, double percentualeGettone) {
		this.setCodiceFiscale(codiceFiscale);
		this.percentualeGettone=percentualeGettone;
		return true;
	}
		

	
	public ArrayList<Atleta> getAtleti() {
		return atleti;
	}

	public void setAtleti(ArrayList<Atleta> atleti) {
		this.atleti = atleti;
	}

	public double getTotaleGuadagni() {
		return totaleGuadagni;
	}

	public void setTotaleGuadagni(double totaleGuadagni) {
		this.totaleGuadagni = totaleGuadagni;
	}

	public double getPercentualeGettone() {
		return percentualeGettone;
	}

	public void setPercentualeGettone(double percentualeGettone) {
		this.percentualeGettone = percentualeGettone;
	}

	

}
