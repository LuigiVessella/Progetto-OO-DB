package controller;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import entity.*;

import javax.swing.JFrame;

import gui.*;
import dbconfig.DBConnection;
import daos.*;
import postegresImpl.*;
public class Controller {

	//ATTRIBUTI 
	private DBConnection dbconn = null;
    private Connection connection = null;
    
    //DAOS
    private PersonaDAO ricercaPersona;
    private ProcuratoreDAO ricercaProcuratore;
    private AtletaDAO ricercaAtleta;
    private NazionaleDAO ricercaNazionale;
    private ClubDAO ricercaClub;
    private SponsorDAO ricercaSponsor;
    private ContrattoDAO ricercaContratto;
    
    //ENTITY
    private ArrayList<Procuratore> procuratori;
    private ArrayList<Nazionale> nazionali;
    private ArrayList<String> nomiClubs;
    private ArrayList<String> nomiSponsors;
    private ArrayList<Club> clubs;
    private ArrayList<Atleta> atleti;
    private ArrayList<Sponsor> sponsors;
    private ArrayList<Contratto> contratti;
    
	//GUI
    private FrameAtleta frameAtleta;
    private FrameClub frameClub;
    private FrameNazionale frameNazionale;
    private FrameProcuratore frameProcuratore;
    private FrameSponsor frameSponsor;
    private FrameContratto frameContratto;
    private FrameStatisticheProcuratore frameStatisticheProcuratore;
    private InserisciAtletaFrame inserisciAtletaFrame;
    private InserisciClubFrame inserisciClubFrame;
    private InserisciContrattoClubFrame inserisciContrattoClubFrame;
    private InserisciContrattoSponsorFrame inserisciContrattoSponsorFrame;
    private InserisciNazionaleFrame inserisciNazionaleFrame;
    private InserisciProcuratoreFrame inserisciProcuratoreFrame;
    private InserisciSponsorFrame inserisciSponsorFrame;
    
    
    
    
    public static void main(String[] args)
	{
		Controller mainController = new Controller();

	}
	
	//COSTRUTTORE
	public Controller()
	{
		try {
			dbconn = DBConnection.getInstance();
			connection = dbconn.getConnection();
			
			creaFrameprocuratore(null, null);

			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	

	private void creaFrameprocuratore(String vincoloNazione, String vincoloOrdine)
	{
		nazionali = new ArrayList<Nazionale>();
		procuratori = new ArrayList<Procuratore>();
		try {
			//PRENDI NAZIONALI DAL DATABASE
			
			
			ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
			nazionali = ricercaNazionale.getNomeNazionale();
			ricercaProcuratore = new ProcuratoreDAOPostgresImpl(connection);
			procuratori = ricercaProcuratore.getAllProcuratore();
			
			if(vincoloNazione != null)
				procuratori = ricercaProcuratore.getProcuratoreNazione(procuratori,vincoloNazione);
			FrameProcuratore frameProcuratore= new FrameProcuratore(this, vincoloNazione, vincoloOrdine, procuratori, nazionali);
			frameProcuratore.setVisible(true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	@SuppressWarnings("deprecation")
	public void toFrameAtleta(JFrame f1, String vincoloNazione, String vincoloOrdine, Procuratore proc)
	{
		
		Comparator<Atleta> orderAtleta;
		nazionali = new ArrayList<Nazionale>();
		atleti = new ArrayList<Atleta>();
		try {
			//PRENDI NAZIONALI DAL DATABASE
			f1.disable();
			
			ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
			nazionali = ricercaNazionale.getNomeNazionale();
			ricercaAtleta = new AtletaDAOPostgresImpl(connection);
			atleti = ricercaAtleta.getAllAtleti();
			
			if(proc != null)
			{
				proc.setAtleti(ricercaAtleta.getAtletiProcuratore(proc));
				atleti=proc.getAtleti();
			}
				
	
			if(vincoloOrdine != null) {
				switch(vincoloOrdine)
				{
				case("nome_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl1.getNome().compareTo(atl2.getNome());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
				
				case("nome_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl2.getNome().compareTo(atl1.getNome());
						}
					};
					Collections.sort(atleti, orderAtleta);	
					break;
					
				case("cognome_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl1.getCognome().compareTo(atl2.getCognome());
						}
					};
					Collections.sort(atleti, orderAtleta);	
					break;
				
				case("cognome_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl2.getCognome().compareTo(atl1.getCognome());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("cf_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl1.getCodiceFiscale().compareTo(atl2.getCodiceFiscale());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("cf_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl2.getCodiceFiscale().compareTo(atl1.getCodiceFiscale());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("nascita_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl1.getDataDiNascita().compareTo(atl2.getDataDiNascita());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
				case("nascita_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl2.getDataDiNascita().compareTo(atl1.getDataDiNascita());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
				case("citta_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl1.getCittaDiNascita().compareTo(atl2.getCittaDiNascita());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
				case("citta_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl2.getCittaDiNascita().compareTo(atl1.getCittaDiNascita());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("nazionalita_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl1.getNazionalita().compareTo(atl2.getNazionalita());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("nazionalita_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl2.getNazionalita().compareTo(atl1.getNazionalita());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("email_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl1.getEmail().compareTo(atl2.getEmail());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("email_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl2.getEmail().compareTo(atl1.getEmail());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("ruolo_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl1.getRuolo().compareTo(atl2.getRuolo());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("ruolo_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return atl2.getRuolo().compareTo(atl1.getRuolo());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
				
				case("guadagno_crescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return  Double.compare(atl1.getTotaleGuadagni(), atl2.getTotaleGuadagni());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
					
				case("guadagno_decrescente"):
					orderAtleta = new Comparator<Atleta>(){
					public int compare(Atleta atl1, Atleta atl2) {
						return Double.compare(atl2.getTotaleGuadagni(), atl1.getTotaleGuadagni());
						}
					};
					Collections.sort(atleti, orderAtleta);
					break;
				
				}
			}
				
			if(vincoloNazione != null)
				atleti = ricercaAtleta.getAtletiNazione(atleti, vincoloNazione);
			
			FrameAtleta frameAtleta = new FrameAtleta(this, vincoloNazione, vincoloOrdine, atleti, nazionali, proc,ricercaAtleta);
			f1.setVisible(false);
			frameAtleta.setVisible(true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void toFrameProcuratore(JFrame f1,String vincoloNazione,String vincoloOrdine)
	{
		Comparator<Procuratore> orderProcuratore;
		nazionali = new ArrayList<Nazionale>();
		procuratori= new ArrayList<Procuratore>();
		try {
			//PRENDI NAZIONALI DAL DATABASE
			f1.disable();
			
			ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
			nazionali = ricercaNazionale.getNomeNazionale();
			ricercaProcuratore = new ProcuratoreDAOPostgresImpl(connection);
			procuratori = ricercaProcuratore.getAllProcuratore();
		
			if(vincoloOrdine != null)
			{
				
				switch(vincoloOrdine)
				{

				case("nome_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc1.getNome().compareTo(proc2.getNome());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
				
				case("nome_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc2.getNome().compareTo(proc1.getNome());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("cognome_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc1.getCognome().compareTo(proc2.getCognome());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
				
				case("cognome_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc2.getCognome().compareTo(proc1.getCognome());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("cf_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc1.getCodiceFiscale().compareTo(proc2.getCodiceFiscale());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
				case("cf_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc2.getCodiceFiscale().compareTo(proc1.getCodiceFiscale());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
				case("nascita_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc1.getDataDiNascita().compareTo(proc2.getDataDiNascita());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
				case("nascita_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc2.getDataDiNascita().compareTo(proc1.getDataDiNascita());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
				case("citta_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc1.getCittaDiNascita().compareTo(proc2.getCittaDiNascita());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
				case("citta_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc2.getCittaDiNascita().compareTo(proc1.getCittaDiNascita());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("nazionalita_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc1.getNazionalita().compareTo(proc2.getNazionalita());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("nazionalita_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc2.getNazionalita().compareTo(proc1.getNazionalita());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("email_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc1.getEmail().compareTo(proc2.getEmail());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("email_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return proc2.getEmail().compareTo(proc1.getEmail());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("gettone_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return Double.compare(proc1.getPercentualeGettone(), proc2.getPercentualeGettone());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("gettone_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return Double.compare(proc2.getPercentualeGettone(), proc1.getPercentualeGettone());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
				
				case("guadagno_crescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return Double.compare(proc1.getTotaleGuadagni(), proc2.getTotaleGuadagni());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;
					
				case("guadagno_decrescente"):
					orderProcuratore = new Comparator<Procuratore>(){
					public int compare(Procuratore proc1, Procuratore proc2) {
						return Double.compare(proc2.getTotaleGuadagni(), proc1.getTotaleGuadagni());
						}
					};
					Collections.sort(procuratori, orderProcuratore);
					break;

				
				}
			}
			if(vincoloNazione != null)
				procuratori = ricercaProcuratore.getProcuratoreNazione(procuratori, vincoloNazione);
			
			
			FrameProcuratore frameProcuratore= new FrameProcuratore(this,vincoloNazione, vincoloOrdine, procuratori,nazionali);
			f1.setVisible(false);
			frameProcuratore.setVisible(true);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public Connection controllerGetConnection()
	{
		return this.connection;
	}

	public void toInserisciNazionaleFrame(JFrame f1) {
		f1.setVisible(false);
		InserisciNazionaleFrame inserisciNazionaleFrame = new InserisciNazionaleFrame(this);
		inserisciNazionaleFrame.setVisible(true);
	}
	
	public void toInserisciSponsorFrame(JFrame f1) throws SQLException {
		f1.setVisible(false);
		ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
		InserisciSponsorFrame inserisciSponsorFrame = new InserisciSponsorFrame(this,ricercaNazionale);
		inserisciSponsorFrame.setVisible(true);

	}

	public void toInserisciProcuratoreFrame(JFrame f1) throws SQLException {
		f1.setVisible(false);
		ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
		ricercaPersona = new PersonaDAOPostgresImpl(connection);
		InserisciProcuratoreFrame inserisciProcuratoreFrame = new InserisciProcuratoreFrame(this,ricercaNazionale,ricercaPersona);
		inserisciProcuratoreFrame.setVisible(true);		
	}

	public void toInserisciClubFrame(JFrame f1) throws SQLException {
		f1.setVisible(false);
		ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
		InserisciClubFrame inserisciClubFrame = new InserisciClubFrame(this,ricercaNazionale);
		inserisciClubFrame.setVisible(true);
		
	}

	public void toInserisciAtletaFrame(JFrame f1, Procuratore p) throws SQLException {
		f1.setVisible(false);
		ricercaPersona = new PersonaDAOPostgresImpl(connection);
		ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
		InserisciAtletaFrame inserisciAtletaFrame = new InserisciAtletaFrame(this, p,ricercaNazionale,ricercaPersona);
		inserisciAtletaFrame.setVisible(true);
	}

	public void toFrameClub(JFrame f1,String vincoloNazione,String vincoloOrdine) {
		
		nazionali = new ArrayList<Nazionale>();
		clubs = new ArrayList<Club>();
		try {
			//PRENDI NAZIONALI DAL DATABASE
			f1.disable();
			
			ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
			nazionali = ricercaNazionale.getNomeNazionale();
			ricercaClub = new ClubDAOPostgresImpl(connection);
			clubs = ricercaClub.getAllClubs();
			if(vincoloOrdine != null) {
				switch(vincoloOrdine) {
				
				case("nome_crescente"):
					clubs = ricercaClub.getClubsNome("asc");
					break;
				case("nome_decrescente"):
					clubs = ricercaClub.getClubsNome("desc");
					break;
					
				case("presidente_crescente"):
					clubs = ricercaClub.getClubsPresidente("asc");
					break;
				case("presidente_decrescente"):
					clubs = ricercaClub.getClubsPresidente("desc");
					break;
					
				case("fondazione_crescente"):
					clubs = ricercaClub.getClubsFondazione("asc");
					break;
				case("fondazione_decrescente"):
					clubs = ricercaClub.getClubsFondazione("desc");
					break;
					
				case("nazione_crescente"):
					clubs = ricercaClub.getClubsNazione("asc");
					break;
				case("nazione_decrescente"):
					clubs = ricercaClub.getClubsNazione("desc");
					break;
				}
			}
			
			if(vincoloNazione != null)
			{
				clubs = ricercaClub.getClubNazione(clubs, vincoloNazione);
			}

			FrameClub frameClub = new FrameClub(this, vincoloNazione, vincoloOrdine,  clubs,nazionali);
			f1.setVisible(false);
			frameClub.setVisible(true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public void toFrameSponsor(JFrame f1, String vincoloNazione, String vincoloOrdine) {
		
		
		
		nazionali = new ArrayList<Nazionale>();
		sponsors = new ArrayList<Sponsor>();
		try {
			//PRENDI NAZIONALI DAL DATABASE
			f1.disable();
			
			ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
			nazionali = ricercaNazionale.getNomeNazionale();
			ricercaSponsor = new SponsorDAOPostgresImpl(connection);
			sponsors = ricercaSponsor.getAllSponsors();
			
			if(vincoloOrdine != null) {
				switch(vincoloOrdine) {
				case("nome_crescente"):
					sponsors = ricercaSponsor.getSponsorsNome("asc");
					break;
				case("nome_decrescente"):
					sponsors = ricercaSponsor.getSponsorsNome("desc");
					break;
				case("nazione_crescente"):
					sponsors = ricercaSponsor.getSponsorsNazione("asc");
					break;
				case("nazione_decrescente"):
					sponsors = ricercaSponsor.getSponsorsNazione("desc");
					break ;
				}
				
			}
			if(vincoloNazione != null)
			{
				sponsors = ricercaSponsor.getSponsorNazione(sponsors, vincoloNazione);
			}
			
			FrameSponsor frameSponsor = new FrameSponsor(this, vincoloNazione, vincoloOrdine,  sponsors,nazionali);
			f1.setVisible(false);
			frameSponsor.setVisible(true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public void toFrameContratto(JFrame f1, String vincoloOrdine, String vincoloClub,
			String vincoloSponsor, Atleta atl) {
		Comparator<Contratto> orderContratto;
		contratti = new ArrayList<Contratto>();
		sponsors = new ArrayList<Sponsor>();
		clubs = new ArrayList<Club>();
		
		try {
			//PRENDI CLUBS DAL DATABASE
			f1.disable();
			
			ricercaClub = new ClubDAOPostgresImpl(connection);
		
		
			ricercaSponsor = new SponsorDAOPostgresImpl(connection);
			ricercaContratto = new ContrattoDAOPostgresImpl(connection);
			sponsors = ricercaSponsor.getAllSponsors();
			clubs = ricercaClub.getAllClubs(); 
			contratti = ricercaContratto.getAllContrattiClub();	
			contratti.addAll(ricercaContratto.getAllContrattiSponsor());
			
		
			if(atl != null)
			{
				
				contratti = atl.getContratti();
			}
			if(vincoloClub!= null)
			{
				contratti = ricercaContratto.getContrattiClub(contratti,vincoloClub);
			}
			else if(vincoloSponsor!= null)
			{
				contratti = ricercaContratto.getContrattiSponsor(contratti,vincoloSponsor);
			}
			
			if(vincoloOrdine != null) {
				switch(vincoloOrdine) {
			
				case("codice_crescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return Integer.compare(contr1.getCodiceContratto(), contr2.getCodiceContratto());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				case("codice_decrescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return Integer.compare(contr2.getCodiceContratto(), contr1.getCodiceContratto());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				case("inizio_crescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return contr1.getInizioContratto().compareTo(contr2.getInizioContratto());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				case("inizio_decrescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return contr2.getInizioContratto().compareTo(contr1.getInizioContratto());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				
				case("fine_crescente"): 
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return contr1.getFineContratto().compareTo(contr2.getFineContratto());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				case("fine_decrescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return contr2.getFineContratto().compareTo(contr1.getFineContratto());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				
				case("compenso_crescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return Double.compare(contr1.getCompenso(), contr2.getCompenso());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				case("compenso_decrescente"): 
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return Double.compare(contr2.getCompenso(), contr1.getCompenso());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				
				case("percentuale_crescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return Double.compare(contr1.getPercentualeProcuratore(), contr2.getPercentualeProcuratore());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				case("percentuale_decrescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return Double.compare(contr2.getPercentualeProcuratore(), contr1.getPercentualeProcuratore());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				
				case("nome_atleta_crescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return contr1.getAtleta().getNome().compareTo(contr2.getAtleta().getNome());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
					
				case("nome_atleta_decrescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						return contr2.getAtleta().getNome().compareTo(contr1.getAtleta().getNome());
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				
				case("nome_club_crescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						if(contr1.getClub() != null && contr2.getClub() != null ) return contr1.getClub().getNome().compareTo(contr2.getClub().getNome());
						else return 0;
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
					
				case("nome_club_decrescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						if(contr1.getClub() != null && contr2.getClub() != null ) return contr2.getClub().getNome().compareTo(contr1.getClub().getNome());
						else return 0;
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				
				case("nome_sponsor_crescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						if(contr1.getSponsor() != null && contr2.getSponsor() != null ) return contr1.getSponsor().getNome().compareTo(contr2.getSponsor().getNome());
						else return 0;
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
					
				case("nome_sponsor_decrescente"):
					orderContratto = new Comparator<Contratto>(){
					public int compare(Contratto contr1, Contratto contr2) {
						if(contr1.getSponsor() != null && contr2.getSponsor() != null ) return contr2.getSponsor().getNome().compareTo(contr1.getSponsor().getNome());
						else return 0;
						}
					};
					Collections.sort(contratti, orderContratto); 
					break;
				
				}
			}
				
			
			FrameContratto frameContratto = new FrameContratto(this, vincoloOrdine, vincoloClub, vincoloSponsor, contratti, atl, sponsors, clubs);
			f1.setVisible(false);
			frameContratto.setVisible(true);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public void toInserisciContrattoClubFrame(JFrame f1, Atleta atl) {
		f1.disable();
		try {
			ricercaClub = new ClubDAOPostgresImpl(connection);
			clubs = ricercaClub.getAllClubs();
			InserisciContrattoClubFrame inserisciContrattoClubFrame = new InserisciContrattoClubFrame(this, clubs, atl);
			f1.setVisible(false);
			inserisciContrattoClubFrame.setVisible(true);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
		
		public void toInserisciContrattoSponsorFrame(JFrame f1, Atleta atl) {
			f1.disable();
			try {
				ricercaSponsor = new SponsorDAOPostgresImpl(connection);
				sponsors = ricercaSponsor.getAllSponsors();
				InserisciContrattoSponsorFrame inserisciContrattoSponsorFrame = new InserisciContrattoSponsorFrame(this, sponsors, atl);
				f1.setVisible(false);
				inserisciContrattoSponsorFrame.setVisible(true);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
		
	}

		public void toEliminaProcuratore(JFrame f1,Procuratore proc) {
			try {
				f1.disable();
				ricercaProcuratore= new ProcuratoreDAOPostgresImpl(connection);
				ricercaProcuratore.eliminaProcuratore(proc);
				toFrameProcuratore(f1, null,null);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}

		public void toEliminaAtleta(FrameAtleta f1, Atleta atl) {
			try {
				f1.disable();
				ricercaAtleta= new AtletaDAOPostgresImpl(connection);
				ricercaAtleta.eliminaAtleta(atl);
				toFrameAtleta(f1, null, null, null);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}

		public void toEliminaClub(FrameClub f1, Club club) {
			try {
				f1.disable();
				ricercaClub= new ClubDAOPostgresImpl(connection);
				ricercaClub.eliminaClub(club);
				toFrameClub(f1, null, null);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}

		public void toEliminaSponsor(FrameSponsor f1, Sponsor sponsor) {
			try {
				f1.disable();
				ricercaSponsor= new SponsorDAOPostgresImpl(connection);
				ricercaSponsor.eliminaSponsor(sponsor);
				toFrameSponsor(f1, null, null);
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
			
		}

		public void toEliminaContratto(FrameContratto f1, Contratto contratto) {
			try {
				f1.disable();
				ricercaContratto = new ContrattoDAOPostgresImpl(connection);
				ricercaContratto.deleteContratto(contratto);
				//eliminacompensoatleta
				ricercaAtleta = new AtletaDAOPostgresImpl(connection);
				ricercaAtleta.eliminaCompensoContratto(contratto);
				
				ricercaProcuratore = new ProcuratoreDAOPostgresImpl(connection);
				ricercaProcuratore.eliminaCompensoContratto(contratto);
				
				toFrameContratto(f1, null, null, null,null);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}

		public void toFrameStatisticheProcuratore(JFrame f1,
				Procuratore proc) {
			try {
				f1.disable();
				ricercaProcuratore= new ProcuratoreDAOPostgresImpl(connection);
				procuratori= ricercaProcuratore.getAllProcuratore();
				FrameStatisticheProcuratore frameStatisticheProcuratore= new FrameStatisticheProcuratore(this, procuratori, proc,ricercaProcuratore);
				f1.setVisible(false);
				frameStatisticheProcuratore.setVisible(true);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}

		public void toFrameNazionale(JFrame f1, String nomeNazione) {
			
			nazionali = new ArrayList<Nazionale>();
			
			try {
				//PRENDI NAZIONALI DAL DATABASE
				f1.disable();
				Nazionale nazione = new Nazionale();
				ricercaNazionale = new NazionaleDAOPostgresImpl(connection);
				nazionali = ricercaNazionale.getNomeNazionale();
				
				FrameNazionale frameNazionale = new FrameNazionale(this, nomeNazione, nazionali, nazione, ricercaNazionale);
				f1.setVisible(false);
				frameNazionale.setVisible(true);
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
}
