package codiceFiscale;

public class ComuniCodice {
	
	private String nome;
	private String codice;
	
	public ComuniCodice(String nome, String codice) {
		super();
		this.nome = nome;
		this.codice = codice;
	}

	public String getNome() {
		return nome;
	}

	public String getCodice() {
		return codice;
	}
	
	
	
}
