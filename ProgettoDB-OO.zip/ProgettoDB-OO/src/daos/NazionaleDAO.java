package daos;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;

import entity.Nazionale;

public interface NazionaleDAO  {
	public void insertNazionale(Nazionale nazione) throws SQLException;

	public ArrayList<Nazionale> getNomeNazionale() throws SQLException;

	public ArrayList<String> getNomeNazionaleString() throws SQLException;
	
	public Nazionale getNazionale(String vincoloNazione) throws SQLException;

	public int getNumeroDiProcuratori(String vincoloNazione) throws SQLException;
	
	public int getNumeroDiAtleti(String vincoloNazione) throws SQLException;

	public void modificaGettone(String vincoloNazione,double gettone)throws SQLException;

	public void eliminaNazionale(String vincoloNazione)throws SQLException;

}
