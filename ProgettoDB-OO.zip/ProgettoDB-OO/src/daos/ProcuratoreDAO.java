package daos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Contratto;
import entity.Procuratore;

public interface ProcuratoreDAO {
	public void insertProcuratore(Procuratore procuratore) throws SQLException;

	public ArrayList<Procuratore> getAllProcuratore() throws SQLException;
	
	public ArrayList<Procuratore> getProcuratoreNazione(ArrayList<Procuratore> procuratori, String vincoloNazione) throws SQLException;

	public void eliminaProcuratore(Procuratore proc) throws SQLException;

	public void eliminaCompensoContratto(Contratto contratto) throws SQLException;

	public String getNumeroDiAtleti(Procuratore proc)throws SQLException;

	public String getNumeroDiContratti(Procuratore proc) throws SQLException;

	public ArrayList<String> getContrattiMigliori(Procuratore proc) throws SQLException;

	public ArrayList<String> getClubMigliori(Procuratore proc) throws SQLException;

	public ArrayList<String> getSponsorMigliori(Procuratore proc) throws SQLException;

	public ArrayList<String> getAtletiMigliori(Procuratore proc) throws SQLException;

	public Procuratore getProcuratoreAtleta(String string) throws SQLException;
};
