package daos;

import java.sql.SQLException;
import java.util.ArrayList;

import entity.Atleta;
import entity.Contratto;
import entity.Procuratore;

public interface AtletaDAO {
	public void insertAtleta(String codiceFiscale, Procuratore p, String ruolo)throws SQLException;

	public ArrayList<Atleta> getAllAtleti() throws SQLException;
	public ArrayList <Atleta> getAtletiNazione(ArrayList<Atleta> atleti, String vincoloNazione) throws SQLException;

	public ArrayList<Atleta> getAtletiProcuratore(Procuratore proc) throws SQLException;

	public void eliminaAtleta(Atleta atl)  throws SQLException;

	public void eliminaCompensoContratto(Contratto contratto) throws SQLException;

	public Atleta getAtletaFromCode(int codiceAtleta) throws SQLException;
	
	public void giocaPartita(Atleta atl) throws SQLException;


}
