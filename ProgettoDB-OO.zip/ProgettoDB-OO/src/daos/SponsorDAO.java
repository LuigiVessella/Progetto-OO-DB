package daos;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

import entity.Sponsor;

public interface SponsorDAO {
	public void inserisciSponsor(Sponsor sponsor) throws ParseException;

	public ArrayList<Sponsor> getAllSponsors() throws SQLException;

	public ArrayList<Sponsor> getSponsorNazione(ArrayList<Sponsor> sponsors, String vincoloNazione) throws SQLException;

	public ArrayList<String> getNomeSponsor ()  throws SQLException;

	public ArrayList<Sponsor> getSponsorsNome(String ordine) throws SQLException;

	public ArrayList<Sponsor> getSponsorsNazione(String ordine) throws SQLException;

	public void eliminaSponsor(Sponsor sponsor) throws SQLException;
	
	public Sponsor getSponsorFromCode(int codiceSponsor) throws SQLException;
	
	
}
