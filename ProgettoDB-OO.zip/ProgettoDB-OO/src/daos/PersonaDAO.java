package daos;

import java.sql.SQLException;
import java.util.Date;

import entity.Persona;

public interface PersonaDAO {
	public void insertPersona(Persona p1)throws SQLException;

}
