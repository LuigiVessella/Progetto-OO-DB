package daos;

import java.sql.SQLException;
import java.util.ArrayList;

import entity.Club;
import entity.Sponsor;

public interface ClubDAO {

	public void insertClub(Club club) throws SQLException;

	public ArrayList<Club> getAllClubs() throws SQLException;

	public ArrayList<Club> getClubNazione(ArrayList<Club> clubs, String vincoloNazione) throws SQLException;

	public ArrayList<String> getNomeClub() throws SQLException;

	public ArrayList<Club> getClubsNome(String ordine) throws SQLException;

	public ArrayList<Club> getClubsPresidente(String ordine) throws SQLException;

	public ArrayList<Club> getClubsFondazione(String ordine) throws SQLException;

	public ArrayList<Club> getClubsNazione(String ordine) throws SQLException;

	public void eliminaClub(Club club) throws SQLException;
	
	public Club getClubFromCode(int codiceClub) throws SQLException;
	
	
}