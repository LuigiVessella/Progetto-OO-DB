package daos;

import java.sql.SQLException;
import java.util.ArrayList;

import entity.Atleta;
import entity.Club;
import entity.Contratto;
import entity.Sponsor;

public interface ContrattoDAO {
	
	public void insertContrattoClub(Contratto contratto) throws SQLException;
	public void insertContrattoSponsor(Contratto contratto) throws SQLException;
	public ArrayList<Contratto> getAllContrattiSponsor() throws SQLException;
	public ArrayList<Contratto> getAllContrattiClub() throws SQLException;
	public void updateAtletaProcuratore(Contratto contratto) throws SQLException;
	public void deleteContratto(Contratto contratto) throws SQLException;
    public ArrayList<Contratto> getContrattiAtleta(Atleta atl) throws SQLException ;
	public ArrayList<Contratto> getContrattiClub(ArrayList<Contratto> contratti, String vincoloClub) throws SQLException;
	public ArrayList<Contratto> getContrattiSponsor(ArrayList<Contratto> contratti, String vincoloSponsor)throws SQLException;
	
}
