package postegresImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import daos.SponsorDAO;

import entity.Sponsor;

public class SponsorDAOPostgresImpl implements SponsorDAO {
	
	//ATTRIBUTI
	
	private Connection conn;
	
	
	
	//COSTRUTTORE
	public SponsorDAOPostgresImpl(Connection conn) throws SQLException {
		super();
		this.conn = conn;	
	}
	
	public void inserisciSponsor(Sponsor sponsor) {
		try {
			PreparedStatement inserisciSponsor= conn.prepareStatement("insert into sponsor(nome,nazionale) values (?,?)");;
			inserisciSponsor.setString(1, sponsor.getNome());
			inserisciSponsor.setString(2, sponsor.getNazionale());
			int i = inserisciSponsor.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}

	@Override
	public ArrayList<Sponsor> getAllSponsors() throws SQLException {
		
		ArrayList<Sponsor> listaSponsor=new ArrayList<Sponsor>();
		PreparedStatement  prendiTuttiSponsor = conn.prepareStatement("select * from sponsor");
		ResultSet rs= prendiTuttiSponsor.executeQuery();
		while(rs.next())
		{
			Sponsor s = new Sponsor();
			s.setNazionale(rs.getString("nazionale"));
			s.setNome(rs.getString("nome"));
			listaSponsor.add(s);
		}
		rs.close();
		return listaSponsor;
	}

	@Override
	public ArrayList<Sponsor> getSponsorNazione(ArrayList<Sponsor> sponsors, String vincoloNazione)
			throws SQLException {
		ArrayList<Sponsor> listaSponsor=new ArrayList<Sponsor>();
		PreparedStatement prendiSponsorNazione = conn.prepareStatement("select * from sponsor s join nazionale n on s.nazionale = n.nome where s.nazionale = ? and s.nome = ?");
		for(Sponsor sponsor: sponsors)
		{
			prendiSponsorNazione.setString(1, vincoloNazione);
			prendiSponsorNazione.setString(2, sponsor.getNome());
			ResultSet rs= prendiSponsorNazione.executeQuery();
			while(rs.next())
			{
				Sponsor s = new Sponsor();
				
				s.setNazionale(rs.getString("nazionale"));
				s.setNome(rs.getString("nome"));
				listaSponsor.add(s);
			}
			rs.close();
		}
		
		return listaSponsor;
	}

	@Override
	public ArrayList<String> getNomeSponsor() throws SQLException {
		ArrayList<String> lista = new ArrayList<String>();
		PreparedStatement getNomeSponsor = conn.prepareStatement("select nome from sponsor order by nome");
		ResultSet rs= getNomeSponsor.executeQuery();
		int counter=0;
		while(rs.next())
		{
			lista.add(counter, rs.getString("nome"));
			counter++;
		}
		return lista;
	}

	@Override
	public ArrayList<Sponsor> getSponsorsNome(String ordine) throws SQLException {
		ArrayList<Sponsor> listaSponsor = new ArrayList<Sponsor>();
		ResultSet rs;
		PreparedStatement prendiSponsorsNomeCrescente = conn.prepareStatement("select * from sponsor order by nome asc");
		PreparedStatement prendiSponsorsNomeDecrescente = conn.prepareStatement("select * from sponsor order by nome desc");
		if(ordine == "asc")
			rs = prendiSponsorsNomeCrescente.executeQuery();
		else 
			rs = prendiSponsorsNomeDecrescente.executeQuery();
		while(rs.next())
		{
			Sponsor s = new Sponsor();
			s.setNome(rs.getString("nome"));
			s.setNazionale(rs.getString("nazionale"));
			listaSponsor.add(s);
		}
		rs.close();
			
		return listaSponsor;
	
	}

	@Override
	public ArrayList<Sponsor> getSponsorsNazione(String ordine) throws SQLException {
		ArrayList<Sponsor> listaSponsor = new ArrayList<Sponsor>();
		ResultSet rs;
		PreparedStatement prendiSponsorsNazioneCrescente = conn.prepareStatement("select * from sponsor order by nazionale asc");
		PreparedStatement prendiSponsorsNazioneDecrescente = conn.prepareStatement("select * from sponsor order by nazionale desc");
		if(ordine == "asc")
			rs = prendiSponsorsNazioneCrescente.executeQuery();
		else 
			rs = prendiSponsorsNazioneDecrescente.executeQuery();
		while(rs.next())
		{
			Sponsor s = new Sponsor();
			s.setNome(rs.getString("nome"));
			s.setNazionale(rs.getString("nazionale"));
			listaSponsor.add(s);
		}
		rs.close();
			
		return listaSponsor;
	}

	@Override
	public void eliminaSponsor(Sponsor sponsor) throws SQLException {
		PreparedStatement deleteSponsor = conn.prepareStatement("delete from sponsor where nome = ?");
		deleteSponsor.setString(1, sponsor.getNome());
		int i = deleteSponsor.executeUpdate();
		
	}
	
	
	public Sponsor getSponsorFromCode(int codiceSponsor) throws SQLException {
		
		PreparedStatement getSponsor = conn.prepareStatement("select * from sponsor where codsponsor = ?");
		getSponsor.setInt(1, codiceSponsor);
		ResultSet rs = getSponsor.executeQuery();
		Sponsor s = new Sponsor();
		while(rs.next())
		{
			
			s.setNazionale(rs.getString("nazionale"));
			s.setNome(rs.getString("nome"));
			
		}
		rs.close();
		return s;
	}
}
