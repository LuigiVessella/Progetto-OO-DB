package postegresImpl;

import java.sql.*;
import java.util.ArrayList;


import daos.NazionaleDAO;
import entity.Nazionale;

public class NazionaleDAOPostgresImpl implements NazionaleDAO {
	//ATTRIBUTI
	private Connection conn;
	
	//COSTRUTTORE
	public NazionaleDAOPostgresImpl(Connection conn) throws SQLException {
		this.conn = conn;}



	@Override
	
	public ArrayList<Nazionale> getNomeNazionale() throws SQLException
	{
		ArrayList<Nazionale> lista = new ArrayList<Nazionale>();
		PreparedStatement getNomeNazionale = conn.prepareStatement("SELECT nome FROM Nazionale ORDER BY nome");
		ResultSet rs= getNomeNazionale.executeQuery();
		int counter=0;
		while(rs.next())
		{
			Nazionale n=new Nazionale();
			n.setNome( rs.getString("nome"));
			lista.add(n);
		}
		return lista;
	}
	
	public ArrayList<String> getNomeNazionaleString() throws SQLException
	{
		ArrayList<String> lista = new ArrayList<String>();
		PreparedStatement getNomeNazionale = conn.prepareStatement("SELECT nome FROM Nazionale ORDER BY nome");
		ResultSet rs= getNomeNazionale.executeQuery();
		int counter=0;
		while(rs.next())
		{
			lista.add(rs.getString("nome"));
		}
		return lista;
	}
	
	public void insertNazionale(Nazionale nazione) throws SQLException {
		PreparedStatement inserisciNazionale = conn.prepareStatement("Insert into nazionale values (?,?)");
		inserisciNazionale.setString(1, nazione.getNome());
		inserisciNazionale.setDouble(2, nazione.getGettone());
		int i = inserisciNazionale.executeUpdate();
	}



	@Override
	public Nazionale getNazionale(String vincoloNazione) throws SQLException {
		PreparedStatement prendiNazionaleDaNome = conn.prepareStatement("SELECT * FROM nazionale where nome= ? ");
		prendiNazionaleDaNome.setString(1,vincoloNazione );
		ResultSet rs= prendiNazionaleDaNome.executeQuery();
		Nazionale nazione= new Nazionale();
		while(rs.next())
		{
			nazione.setNome(rs.getString("nome"));
			nazione.setGettone(rs.getDouble("gettone"));
		}
		rs.close();
		return nazione;
		
	}



	@Override
	public int getNumeroDiProcuratori(String vincoloNazione) throws SQLException {
		int value=0;
		PreparedStatement prendiNumeroProcuratori = conn.prepareStatement("SELECT COUNT(codicefiscale)as valore FROM procuratore natural join persona  WHERE nazionalita = ?");
		prendiNumeroProcuratori.setString(1, vincoloNazione);
		ResultSet rs = prendiNumeroProcuratori.executeQuery();
		while(rs.next())
		{
			value = rs.getInt("valore");
		}
		rs.close();
		return value;
	}



	@Override
	public int getNumeroDiAtleti(String vincoloNazione) throws SQLException {
		int value=0;
		PreparedStatement prendiNumeroAtleti = conn.prepareStatement("SELECT COUNT(codicefiscale)as valore FROM atleta natural join persona  WHERE nazionalita = ?");
		prendiNumeroAtleti.setString(1, vincoloNazione);
		ResultSet rs = prendiNumeroAtleti.executeQuery();
		while(rs.next())
		{
			value = rs.getInt("valore");
		}
		rs.close();
		return value;
	}



	@Override
	public void modificaGettone(String vincoloNazione,double gettone) throws SQLException {
		PreparedStatement updateGettone = conn.prepareStatement("update nazionale set gettone= ? where nome = ?");
		updateGettone.setDouble(1, gettone);
		updateGettone.setString(2, vincoloNazione);
		int valore = updateGettone.executeUpdate();
		
	}



	@Override
	public void eliminaNazionale(String vincoloNazione) throws SQLException {
		PreparedStatement deleteNazionale= conn.prepareStatement("delete from nazionale where nome= ?");
		deleteNazionale.setString(1, vincoloNazione);
		int i= deleteNazionale.executeUpdate();
		
	}

}
