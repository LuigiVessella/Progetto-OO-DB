package postegresImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



import daos.ClubDAO;
import entity.Club;
import entity.Sponsor;


public class ClubDAOPostgresImpl implements ClubDAO {
	private Connection conn;
	  
	public ClubDAOPostgresImpl(Connection conn) throws SQLException {
		super();
		this.conn = conn;
	}
	
	public void insertClub(Club club) throws SQLException
	{
		PreparedStatement inserisciClub = conn.prepareStatement("insert into club(nome,presidente,fondazione,nazionale) values(?,?,?,?)");
		java.sql.Date sd = new java.sql.Date(club.getFondazione().getTime());
		inserisciClub.setString(1, club.getNome());
		inserisciClub.setString(2, club.getPresidente());
		inserisciClub.setDate(3, sd);
		inserisciClub.setString(4, club.getNazionale());
		int i = inserisciClub.executeUpdate();
	}

	public ArrayList<Club> getAllClubs() throws SQLException {
		ArrayList<Club> listaClub = new ArrayList<Club>();
		PreparedStatement prendiTuttiClub = conn.prepareStatement("select * from club");
		ResultSet rs = prendiTuttiClub.executeQuery();
		while(rs.next())
		{
			Club club = new Club();
			club.setNome(rs.getString("nome"));
			club.setPresidente(rs.getString("presidente"));
			club.setNazionale(rs.getString("nazionale"));
			club.setFondazione(rs.getDate("fondazione"));
			listaClub.add(club);
		}
		rs.close();
		return listaClub;
	}

	@Override
	public ArrayList<Club> getClubNazione(ArrayList<Club> clubs, String vincoloNazione) throws SQLException {

		ArrayList<Club> listaClub = new ArrayList<Club>();
		Club c;
		PreparedStatement prendiClubNazione = conn.prepareStatement("select * from club c join nazionale n on c.nazionale = n.nome where nazionale = ? and c.nome= ? ");
		System.out.println(vincoloNazione);
		for(Club club : clubs)
		{
			prendiClubNazione.setString(1, vincoloNazione);
			prendiClubNazione.setString(2, club.getNome());
			ResultSet rs = prendiClubNazione.executeQuery();
			
			while(rs.next())
			{
				
				c = new Club();
				c.setNome(rs.getString("nome"));
				c.setPresidente(rs.getString("presidente"));
				c.setNazionale(rs.getString("nazionale"));
				c.setFondazione(rs.getDate("fondazione"));
				listaClub.add(c);
			}
			rs.close();
		}
		return listaClub;
	}

	@Override
	public ArrayList<String> getNomeClub() throws SQLException {
		ArrayList<String> lista = new ArrayList<String>();
		PreparedStatement getNomeClub = conn.prepareStatement("select nome from club order by nome");
		ResultSet rs = getNomeClub.executeQuery();
		int counter = 0;
		while(rs.next())
		{
			lista.add(counter, rs.getString("nome"));
			counter++;
		}
		return lista;
		
	}

	@Override
	public ArrayList<Club> getClubsNome(String ordine) throws SQLException {
		ArrayList<Club> listaClub = new ArrayList<Club>();
		ResultSet rs;
		PreparedStatement prendiClubsNomeCrescente = conn.prepareStatement("select * from club order by nome asc");
		PreparedStatement prendiClubsNomeDecrescente = conn.prepareStatement("select * from club order by nome desc");
		if(ordine == "asc")
			rs = prendiClubsNomeCrescente.executeQuery();
		else 
			rs = prendiClubsNomeDecrescente.executeQuery();
		while(rs.next())
		{
			Club c = new Club();
			c.setNome(rs.getString("nome"));
			c.setPresidente(rs.getString("presidente"));
			c.setFondazione(rs.getDate("fondazione"));
			c.setNazionale(rs.getString("nazionale"));
			listaClub.add(c);
		}
		rs.close();
			
		return listaClub;
	
	}

	@Override
	public ArrayList<Club> getClubsPresidente(String ordine) throws SQLException {
		ArrayList<Club> listaClub = new ArrayList<Club>();
		ResultSet rs;
		PreparedStatement prendiClubsPresidenteCrescente = conn.prepareStatement("select * from club order by presidente asc");
		PreparedStatement prendiClubsPresidenteDecrescente = conn.prepareStatement("select * from club order by presidente desc");
		if(ordine == "asc")
			rs = prendiClubsPresidenteCrescente.executeQuery();
		else 
			rs = prendiClubsPresidenteDecrescente.executeQuery();
		while(rs.next())
		{
			Club c = new Club();
			c.setNome(rs.getString("nome"));
			c.setPresidente(rs.getString("presidente"));
			c.setFondazione(rs.getDate("fondazione"));
			c.setNazionale(rs.getString("nazionale"));
			listaClub.add(c);
		}
		rs.close();
			
		return listaClub;
	}

	@Override
	public ArrayList<Club> getClubsFondazione(String ordine) throws SQLException {
		ArrayList<Club> listaClub = new ArrayList<Club>();
		ResultSet rs;
		PreparedStatement prendiClubsFondazioneCrescente = conn.prepareStatement("select * from club order by extract(year from fondazione) asc");
		PreparedStatement prendiClubsFondazioneDecrescente = conn.prepareStatement("select * from club order by extract(year from fondazione) desc");
		if(ordine == "asc")
			rs = prendiClubsFondazioneCrescente.executeQuery();
		else 
			rs = prendiClubsFondazioneDecrescente.executeQuery();
		while(rs.next())
		{
			Club c = new Club();
			c.setNome(rs.getString("nome"));
			c.setPresidente(rs.getString("presidente"));
			c.setFondazione(rs.getDate("fondazione"));
			c.setNazionale(rs.getString("nazionale"));
			listaClub.add(c);
		}
		rs.close();
			
		return listaClub;
	}

	@Override
	public ArrayList<Club> getClubsNazione(String ordine) throws SQLException {
		ArrayList<Club> listaClub = new ArrayList<Club>();
		ResultSet rs;
		PreparedStatement prendiClubsNazioneCrescente = conn.prepareStatement("select * from club order by nazionale asc");
		PreparedStatement prendiClubsNazioneDecrescente = conn.prepareStatement("select * from club order by nazionale desc");
		if(ordine == "asc")
			rs = prendiClubsNazioneCrescente.executeQuery();
		else 
			rs = prendiClubsNazioneDecrescente.executeQuery();
		while(rs.next())
		{
			Club c = new Club();
			c.setNome(rs.getString("nome"));
			c.setPresidente(rs.getString("presidente"));
			c.setFondazione(rs.getDate("fondazione"));
			c.setNazionale(rs.getString("nazionale"));
			listaClub.add(c);
		}
		rs.close();
			
		return listaClub;
	}

	@Override
	public void eliminaClub(Club club) throws SQLException {
		PreparedStatement deleteClub = conn.prepareStatement("delete from club where nome = ?");
		deleteClub.setString(1, club.getNome());
		int i = deleteClub.executeUpdate();
	}
	
	
	public Club getClubFromCode(int codiceClub) throws SQLException {
		PreparedStatement getClub = conn.prepareStatement("select * from club where codclub = ?");
		getClub.setInt(1, codiceClub);
		ResultSet rs = getClub.executeQuery();
		Club club = new Club();
		while(rs.next())
		{
		
			club.setNome(rs.getString("nome"));
			club.setPresidente(rs.getString("presidente"));
			club.setNazionale(rs.getString("nazionale"));
			club.setFondazione(rs.getDate("fondazione"));
			
		}
		rs.close();
		return club;
	}
		
	
}
