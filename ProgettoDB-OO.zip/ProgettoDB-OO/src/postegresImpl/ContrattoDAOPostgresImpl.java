package postegresImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import daos.AtletaDAO;
import daos.ClubDAO;
import daos.ContrattoDAO;
import daos.SponsorDAO;
import entity.Atleta;
import entity.Club;
import entity.Contratto;
import entity.Procuratore;
import entity.Sponsor;


public class ContrattoDAOPostgresImpl implements ContrattoDAO {
	
	//ATTRIBUTI
	private Connection conn;

	//DAO
	private SponsorDAO ricercaSponsor;
	private ClubDAO ricercaClub;
	//COSTRUTTORE
	public ContrattoDAOPostgresImpl(Connection conn) throws SQLException {
		super();
		this.conn = conn;
	}
	
	
	//METODI
	public void insertContrattoClub(Contratto contratto) throws SQLException {
		PreparedStatement inserisciContrattoClub = conn.prepareStatement("insert into contratto(iniziocontratto, finecontratto, compenso, "
				+ "percentualeprocuratore, codiceatleta, codsponsor, codclub) values(?, ?, ?, ?, ?, null, ?)");
		
		int codiceClub = 0;
		PreparedStatement stmt = conn.prepareStatement("select codclub from club where nome = ?");
		stmt.setString(1, contratto.getClub().getNome());
		ResultSet prendiCodice = stmt.executeQuery();
		while(prendiCodice.next()) codiceClub = prendiCodice.getInt("codclub");
		System.out.println(codiceClub);
		
		int codiceAtleta = 0;
		PreparedStatement stmt2 = conn.prepareStatement("select codiceatleta from atleta where codicefiscale = ?");
		stmt2.setString(1,contratto.getAtleta().getCodiceFiscale());
		ResultSet prendiCodice2 = stmt2.executeQuery();
		while(prendiCodice2.next()) codiceAtleta = prendiCodice2.getInt("codiceatleta");
		
		java.sql.Date inizioContratto = new java.sql.Date(contratto.getInizioContratto().getTime());
		java.sql.Date fineContratto = new java.sql.Date(contratto.getFineContratto().getTime());
		inserisciContrattoClub.setDate(1, inizioContratto);
		inserisciContrattoClub.setDate(2, fineContratto);
		inserisciContrattoClub.setDouble(3, contratto.getCompenso());
		inserisciContrattoClub.setDouble(4, contratto.getPercentualeProcuratore());
		inserisciContrattoClub.setInt(5, codiceAtleta); // set codice atleta
		inserisciContrattoClub.setInt(6, codiceClub); // set codice club
		
		int i = inserisciContrattoClub.executeUpdate();
		
	}
	
	public void insertContrattoSponsor(Contratto contratto) throws SQLException {
		PreparedStatement inserisciContrattoSponsor = conn.prepareStatement("insert into contratto(iniziocontratto, finecontratto, compenso, "
				+ "percentualeprocuratore, codiceatleta, codsponsor, codclub) values(?, ?, ?, ?, ?, ?, null)") ;
		
		int codiceSponsor = 0;
		PreparedStatement stmt = conn.prepareStatement("select codsponsor from sponsor where nome = ?");
		stmt.setString(1, contratto.getSponsor().getNome());
		ResultSet prendiCodice = stmt.executeQuery();
		if(prendiCodice.next()) codiceSponsor = prendiCodice.getInt("codsponsor");
		
		int codiceAtleta = 0;
		PreparedStatement stmt2 = conn.prepareStatement("select codiceatleta from atleta where codicefiscale = ?");
		stmt2.setString(1, contratto.getAtleta().getCodiceFiscale());
		ResultSet prendiCodice2 = stmt2.executeQuery();
		if(prendiCodice2.next()) codiceAtleta = prendiCodice2.getInt("codiceatleta");
		
		
		java.sql.Date inizioContratto = new java.sql.Date(contratto.getInizioContratto().getTime());
		java.sql.Date fineContratto = new java.sql.Date(contratto.getFineContratto().getTime());
		inserisciContrattoSponsor.setDate(1, inizioContratto);
		inserisciContrattoSponsor.setDate(2, fineContratto);
		inserisciContrattoSponsor.setDouble(3, contratto.getCompenso());
		inserisciContrattoSponsor.setDouble(4, contratto.getPercentualeProcuratore());
		inserisciContrattoSponsor.setInt(5, codiceAtleta); 
		inserisciContrattoSponsor.setInt(6, codiceSponsor); 

	
		int i = inserisciContrattoSponsor.executeUpdate();
	}
	
	public void updateAtletaProcuratore(Contratto contratto) throws SQLException {
		PreparedStatement aggiornaGuadagniAtleta = conn.prepareStatement("update atleta set totaleguadagni = totaleguadagni + ? where atleta.codicefiscale = ? ");
		PreparedStatement aggiornaGuadagniProcuratore = conn.prepareStatement("update procuratore set totaleguadagni = totaleguadagni + ? where procuratore.codicefiscale = ? ");

		double guadagnoProcuratore = (contratto.getPercentualeProcuratore()/100) * contratto.getCompenso();
		double guadagnoAtleta = contratto.getCompenso() - guadagnoProcuratore;
		
		aggiornaGuadagniProcuratore.setDouble(1, guadagnoProcuratore);
		aggiornaGuadagniProcuratore.setString(2, contratto.getAtleta().getProcuratore().getCodiceFiscale());
		
		aggiornaGuadagniAtleta.setDouble(1, guadagnoAtleta);
		aggiornaGuadagniAtleta.setString(2, contratto.getAtleta().getCodiceFiscale());
		
		int i = aggiornaGuadagniProcuratore.executeUpdate();
		int a = aggiornaGuadagniAtleta.executeUpdate();
	}
	
	public ArrayList<Contratto> getAllContrattiClub() throws SQLException{
		AtletaDAO getAtleta = new AtletaDAOPostgresImpl(conn);
		ricercaClub = new ClubDAOPostgresImpl(conn);
		ArrayList<Contratto> contratti = new ArrayList<Contratto>();
		PreparedStatement getAllContrattiClub = conn.prepareStatement("select * from contratto where codsponsor is null");
		ResultSet rs = getAllContrattiClub.executeQuery();
		
		while(rs.next()) {

			Contratto contratto = new Contratto();
			
			contratto.setCodiceContratto(rs.getInt("codicecontratto"));
			contratto.setCompenso(rs.getDouble("compenso"));
			contratto.setFineContratto(rs.getDate("finecontratto"));
			contratto.setInizioContratto(rs.getDate("iniziocontratto"));
			contratto.setPercentualeProcuratore(rs.getDouble("percentualeprocuratore"));
			contratto.setAtleta(getAtleta.getAtletaFromCode(rs.getInt("codiceatleta")));
			contratto.setClub(ricercaClub.getClubFromCode(rs.getInt("codclub")));
			contratto.setSponsor(null);
			contratti.add(contratto);
		}
		return contratti;
	}
	
	@Override
	public ArrayList<Contratto> getContrattiAtleta(Atleta atl) throws SQLException {
		ArrayList<Contratto> contratti = new ArrayList<Contratto>();
		PreparedStatement prendiContrattiAtleta = conn.prepareStatement("select * from contratto natural join atleta where  codicefiscale = ?"); 
		ricercaClub=new ClubDAOPostgresImpl(conn);
		ricercaSponsor = new SponsorDAOPostgresImpl(conn);
		prendiContrattiAtleta.setString(1, atl.getCodiceFiscale());
		ResultSet rs = prendiContrattiAtleta.executeQuery();
		while(rs.next())
		{
			Contratto c = new Contratto();
			c.setAtleta(atl);
			c.setSponsor(ricercaSponsor.getSponsorFromCode(rs.getInt("codsponsor")));
			c.setClub(ricercaClub.getClubFromCode(rs.getInt("codclub")));
			c.setCodiceContratto(rs.getInt("codicecontratto"));
			c.setCompenso(rs.getDouble("compenso"));
			c.setFineContratto(rs.getDate("finecontratto"));
			c.setInizioContratto(rs.getDate("iniziocontratto"));
			c.setPercentualeProcuratore(rs.getDouble("percentualeprocuratore"));
			contratti.add(c);
			
		}
		rs.close();
		
		return contratti;
	}
	
	public ArrayList<Contratto> getAllContrattiSponsor() throws SQLException{
		AtletaDAO getAtleta = new AtletaDAOPostgresImpl(conn);
		ricercaSponsor = new SponsorDAOPostgresImpl(conn);
		
		
		PreparedStatement getAllContrattiSponsor = conn.prepareStatement("select * from contratto  where codclub is null");
		
		ArrayList<Contratto> contratti = new ArrayList<Contratto>();
		ResultSet rs = getAllContrattiSponsor.executeQuery();
		
		while(rs.next()) {
			Contratto contratto = new Contratto();

			contratto.setCodiceContratto(rs.getInt("codicecontratto"));
			contratto.setCompenso(rs.getDouble("compenso"));
			contratto.setFineContratto(rs.getDate("finecontratto"));
			contratto.setInizioContratto(rs.getDate("iniziocontratto"));
			contratto.setPercentualeProcuratore(rs.getDouble("percentualeprocuratore"));
			contratto.setAtleta(getAtleta.getAtletaFromCode(rs.getInt("codiceatleta")));
			contratto.setSponsor(ricercaSponsor.getSponsorFromCode(rs.getInt("codsponsor")));
			contratto.setClub(null);
			contratti.add(contratto);
		}
		
		return contratti;
	}



	@Override
	public void deleteContratto(Contratto contratto) throws SQLException {
		PreparedStatement deleteContratto = conn.prepareStatement("delete from contratto where codicecontratto = ? ");
		deleteContratto.setInt(1, contratto.getCodiceContratto());
		int i = deleteContratto.executeUpdate();
		
	}


	@Override
	public ArrayList<Contratto> getContrattiClub(ArrayList<Contratto> contratti, String vincoloClub)
			throws SQLException {
		AtletaDAO getAtleta = new AtletaDAOPostgresImpl(conn);
		ricercaClub = new ClubDAOPostgresImpl(conn);
		ArrayList<Contratto> listaContratti=new ArrayList<Contratto>();
		PreparedStatement prendiSponsorNazione = conn.prepareStatement("select * from contratto c join club cl on c.codclub = cl.codclub where cl.nome= ? and c.codicecontratto = ?");
		for(Contratto contratto: contratti)
		{
			prendiSponsorNazione.setString(1, vincoloClub);
			prendiSponsorNazione.setInt(2, contratto.getCodiceContratto());
			ResultSet rs= prendiSponsorNazione.executeQuery();
			while(rs.next())
			{
				Contratto c = new Contratto();
				
				c.setCodiceContratto(rs.getInt("codicecontratto"));
				c.setCompenso(rs.getDouble("compenso"));
				c.setFineContratto(rs.getDate("finecontratto"));
				c.setInizioContratto(rs.getDate("iniziocontratto"));
				c.setPercentualeProcuratore(rs.getDouble("percentualeprocuratore"));
				c.setAtleta(getAtleta.getAtletaFromCode(rs.getInt("codiceatleta")));
				c.setSponsor(null);
				c.setClub(ricercaClub.getClubFromCode(rs.getInt("codclub")));
				listaContratti.add(c);
			}
			rs.close();
		}
		
		return listaContratti;
	}


	@Override
	public ArrayList<Contratto> getContrattiSponsor(ArrayList<Contratto> contratti, String vincoloSponsor)
			throws SQLException {
		AtletaDAO getAtleta = new AtletaDAOPostgresImpl(conn);
		ricercaSponsor = new SponsorDAOPostgresImpl(conn);
		ArrayList<Contratto> listaContratti=new ArrayList<Contratto>();
		PreparedStatement prendiSponsorNazione = conn.prepareStatement("select * from contratto c join sponsor s on c.codsponsor = s.codsponsor where s.nome and c.codicecontratto = ?");
		for(Contratto contratto: contratti)
		{
			prendiSponsorNazione.setString(1, vincoloSponsor);
			prendiSponsorNazione.setInt(2, contratto.getCodiceContratto());
			ResultSet rs= prendiSponsorNazione.executeQuery();
			while(rs.next())
			{
				Contratto c = new Contratto();
				
				c.setCodiceContratto(rs.getInt("codicecontratto"));
				c.setCompenso(rs.getDouble("compenso"));
				c.setFineContratto(rs.getDate("finecontratto"));
				c.setInizioContratto(rs.getDate("iniziocontratto"));
				c.setPercentualeProcuratore(rs.getDouble("percentualeprocuratore"));
				c.setAtleta(getAtleta.getAtletaFromCode(rs.getInt("codiceatleta")));
				c.setSponsor(ricercaSponsor.getSponsorFromCode(rs.getInt("codsponsor")));
				c.setClub(null);
				listaContratti.add(c);
			}
			rs.close();
		}
		
		return listaContratti;
	}

	

}
