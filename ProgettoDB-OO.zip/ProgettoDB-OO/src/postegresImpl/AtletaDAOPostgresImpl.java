package postegresImpl;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

import daos.AtletaDAO;
import daos.ContrattoDAO;
import daos.ProcuratoreDAO;
import entity.Atleta;
import entity.Contratto;
import entity.Procuratore;


public class AtletaDAOPostgresImpl implements AtletaDAO {
	//ATTRIBUTI
	
	private Connection conn;

	//DAO
	private ProcuratoreDAO ricercaProcuratore;
	private ContrattoDAO ricercaContratto;
	//COSTRUTTORE
	public AtletaDAOPostgresImpl(Connection conn) throws SQLException {
		super();
		this.conn = conn;
	}
	
	public ArrayList<Atleta> getAtletiProcuratore (Procuratore p) throws SQLException
	{
		PreparedStatement prendiAtletiProcuratore = conn.prepareStatement("select * from atleta natural join persona where codiceprocuratore = ?");
		
		ricercaContratto = new ContrattoDAOPostgresImpl(conn);
		int codiceProcuratore = 0;
		PreparedStatement stmt = conn.prepareStatement("select codiceprocuratore from procuratore where codicefiscale = ?");
		
		stmt.setString(1, p.getCodiceFiscale());
		ResultSet prendiCodice = stmt.executeQuery();
		if(prendiCodice.next()) codiceProcuratore = prendiCodice.getInt("codiceprocuratore");
		
		ArrayList<Atleta> listaAtleti = new ArrayList<Atleta>();
		prendiAtletiProcuratore.setInt(1, codiceProcuratore);
		ResultSet rs = prendiAtletiProcuratore.executeQuery();
		
		while(rs.next())
		{
			Atleta a = new Atleta();
			a.setCodiceFiscale(rs.getString("codicefiscale"));
			a.setNome(rs.getString("nome"));
			a.setCognome(rs.getString("cognome"));
			a.setEmail(rs.getString("email"));
			a.setNazionalita(rs.getString("nazionalita"));
			a.setTotaleGuadagni(rs.getDouble("totaleguadagni"));
			a.setCittaDiNascita(rs.getString("cittadinascita"));
			a.setDataDiNascita(rs.getDate("datadinascita"));
			a.setRuolo(rs.getString("ruolo"));
			a.setSesso(rs.getString("sesso"));
			a.setPartiteGiocateNazionale(rs.getInt("partitegiocatenazionale"));
			a.setProcuratore(p);
			a.setContratti(ricercaContratto.getContrattiAtleta(a));
			listaAtleti.add(a);
		}

		p.setAtleti(listaAtleti);
		rs.close();
		return p.getAtleti();
	}
	
	public void insertAtleta(String codiceFiscale, Procuratore p, String ruolo)throws SQLException
	{
		int codiceProcuratore = 0;
		PreparedStatement stmt = conn.prepareStatement("SELECT codiceprocuratore from procuratore where codicefiscale = ?");
		stmt.setString(1, p.getCodiceFiscale());
		ResultSet rs = stmt.executeQuery();
		if(rs.next())
			codiceProcuratore = rs.getInt("codiceprocuratore");
		PreparedStatement inserisciAtletaCodiceFiscaleProc = conn.prepareStatement("insert into atleta (codicefiscale, codiceprocuratore, ruolo,partitegiocatenazionale) values (?,?,?,?)");

		inserisciAtletaCodiceFiscaleProc.setString(1, codiceFiscale);
		inserisciAtletaCodiceFiscaleProc.setInt(2, codiceProcuratore );
		inserisciAtletaCodiceFiscaleProc.setString(3, ruolo);
		inserisciAtletaCodiceFiscaleProc.setInt(4, 0);
		int i = inserisciAtletaCodiceFiscaleProc.executeUpdate();
	}
	
	public ArrayList <Atleta> getAtletiNazione (ArrayList<Atleta> atleti, String vincoloNazione) throws SQLException
	{
		ricercaProcuratore = new ProcuratoreDAOPostgresImpl(conn);
		PreparedStatement prendiAtletiNazione = conn.prepareStatement("select * from atleta natural join persona where nazionalita = ? and codicefiscale = ?");
		ricercaContratto = new ContrattoDAOPostgresImpl(conn);
		ArrayList<Atleta> listaAtleti = new ArrayList<Atleta>();
		
		for(Atleta atl : atleti)
		{
			prendiAtletiNazione.setString(1, vincoloNazione);
			prendiAtletiNazione.setString(2, atl.getCodiceFiscale());
			ResultSet rs = prendiAtletiNazione.executeQuery();
			
			while(rs.next())
			{
				Atleta a = new Atleta();
				a.setCodiceFiscale(rs.getString("codicefiscale"));
				a.setNome(rs.getString("nome"));
				a.setCognome(rs.getString("cognome"));
				a.setEmail(rs.getString("email"));
				a.setNazionalita(rs.getString("nazionalita"));
				a.setTotaleGuadagni(rs.getDouble("totaleguadagni"));
				a.setCittaDiNascita(rs.getString("cittadinascita"));
				a.setDataDiNascita(rs.getDate("datadinascita"));
				a.setRuolo(rs.getString("ruolo"));
				a.setSesso(rs.getString("sesso"));
				a.setPartiteGiocateNazionale(rs.getInt("partitegiocatenazionale"));
				a.setContratti(ricercaContratto.getContrattiAtleta(a));
				a.setProcuratore(ricercaProcuratore.getProcuratoreAtleta(rs.getString("codicefiscale")));
				listaAtleti.add(a);
			}
			rs.close();
		}
		
		return listaAtleti;
	}
	
	public ArrayList<Atleta> getAllAtleti() throws SQLException
	{
		ricercaProcuratore = new ProcuratoreDAOPostgresImpl(conn);
		ArrayList<Atleta> listaAtleti = new ArrayList<Atleta>();
		PreparedStatement prenditTuttiAtleti = conn.prepareStatement("select * from atleta natural join persona");
		ricercaContratto = new ContrattoDAOPostgresImpl(conn);
		ResultSet rs = prenditTuttiAtleti.executeQuery();
		while(rs.next())
		{
			Atleta a = new Atleta();
			a.setCodiceFiscale(rs.getString("codicefiscale"));
			a.setNome(rs.getString("nome"));
			a.setCognome(rs.getString("cognome"));
			a.setEmail(rs.getString("email"));
			a.setNazionalita(rs.getString("nazionalita"));
			a.setTotaleGuadagni(rs.getDouble("totaleguadagni"));
			a.setCittaDiNascita(rs.getString("cittadinascita"));
			a.setDataDiNascita(rs.getDate("datadinascita"));
			a.setRuolo(rs.getString("ruolo"));
			a.setSesso(rs.getString("sesso"));
			a.setPartiteGiocateNazionale(rs.getInt("partitegiocatenazionale"));
			a.setContratti(ricercaContratto.getContrattiAtleta(a));
			a.setProcuratore(ricercaProcuratore.getProcuratoreAtleta(rs.getString("codicefiscale")));
			listaAtleti.add(a);
		}
		return listaAtleti;
	}

	

	@Override
	public void eliminaAtleta(Atleta atl) throws SQLException {
		PreparedStatement deletePersona = conn.prepareStatement("delete from persona where codicefiscale = ? ");

		deletePersona.setString(1, atl.getCodiceFiscale());
		int i = deletePersona.executeUpdate();
		
	}

	@Override
	public void eliminaCompensoContratto(Contratto contratto) throws SQLException {
		PreparedStatement deleteCompensoContratto = conn.prepareStatement("update atleta set totaleguadagni = totaleguadagni - ? where codicefiscale = ?");

		double guadagnoProcuratore = (contratto.getPercentualeProcuratore()/100) * contratto.getCompenso();
		double guadagnoAtleta = contratto.getCompenso() - guadagnoProcuratore;
		deleteCompensoContratto.setDouble(1, guadagnoAtleta);
		deleteCompensoContratto.setString(2, contratto.getAtleta().getCodiceFiscale());
		int i = deleteCompensoContratto.executeUpdate();
	}
	
	


	@Override
	public void giocaPartita (Atleta atl) throws SQLException {
		PreparedStatement giocaPartita = conn.prepareStatement("update atleta set partitegiocatenazionale = partitegiocatenazionale+1 where codicefiscale = ?");
		PreparedStatement aggiornaGuadagnoPartita = conn.prepareStatement("update atleta set totaleguadagni =totaleguadagni +(select ((n.gettone)-((p.percentualegettone/100)*n.gettone)) as guadagno from atleta a join procuratore p on a.codiceprocuratore=p.codiceprocuratore join persona pp on a.codicefiscale=pp.codicefiscale  join nazionale n on pp.nazionalita=n.nome where a.codicefiscale = ?) where codicefiscale= ?	");
		PreparedStatement aggiornaGuadagnoPartitaProcuratore = conn.prepareStatement("update procuratore set totaleguadagni =totaleguadagni+ (select ((p.percentualegettone/100)*n.gettone) as guadagno from atleta a join procuratore p on a.codiceprocuratore=p.codiceprocuratore join persona pp on a.codicefiscale=pp.codicefiscale  join nazionale n on pp.nazionalita=n.nome where a.codicefiscale = ?) where codicefiscale = ?"); 


		//i codici li dobbiamo ottenere con delle query
		aggiornaGuadagnoPartita.setString(1, atl.getCodiceFiscale());
		aggiornaGuadagnoPartita.setString(2, atl.getCodiceFiscale());
		int i = aggiornaGuadagnoPartita.executeUpdate();
		giocaPartita.setString(1, atl.getCodiceFiscale());
		i = giocaPartita.executeUpdate();
		
		aggiornaGuadagnoPartitaProcuratore.setString(1, atl.getCodiceFiscale());
		aggiornaGuadagnoPartitaProcuratore.setString(2, atl.getProcuratore().getCodiceFiscale());
		
		i = aggiornaGuadagnoPartitaProcuratore.executeUpdate();
		
	}
	
	
	public Atleta getAtletaFromCode(int codiceAtleta) throws SQLException {
		
		ricercaProcuratore = new ProcuratoreDAOPostgresImpl(conn);
		ricercaContratto = new ContrattoDAOPostgresImpl(conn);
		PreparedStatement prendiAtletaDaCodice = conn.prepareStatement("select * from atleta natural join persona where codiceatleta = ?");
		prendiAtletaDaCodice.setInt(1, codiceAtleta);
		
		ResultSet rs = prendiAtletaDaCodice.executeQuery();
		Atleta a = new Atleta();
		while(rs.next())
		{
			
			a.setCodiceFiscale(rs.getString("codicefiscale"));
			a.setNome(rs.getString("nome"));
			a.setCognome(rs.getString("cognome"));
			a.setEmail(rs.getString("email"));
			a.setNazionalita(rs.getString("nazionalita"));
			a.setTotaleGuadagni(rs.getDouble("totaleguadagni"));
			a.setCittaDiNascita(rs.getString("cittadinascita"));
			a.setDataDiNascita(rs.getDate("datadinascita"));
			a.setRuolo(rs.getString("ruolo"));
			a.setSesso(rs.getString("sesso"));
			a.setPartiteGiocateNazionale(rs.getInt("partitegiocatenazionale"));
			a.setContratti(ricercaContratto.getContrattiAtleta(a));
			a.setProcuratore(ricercaProcuratore.getProcuratoreAtleta(rs.getString("codicefiscale")));
			
		}
		return a;
	}
	
	
}
