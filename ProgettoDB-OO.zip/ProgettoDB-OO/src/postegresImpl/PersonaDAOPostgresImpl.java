package postegresImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import daos.PersonaDAO;
import entity.Persona;

public class PersonaDAOPostgresImpl implements PersonaDAO {
	//ATTRIBUTI
	private Connection conn;
	
	//COSTRUTTORE

	public PersonaDAOPostgresImpl(Connection conn) throws SQLException {
		super();
		this.conn = conn;
	}
	
	
	public void insertPersona(Persona p1) throws SQLException
	{
		PreparedStatement inserisciPersona = conn.prepareStatement("INSERT INTO PERSONA VALUES(?,?,?,?,?,?,?,?,?)");
		java.sql.Date sd = new java.sql.Date(p1.getDataDiNascita().getTime());
		try {
			inserisciPersona.setString(1, p1.getCodiceFiscale().trim());
			inserisciPersona.setString(2, p1.getNome().trim());
			inserisciPersona.setString(3, p1.getCognome().trim());		
			inserisciPersona.setDate(4, sd);
			inserisciPersona.setString(5, p1.getCittaDiNascita().trim());
			inserisciPersona.setString(6, p1.getDomicilio().trim());
			inserisciPersona.setString(7, p1.getEmail().trim());
			inserisciPersona.setString(8, p1.getNazionalita().trim());
			inserisciPersona.setString(9, p1.getSesso());
			
			int i = inserisciPersona.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
}
