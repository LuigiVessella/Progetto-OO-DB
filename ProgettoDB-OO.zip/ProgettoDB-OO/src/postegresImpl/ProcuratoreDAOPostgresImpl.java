package postegresImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import daos.AtletaDAO;
import daos.ProcuratoreDAO;
import entity.Atleta;
import entity.Contratto;
import entity.Procuratore;

public class ProcuratoreDAOPostgresImpl implements ProcuratoreDAO {
	//ATTRIBUTI
	private Connection conn;
	//DAO
	AtletaDAO ricercaAtleta;
	//COSTRUTTORE
	public ProcuratoreDAOPostgresImpl(Connection conn) throws SQLException {
		super();
		this.conn = conn;	
	}
	
	
	//METODI E LANCIO QUERY
	public ArrayList<Procuratore> getProcuratoreNazione(ArrayList<Procuratore> procuratori, String vincoloNazione) throws SQLException
	{
		PreparedStatement prendiProcuratoriNazione = conn.prepareStatement("select * from procuratore natural join persona where nazionalita = ? and codicefiscale = ?");
		
		ricercaAtleta=new AtletaDAOPostgresImpl(conn);
		
		ArrayList<Procuratore> listaProc = new ArrayList<Procuratore>();
		for(Procuratore proc: procuratori)
		{
			prendiProcuratoriNazione.setString(1, vincoloNazione);
			prendiProcuratoriNazione.setString(2, proc.getCodiceFiscale() );
			ResultSet rs = prendiProcuratoriNazione.executeQuery();
			while(rs.next())
			{
				Procuratore p = new Procuratore();
				p.setCodiceFiscale(rs.getString("codicefiscale"));
				p.setNome(rs.getString("nome"));
				p.setCognome(rs.getString("cognome"));
				p.setEmail(rs.getString("email"));
				p.setCittaDiNascita(rs.getString("cittadinascita"));
				p.setDataDiNascita(rs.getDate("datadinascita"));
				p.setTotaleGuadagni(rs.getDouble("totaleguadagni"));
				p.setNazionalita(rs.getString("nazionalita"));
				p.setAtleti(ricercaAtleta.getAtletiProcuratore(p));
				p.setPercentualeGettone(rs.getDouble("percentualegettone"));
				p.setSesso(rs.getString("sesso"));
				listaProc.add(p);
				
			}
			rs.close();
		}
		
		return listaProc;
	}
	
	public ArrayList<Procuratore> getAllProcuratore() throws SQLException
	{
		PreparedStatement prenditTuttiProcuratori = conn.prepareStatement("select * from procuratore natural join persona");
		ricercaAtleta=new AtletaDAOPostgresImpl(conn);
		ArrayList<Procuratore> lista = new ArrayList<Procuratore>();
		ResultSet rs= prenditTuttiProcuratori.executeQuery();
		while(rs.next())
		{
			Procuratore p = new Procuratore();
			p.setCodiceFiscale(rs.getString("codicefiscale"));
			p.setNome(rs.getString("nome"));
			p.setCognome(rs.getString("cognome"));
			p.setEmail(rs.getString("email"));
			p.setCittaDiNascita(rs.getString("cittadinascita"));
			p.setDataDiNascita(rs.getDate("datadinascita"));
			p.setTotaleGuadagni(rs.getDouble("totaleguadagni"));
			p.setNazionalita(rs.getString("nazionalita"));
			p.setPercentualeGettone(rs.getDouble("percentualegettone"));
			p.setSesso(rs.getString("sesso"));
			p.setAtleti(ricercaAtleta.getAtletiProcuratore(p));
			lista.add(p);
		}
		return lista;
	}
	
	public void insertProcuratore(Procuratore procuratore) throws SQLException
	{
		PreparedStatement inserisciProcuratore = conn.prepareStatement("insert into procuratore(codicefiscale,percentualegettone) values (?,?)");

		inserisciProcuratore.setString(1, procuratore.getCodiceFiscale().toUpperCase());
		inserisciProcuratore.setDouble(2, procuratore.getPercentualeGettone());
		int i = inserisciProcuratore.executeUpdate();
	}

	


	@Override
	public void eliminaProcuratore(Procuratore proc) throws SQLException {
		
		PreparedStatement deletePersona = conn.prepareStatement("delete from persona where codicefiscale = ? ");

		deletePersona.setString(1, proc.getCodiceFiscale());
		int i = deletePersona.executeUpdate();
		
	}

	//q
	@Override
	public void eliminaCompensoContratto(Contratto contratto) throws SQLException {
		PreparedStatement deleteCompensoContratto = conn.prepareStatement("update procuratore set totaleguadagni = totaleguadagni - 							? where codicefiscale = ?");

		double guadagnoProcuratore = (contratto.getPercentualeProcuratore()/100) * contratto.getCompenso();
		deleteCompensoContratto.setDouble(1, guadagnoProcuratore);
		deleteCompensoContratto.setString(2, contratto.getAtleta().getProcuratore().getCodiceFiscale());
		int i = deleteCompensoContratto.executeUpdate();
		
	}


	@Override
	public String getNumeroDiAtleti(Procuratore p) throws SQLException {
		PreparedStatement prendiNumeroAtleti= conn.prepareStatement("select count (codiceatleta) as numero from atleta where 		codiceprocuratore= ?  ");
		
		
		int codiceProcuratore = 0;
		PreparedStatement stmt = conn.prepareStatement("select codiceprocuratore from procuratore where codicefiscale = ?");
		
		stmt.setString(1, p.getCodiceFiscale());
		ResultSet prendiCodice = stmt.executeQuery();
		if(prendiCodice.next()) codiceProcuratore = prendiCodice.getInt("codiceprocuratore");
		
		prendiNumeroAtleti.setInt(1, codiceProcuratore);
		ResultSet rs = prendiNumeroAtleti.executeQuery();
		String numero = "";
		while(rs.next())
		{
			numero = String.valueOf(rs.getInt("numero"));
		}
		return numero;
	}


	@Override
	public String getNumeroDiContratti(Procuratore p) throws SQLException {
		PreparedStatement prendiNumeroContratti = conn.prepareStatement("select count(c.codicecontratto) as numero from atleta a 			join contratto c on a.codiceatleta=c.codiceatleta where a.codiceprocuratore= ?");
		
		int codiceProcuratore = 0;
		PreparedStatement stmt = conn.prepareStatement("select codiceprocuratore from procuratore where codicefiscale = ?");
		
		stmt.setString(1, p.getCodiceFiscale());
		ResultSet prendiCodice = stmt.executeQuery();
		if(prendiCodice.next()) codiceProcuratore = prendiCodice.getInt("codiceprocuratore");
		
		
		prendiNumeroContratti.setInt(1, codiceProcuratore);
		ResultSet rs = prendiNumeroContratti.executeQuery();
		String numero = "";
		while(rs.next())
		{
			numero = String.valueOf(rs.getInt("numero"));
		}
		return numero;
	}


	@Override
	public ArrayList<String> getContrattiMigliori(Procuratore p) throws SQLException {
		PreparedStatement prendiContrattiRemunerativi=conn.prepareStatement("select * from procuratore_compenso_codice where 			codiceprocuratore= ?");


		int codiceProcuratore = 0;
		PreparedStatement stmt = conn.prepareStatement("select codiceprocuratore from procuratore where codicefiscale = ?");
		
		stmt.setString(1, p.getCodiceFiscale());
		ResultSet prendiCodice = stmt.executeQuery();
		if(prendiCodice.next()) codiceProcuratore = prendiCodice.getInt("codiceprocuratore");
		
		
		
		prendiContrattiRemunerativi.setInt(1, codiceProcuratore);
		ResultSet rs = prendiContrattiRemunerativi.executeQuery();
		String stringa="Codici : ";
		ArrayList<String> stringhe = new ArrayList<String>();
		while(rs.next())
		{
			stringa+=String.valueOf(rs.getInt("codicecontratto"));
			stringa+="  ";
			if(rs.isLast())
			{
				stringa+="   Compenso: ";
				stringa+=String.valueOf(rs.getDouble("maxcontratto"));
				
			}
			
		}
		stringhe.add(stringa);
		return stringhe;
	}


	@Override
	public ArrayList<String> getClubMigliori(Procuratore p) throws SQLException {
		
		PreparedStatement prendiClubRemunerativi=conn.prepareStatement("select * from club_migliore_codice where codiceprocuratore= 			?");
		
		int codiceProcuratore = 0;
		PreparedStatement stmt = conn.prepareStatement("select codiceprocuratore from procuratore where codicefiscale = ?");
		
		stmt.setString(1, p.getCodiceFiscale());
		ResultSet prendiCodice = stmt.executeQuery();
		if(prendiCodice.next()) codiceProcuratore = prendiCodice.getInt("codiceprocuratore");
		
		
		
		prendiClubRemunerativi.setInt(1, codiceProcuratore);
		ResultSet rs = prendiClubRemunerativi.executeQuery();
		String stringa="Nomi Club : ";
		ArrayList<String> stringhe = new ArrayList<String>();
		while(rs.next())
		{
			stringa+=rs.getString("nomeclub");
			stringa+="  ";
			if(rs.isLast())
			{
				stringa+="   Compenso: ";
				stringa+=String.valueOf(rs.getDouble("sommacompensi"));
				
			}
			
		}
		stringhe.add(stringa);
		return stringhe;
		
	}


	@Override
	public ArrayList<String> getSponsorMigliori(Procuratore p) throws SQLException {
		PreparedStatement prendiSponsorRemunerativi = conn.prepareStatement("select * from sponsor_migliore_codice where 			codiceprocuratore = ?");

		
		int codiceProcuratore = 0;
		PreparedStatement stmt = conn.prepareStatement("select codiceprocuratore from procuratore where codicefiscale = ?");
		
		stmt.setString(1, p.getCodiceFiscale());
		ResultSet prendiCodice = stmt.executeQuery();
		if(prendiCodice.next()) codiceProcuratore = prendiCodice.getInt("codiceprocuratore");
				
		
		prendiSponsorRemunerativi.setInt(1, codiceProcuratore);
		ResultSet rs = prendiSponsorRemunerativi.executeQuery();
		String stringa = "Nomi Sponsor : ";
		ArrayList<String> stringhe = new ArrayList<String>();
		while(rs.next())
		{
			//LA colonna si chiama nomeclub per errore
			stringa += rs.getString("nomeclub");
			stringa += "  ";
			if(rs.isLast())
			{
				stringa+="   Compenso: ";
				stringa+=String.valueOf(rs.getDouble("sommacompensi"));
				
			}
			
		}
		stringhe.add(stringa);
		return stringhe;
	}

	@Override
	public ArrayList<String> getAtletiMigliori(Procuratore p) throws SQLException {
		PreparedStatement prendiAtletiRemunerativi = conn.prepareStatement("select * from atleta_migliore_nome where 			codiceprocuratore= ?");
		
		int codiceProcuratore = 0;
		PreparedStatement stmt = conn.prepareStatement("select codiceprocuratore from procuratore where codicefiscale = ?");
		stmt.setString(1, p.getCodiceFiscale());
		ResultSet prendiCodice = stmt.executeQuery();
		
		if(prendiCodice.next()) codiceProcuratore = prendiCodice.getInt("codiceprocuratore");
		
		prendiAtletiRemunerativi.setInt(1, codiceProcuratore);
		ResultSet rs = prendiAtletiRemunerativi.executeQuery();
		String stringa="Nomi Atleti : ";
		ArrayList<String> stringhe = new ArrayList<String>();
		while(rs.next())
		{
			//LA colonna si chiama nomeclub per errore
			stringa += rs.getString("nome");
			stringa += "  ";
			stringa += rs.getString("cognome");
			stringa += "  ";
			if(rs.isLast())
			{
				stringa += "   Compenso: ";
				stringa += String.valueOf(rs.getDouble("sommacompensi"));
				
			}
			
		}
		stringhe.add(stringa);
		return stringhe;
	}


	@Override
	public Procuratore getProcuratoreAtleta(String string) throws SQLException {
		ricercaAtleta = new AtletaDAOPostgresImpl(conn);
		Procuratore p = new Procuratore();
		PreparedStatement getProcu = conn.prepareStatement("select p.codicefiscale as codicefiscale,pp.nome as nome,pp.cognome as cognome, pp.email as email, pp.cittadinascita as cittadinascita,pp.datadinascita as datadinascita,p.totaleguadagni as totaleguadagni, pp.nazionalita as nazionalita,p.percentualegettone as percentualegettone,pp.sesso as sesso from procuratore p join atleta a on p.codiceprocuratore=a.codiceprocuratore join persona pp on p.codicefiscale = pp.codicefiscale where a.codicefiscale = ? ");
		getProcu.setString(1, string);
		
		ResultSet rs = getProcu.executeQuery();
		
		while(rs.next()) {
			
			p.setCodiceFiscale(rs.getString("codicefiscale"));
			p.setNome(rs.getString("nome"));
			p.setCognome(rs.getString("cognome"));
			p.setEmail(rs.getString("email"));
			p.setCittaDiNascita(rs.getString("cittadinascita"));
			p.setDataDiNascita(rs.getDate("datadinascita"));
			p.setTotaleGuadagni(rs.getDouble("totaleguadagni"));
			p.setNazionalita(rs.getString("nazionalita"));
			p.setPercentualeGettone(rs.getDouble("percentualegettone"));
			p.setSesso(rs.getString("sesso"));
			p.setAtleti(ricercaAtleta.getAtletiProcuratore(p));
			
		}
		
		return p;
	}

	
}
