package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import controller.Controller;
import daos.AtletaDAO;
import entity.Atleta;
import entity.Nazionale;
import entity.Procuratore;
import postegresImpl.AtletaDAOPostgresImpl;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

public class FrameAtleta extends JFrame {

	
	//ELEMENTI INTERFACCIA
	private JPanel contentPane;
	private JPanel menuNazioniPanel;
	private JScrollPane nazioniScrollPane;
	private JPanel panel_1;
	private JPanel bottoniNazionaliPanel;
	private JPanel leftMenuNazioniPanel;
	private JPanel upPanel;
	private GridBagConstraints gbcElement;
	private JButton buttonOperazione;
	private JLabel labelDatoAtleta;
	private GridBagLayout gbl_personePanel;
	private JPanel mainPanel;
	private JPanel personePanel;
	private JScrollPane listaScrollPane;
	private JLabel copyrightLabel;
	private JButton toProcuratoriButton;
	private JButton toAtletiButton;
	private JButton toClubButton;
	private JButton toSponsorButton;
	private JButton toContrattiButton;
	private JButton toStatisticheProcuratoriButton;
	private GridBagLayout gbl_bottoniNazionaliPanel;
	private JButton toFrameNazionaleButton;
	private JLabel nomeProcuratoreLabel;
	
	
	
	//VINCOLI
	private String vincoloNazione;
	private String vincoloOrdine;
	
	//UTILI
	
	private Controller theController;
	


	
	public FrameAtleta(Controller theController, String vincoloNazione, String vincoloOrdine,
						ArrayList<Atleta> atleti, ArrayList<Nazionale> nazioni, Procuratore proc,AtletaDAO ricercaAtleta)
	{
		setMinimumSize(new Dimension(1280, 720));
		setExtendedState(JFrame.MAXIMIZED_BOTH); //SCHERMO INTERO
		
		//setMinimumSize(new Dimension(900, 500));
		setTitle("Atleti");
		
		//ASSEGNAMENTI ATTRIBUTI
		
		this.theController = theController;
		this.vincoloNazione = vincoloNazione;
		this.vincoloOrdine = vincoloOrdine;
		
		//FINE ASSEGNAMENTI
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		menuNazioniPanel = new JPanel();
		menuNazioniPanel.setPreferredSize(new Dimension(134, 10));
		contentPane.add(menuNazioniPanel, BorderLayout.WEST);
		menuNazioniPanel.setLayout(new BorderLayout(0, 0));
		
		nazioniScrollPane = new JScrollPane();
		menuNazioniPanel.add(nazioniScrollPane, BorderLayout.CENTER);
		
		panel_1 = new JPanel();
		panel_1.setForeground(Color.BLACK);
		panel_1.setPreferredSize(new Dimension(10, 39));
		panel_1.setBackground(Color.GRAY);
		contentPane.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(null);
		
		copyrightLabel = new JLabel("\u00AE2020 Raimo Vessella. All Right Reserved ");
		copyrightLabel.setForeground(Color.WHITE);
		copyrightLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		copyrightLabel.setBounds(10, 11, 298, 14);
		panel_1.add(copyrightLabel);
		
		bottoniNazionaliPanel = new JPanel();
		nazioniScrollPane.setViewportView(bottoniNazionaliPanel);
	
		gbl_bottoniNazionaliPanel = new GridBagLayout();
		gbl_bottoniNazionaliPanel.columnWidths = new int[]{0};
		gbl_bottoniNazionaliPanel.rowHeights = new int[]{0};
		gbl_bottoniNazionaliPanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_bottoniNazionaliPanel.rowWeights = new double[]{Double.MIN_VALUE};
		bottoniNazionaliPanel.setLayout(gbl_bottoniNazionaliPanel);
		
		leftMenuNazioniPanel = new JPanel();
		leftMenuNazioniPanel.setBackground(Color.GRAY);
		menuNazioniPanel.add(leftMenuNazioniPanel, BorderLayout.WEST);
		
		upPanel = new JPanel();
		upPanel.setPreferredSize(new Dimension(10, 35));
		upPanel.setBackground(Color.GRAY);
		contentPane.add(upPanel, BorderLayout.NORTH);
		upPanel.setLayout(null);
		
		toProcuratoriButton = new JButton("");
		toProcuratoriButton.setToolTipText("Procuratori");
		toProcuratoriButton.setBackground(new Color(255, 255, 255));
		toProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameProcuratore(FrameAtleta.this, null, null);
			}
		});
		toProcuratoriButton.setIcon(new ImageIcon("icone/businessman.png"));
		toProcuratoriButton.setFocusPainted(false);
		toProcuratoriButton.setBorderPainted(false);
		toProcuratoriButton.setBounds(12, 2, 33, 33);
		upPanel.add(toProcuratoriButton);
		
		toAtletiButton = new JButton("");
		toAtletiButton.setToolTipText("Atleti");
		toAtletiButton.setBackground(new Color(255, 255, 255));
		toAtletiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameAtleta(FrameAtleta.this, null, null,null);
			}
		});
		toAtletiButton.setIcon(new ImageIcon("icone/football-player.png"));
		toAtletiButton.setFocusPainted(false);
		toAtletiButton.setBorderPainted(false);
		toAtletiButton.setBounds(47, 2, 33, 33);
		upPanel.add(toAtletiButton);
		
		toClubButton = new JButton("");
		toClubButton.setToolTipText("Club");
		toClubButton.setBackground(new Color(255, 255, 255));
		toClubButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameClub(FrameAtleta.this,null,null);
			}
		});
		toClubButton.setIcon(new ImageIcon("icone/football-club.png"));
		toClubButton.setFocusPainted(false);
		toClubButton.setBorderPainted(false);
		toClubButton.setBounds(82, 2, 33, 33);
		upPanel.add(toClubButton);
		
		toSponsorButton = new JButton("");
		toSponsorButton.setToolTipText("Sponsor");
		toSponsorButton.setBackground(new Color(255, 255, 255));
		toSponsorButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameSponsor(FrameAtleta.this, null,null);
			}
		});
		toSponsorButton.setIcon(new ImageIcon("icone/nike.png"));
		toSponsorButton.setFocusPainted(false);
		toSponsorButton.setBorderPainted(false);
		toSponsorButton.setBounds(117, 2, 33, 33);
		upPanel.add(toSponsorButton);
		
		toContrattiButton = new JButton("");
		toContrattiButton.setToolTipText("Contratti");
		toContrattiButton.setBackground(new Color(255, 255, 255));
		toContrattiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameContratto(FrameAtleta.this, null, null, null,null);
			}
		});
		toContrattiButton.setIcon(new ImageIcon("icone/contract.png"));
		toContrattiButton.setFocusPainted(false);
		toContrattiButton.setBorderPainted(false);
		toContrattiButton.setBounds(152, 2, 33, 33);
		upPanel.add(toContrattiButton);
		
		toStatisticheProcuratoriButton = new JButton("");
		toStatisticheProcuratoriButton.setToolTipText("Statistiche Procuratori");
		toStatisticheProcuratoriButton.setBackground(new Color(255, 255, 255));
		toStatisticheProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameStatisticheProcuratore(FrameAtleta.this,null);
			}
		});
		toStatisticheProcuratoriButton.setIcon(new ImageIcon("icone/presentation.png"));
		toStatisticheProcuratoriButton.setFocusPainted(false);
		toStatisticheProcuratoriButton.setBorderPainted(false);
		toStatisticheProcuratoriButton.setBounds(187, 2, 33, 33);
		upPanel.add(toStatisticheProcuratoriButton);
		
		toFrameNazionaleButton = new JButton("");
		toFrameNazionaleButton.setToolTipText("Gestione Nazionali");
		toFrameNazionaleButton.setBackground(new Color(255, 255, 255));
		toFrameNazionaleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameNazionale(FrameAtleta.this,null);
			}
		});
		toFrameNazionaleButton.setIcon(new ImageIcon("icone/location.png"));
		toFrameNazionaleButton.setFocusPainted(false);
		toFrameNazionaleButton.setBorderPainted(false);
		toFrameNazionaleButton.setBounds(222, 2, 33, 33);
		upPanel.add(toFrameNazionaleButton);
		
		nomeProcuratoreLabel = new JLabel("");
		nomeProcuratoreLabel.setHorizontalAlignment(SwingConstants.CENTER);
		nomeProcuratoreLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		nomeProcuratoreLabel.setBounds(282, 0, 320, 35);
		
		if(proc == null)
			nomeProcuratoreLabel.setVisible(false);
		else
			nomeProcuratoreLabel.setText("PROCURATORE " + proc.getNome() + " " + proc.getCognome());
		upPanel.add(nomeProcuratoreLabel);
		
		mainPanel = new JPanel();
		contentPane.add(mainPanel, BorderLayout.CENTER);
		mainPanel.setLayout(new BorderLayout(0, 0));
		
		listaScrollPane = new JScrollPane();
		mainPanel.add(listaScrollPane, BorderLayout.CENTER);
		
		personePanel = new JPanel();
		personePanel.setBackground(new Color(192, 192, 192));
		listaScrollPane.setViewportView(personePanel);
		
		gbl_personePanel = new GridBagLayout();
		gbl_personePanel.columnWidths = new int[]{0};
		gbl_personePanel.rowHeights = new int[]{0};
		gbl_personePanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_personePanel.rowWeights = new double[]{Double.MIN_VALUE};
		personePanel.setLayout(gbl_personePanel);
		
		
		//FUNZIONI
		creaBottoniNazionale(bottoniNazionaliPanel,proc,nazioni);
		creaBottoniTabella(personePanel,proc);
		creaTabellaAtleti(personePanel,atleti,proc,ricercaAtleta);
		
		//FINE FUNZIONI
		
	}
	
	public void creaTabellaAtleti(JPanel personePanel,ArrayList<Atleta >atleti,Procuratore proc,AtletaDAO ricercaAtleta)
	{
		
		
		int countery = 1;
		for(Atleta atl : atleti)
		{		
			gbcElement = new GridBagConstraints();
 
			labelDatoAtleta = new JLabel(atl.getNome());
			labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 1;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty= 0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	
	        
	        labelDatoAtleta = new JLabel(atl.getCognome());
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 2;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	        
	        labelDatoAtleta = new JLabel(atl.getCodiceFiscale());
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 3;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	        
	        labelDatoAtleta = new JLabel(atl.getDataDiNascita().toString());
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 4;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	             
	        
	        labelDatoAtleta = new JLabel(atl.getCittaDiNascita());
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 5;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	        
	        
	        labelDatoAtleta = new JLabel(atl.getNazionalita());
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 6;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	         
	        
	        labelDatoAtleta = new JLabel(atl.getEmail());
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 7;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	        
	        labelDatoAtleta = new JLabel(atl.getRuolo());
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 8;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty = 0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	        
	        labelDatoAtleta = new JLabel(Double.toString(atl.getTotaleGuadagni()) + "�");
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 9;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	        
	        labelDatoAtleta = new JLabel(atl.getSesso());
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 10;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty = 0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	        
	        labelDatoAtleta = new JLabel(String.valueOf(atl.getPartiteGiocateNazionale()));
	        labelDatoAtleta.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	        labelDatoAtleta.setHorizontalAlignment(SwingConstants.CENTER);
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 11;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(labelDatoAtleta, gbcElement);
	        
	        buttonOperazione = new JButton("...");
	        buttonOperazione.setFont(new Font("Tahoma", Font.BOLD, 11));
	        buttonOperazione.setToolTipText("Visualizza contratti");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						theController.toFrameContratto(FrameAtleta.this, null, null, null, atl);
				}
			});
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 12;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(buttonOperazione, gbcElement);
	        
	        buttonOperazione = null;
	        buttonOperazione = new JButton("X");
	        buttonOperazione.setFont(new Font("Tahoma", Font.BOLD, 11));
	        buttonOperazione.setToolTipText("Elimina Atleta");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int i = JOptionPane.showConfirmDialog(null, "Questo causer� la cancellazione dell'alteta, procedere?", "Eliminazione", JOptionPane.YES_NO_OPTION);
					if(i == JOptionPane.YES_OPTION) {
						theController.toEliminaAtleta(FrameAtleta.this,atl);
					}
						
				}
			});
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 13;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(buttonOperazione, gbcElement);
	        
	        buttonOperazione = null;
	        buttonOperazione = new JButton("GIOCA PARTITA");
	        buttonOperazione.setFont(new Font("Tahoma", Font.BOLD, 11));
	        buttonOperazione.setToolTipText("Gioca partita in nazionale");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						//TODO
						try {
							ricercaAtleta.giocaPartita(atl);
							theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, vincoloOrdine, proc);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				}
			});
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 14;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        personePanel.add(buttonOperazione, gbcElement);
	        
	        //BUGORIZZONTALE
			JLabel lbl = new JLabel();
	        GridBagConstraints gbc_btn = new GridBagConstraints();
	        lbl.setHorizontalAlignment(SwingConstants.CENTER);
	        gbc_btn.insets = new Insets(0, 0, 0, 0);
	        gbc_btn.gridx = 14;
	        gbc_btn.gridy = countery;
	        gbc_btn.fill = GridBagConstraints.BOTH;
	        gbc_btn.weightx=1;
	        personePanel.add(lbl, gbc_btn);
	        //FINE BUG
	        
	        countery++;	        	        
		}
		
		
		
		//BOTTONE INSERIMENTO
		//Il bottone viene inserito solamente se il frame � associato a un procuratore
		if(proc != null)
		{
			buttonOperazione = new JButton("INSERISCI NUOVO ATLETA");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						try {
							theController.toInserisciAtletaFrame(FrameAtleta.this, proc);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				}
			});
			
			buttonOperazione.addMouseListener(new MouseAdapter() {
				public void mouseEntered(MouseEvent e) {
					buttonOperazione.setBackground(Color.CYAN);
				}
				public void mouseExited(MouseEvent e) {
					buttonOperazione.setBackground(new Color(252,163,17));
				}
			});

			buttonOperazione.setFont(new Font("Tahoma", Font.BOLD, 12));
			buttonOperazione.setFocusPainted(false) ;
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.gridwidth = 12;
	        gbcElement.weighty = 0;
	        countery ++;
	        personePanel.add(buttonOperazione, gbcElement);
		}
		
		
        //BUGVERTICALE
		JLabel lbl = new JLabel();
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 0, 0);
        gbcElement.gridx = 0;
        gbcElement.gridy = countery;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 1;
        gbcElement.gridwidth = 10;
        personePanel.add(lbl, gbcElement);
        //FINE BUG
		//
        
	}
	
	private void creaBottoniTabella(JPanel personePanel,Procuratore proc)
	{
		

        buttonOperazione = new JButton("NOME");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "nome_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione,"nome_crescente",proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione,"nome_decrescente",proc);

			}
		});
		gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 1;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("COGNOME");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "cognome_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione,"cognome_crescente",proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione,"cognome_decrescente",proc);
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 2;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("CODICE FISCALE");
        buttonOperazione.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseEntered(MouseEvent e) {
        	}
        });
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "cf_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione,"cf_crescente", proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione,"cf_decrescente", proc);
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 3;
        gbcElement.gridy =0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("DATA DI NASCITA");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "nascita_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione,"nascita_crescente", proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione,"nascita_decrescente",proc);
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 4;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        
		buttonOperazione.setFocusPainted(false);
		buttonOperazione = new JButton("CITT� DI NASCITA");
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "citta_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "citta_crescente", proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "citta_decrescente", proc);
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 5;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("NAZIONALIT�");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "nazionalita_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "nazionalita_crescente", proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "nazionalita_decrescente", proc);
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 6;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
       
        
        buttonOperazione = new JButton("EMAIL");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "email_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "email_crescente", proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "email_decrescente", proc);
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 7;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("RUOLO");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "ruolo_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "ruolo_crescente", proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "ruolo_decrescente", proc);
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 8;
        gbcElement.gridy =0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
 
        
        buttonOperazione = new JButton("TOTALE GUADAGNI");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "guadagno_crescente")
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "guadagno_crescente", proc);
				else
					theController.toFrameAtleta(FrameAtleta.this, vincoloNazione, "guadagno_decrescente", proc);
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 9;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty= 0;
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("SESSO");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 10;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 0;
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("PARTITE IN NAZIONALE");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 11;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 0;
        personePanel.add(buttonOperazione, gbcElement);
        
        
        //BUGORIZZONTALE
		JLabel lbl = new JLabel();
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 0, 0);
        gbcElement.gridx = 12;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weightx = 1;
        gbcElement.weighty = 0;
        personePanel.add(lbl, gbcElement);
        //FINE BUG
		
	}
	
	public void creaBottoniNazionale(JPanel bottoniNazionaliPanel,Procuratore proc,ArrayList<Nazionale> nazioni)
	{
		//CREAZIONE BOTTONI NAZIONE
			int counter = 0;
			for(Nazionale nazione : nazioni)
			{
				buttonOperazione = new JButton(nazione.getNome());
				buttonOperazione.setFocusPainted(false);
				buttonOperazione.setBackground(new Color(252, 163, 17));
				buttonOperazione.setBorderPainted(false);
				buttonOperazione.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							theController.toFrameAtleta(FrameAtleta.this, nazione.getNome(), vincoloOrdine, proc);
					}
				});
		        gbcElement = new GridBagConstraints();
		        gbcElement.insets = new Insets(0, 0, 1, 0);
		        gbcElement.gridx = 0;
		        gbcElement.gridy = counter;
		        gbcElement.fill = GridBagConstraints.BOTH;
		        gbcElement.weighty=0;
		        
		        bottoniNazionaliPanel.add(buttonOperazione, gbcElement);
		        counter++;
			}
			//BOTTONE INSERIMENTO
			buttonOperazione = new JButton("+");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						theController.toInserisciNazionaleFrame(FrameAtleta.this);
				}
			});
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 1, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = counter;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        counter ++;
	        bottoniNazionaliPanel.add(buttonOperazione, gbcElement);
			
	        //BUG
			labelDatoAtleta = new JLabel();
			buttonOperazione.setVisible(true);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 0, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = counter;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty = 1;
	        bottoniNazionaliPanel.add(labelDatoAtleta, gbcElement);
	        //FINE BUG
			//
	}
}
