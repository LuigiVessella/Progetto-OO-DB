package gui;

import java.awt.BorderLayout;
import javax.swing.JOptionPane;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.Controller;
import daos.NazionaleDAO;
import entity.Nazionale;
import postegresImpl.NazionaleDAOPostgresImpl;

import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Cursor;

public class InserisciNazionaleFrame extends JFrame {

	private JPanel contentPane;
	private JTextField nomeTextField;
	private JTextField gettoneTextField;
	private JLabel nomeLabel;
	private JLabel gettoneLabel;
	private JButton inserisciButton;
	private JLabel imageLabel;
	private JButton indietroButton;
	private Controller theController;
	/**
	 * Create the frame.
	 */
	public InserisciNazionaleFrame(Controller theController) {
		this.theController=theController;
		setResizable(false);
		setTitle("Inserimento Nazionale");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		nomeTextField = new JTextField();
		nomeTextField.setBounds(10, 45, 96, 19);
		contentPane.add(nomeTextField);
		nomeTextField.setColumns(10);
		
		gettoneTextField = new JTextField();
		gettoneTextField.setBounds(10, 75, 96, 19);
		contentPane.add(gettoneTextField);
		gettoneTextField.setColumns(10);
		
		nomeLabel = new JLabel("NOME");
		nomeLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		nomeLabel.setBounds(116, 45, 69, 19);
		contentPane.add(nomeLabel);
		
		gettoneLabel = new JLabel("GETTONE");
		gettoneLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		gettoneLabel.setBounds(116, 78, 69, 12);
		contentPane.add(gettoneLabel);
		
		inserisciButton = new JButton("Inserisci");
		inserisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inserisciButton.setBackground(Color.ORANGE);
		inserisciButton.addActionListener(new ActionListener() {
			String nomeNazionale = null;
			double valoreGettone = 0;
			
			public void actionPerformed(ActionEvent arg0) {
				try {
					nomeNazionale = nomeTextField.getText();
					valoreGettone = Double.parseDouble(gettoneTextField.getText());
				}
				catch(NullPointerException e1) {
					JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);
				}
				catch(NumberFormatException e2) {
					JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

				}
				
				Nazionale nuovaNazione = new Nazionale();
				
				if(nuovaNazione.setNazionale(nomeNazionale, valoreGettone))
				{
					try {
						NazionaleDAO inserimento = new NazionaleDAOPostgresImpl(theController.controllerGetConnection());
						inserimento.insertNazionale(nuovaNazione);
						pulisciCaselle();
						JOptionPane.showMessageDialog(null, "Inserimento avvenuto con successo!");
					} catch (SQLException e) {
						JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);
					}
					catch (NumberFormatException e1 ) {
						JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

					}
					catch (NullPointerException e2) {
						JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

					}
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "Inserimento errato, rivedere i valori");
				}
				
			}
		});
		inserisciButton.setFont(new Font("Dialog", Font.BOLD, 13));
		inserisciButton.setBounds(323, 196, 103, 23);
		contentPane.add(inserisciButton);
		
		indietroButton = new JButton("Indietro");
		indietroButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		indietroButton.setBackground(Color.ORANGE);
		indietroButton.setFont(new Font("Dialog", Font.BOLD, 13));
		indietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameProcuratore(InserisciNazionaleFrame.this, null, null);
			}
		});
		indietroButton.setBounds(10, 196, 89, 23);
		contentPane.add(indietroButton);
		
		ImageIcon image = new ImageIcon("icone\\flag128.png");
		imageLabel = new JLabel(image);	
		imageLabel.setToolTipText("La nazionale");
		imageLabel.setBounds(283, 23, 128, 128);
		contentPane.add(imageLabel);
	}
	
	
	public void pulisciCaselle() {	
		nomeTextField.setText("");
		gettoneTextField.setText("");
	}
}
