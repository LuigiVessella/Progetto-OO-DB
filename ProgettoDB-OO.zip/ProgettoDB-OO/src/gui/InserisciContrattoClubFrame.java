package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.postgresql.util.PSQLException;

import controller.Controller;
import daos.ContrattoDAO;
import daos.SponsorDAO;
import entity.Atleta;
import entity.Club;
import entity.Contratto;
import postegresImpl.ContrattoDAOPostgresImpl;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class InserisciContrattoClubFrame extends JFrame {

	private JPanel contentPane;
	private JTextField inizioContrattoTextField;
	private JTextField fineContrattoTextField;
	private JTextField compensoTextField;
	private JTextField percProcuratoreTextField;
	private JComboBox clubComboBox;
	private JLabel inizioContrattoLabel;
	private JLabel fineContrattoLabel;
	private JLabel compensoLabel;
	private JLabel percentualeLabel;
	private JLabel clubLabel;
	private JButton inserisciButton;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel imageLabel;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JButton indietroButton;
	private ImageIcon image;
	private Controller theController;

	/**
	 * Create the frame.
	 */
	public InserisciContrattoClubFrame(Controller theController, ArrayList<Club> clubs, Atleta atleta) {
		this.theController=theController;
		setResizable(false);
		setTitle("Inserimento Contratto Club");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 663, 412);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		inizioContrattoLabel = new JLabel("INIZIO CONTRATTO");
		inizioContrattoLabel.setBounds(125, 64, 123, 16);
		inizioContrattoLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		contentPane.add(inizioContrattoLabel);
		
		fineContrattoLabel = new JLabel("FINE CONTRATTO");
		fineContrattoLabel.setBounds(125, 103, 123, 16);
		fineContrattoLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		contentPane.add(fineContrattoLabel);
		
		compensoLabel = new JLabel("COMPENSO");
		compensoLabel.setBounds(125, 183, 96, 16);
		compensoLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		contentPane.add(compensoLabel);
		
		percentualeLabel = new JLabel("PERCENTUALE PROCURATORE");
		percentualeLabel.setBounds(125, 142, 192, 16);
		percentualeLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		contentPane.add(percentualeLabel);
		
		inizioContrattoTextField = new JTextField();
		inizioContrattoTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				fineContrattoTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(inizioContrattoTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		inizioContrattoTextField.setBounds(8, 64, 96, 19);
		inizioContrattoTextField.setToolTipText("Inizio contratto");
		contentPane.add(inizioContrattoTextField);
		inizioContrattoTextField.setColumns(10);
		
		fineContrattoTextField = new JTextField();
		fineContrattoTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				percProcuratoreTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(fineContrattoTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		fineContrattoTextField.setEditable(false);
		fineContrattoTextField.setBounds(8, 103, 96, 19);
		contentPane.add(fineContrattoTextField);
		fineContrattoTextField.setColumns(10);
		
		compensoTextField = new JTextField();
		compensoTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				inserisciButton.setEnabled(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(compensoTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		compensoTextField.setEditable(false);
		compensoTextField.setBounds(8, 180, 96, 19);
		contentPane.add(compensoTextField);
		compensoTextField.setColumns(10);
		
		percProcuratoreTextField = new JTextField();
		percProcuratoreTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				compensoTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(percProcuratoreTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		percProcuratoreTextField.setEditable(false);
		percProcuratoreTextField.setBounds(8, 142, 96, 19);
		contentPane.add(percProcuratoreTextField);
		percProcuratoreTextField.setColumns(10);
		ArrayList<String> nomiClub = new ArrayList<String>();
		for(Club club: clubs) {
			nomiClub.add(club.getNome());
		}
		
		clubLabel = new JLabel("Club:");
		clubLabel.setBounds(410, 64, 42, 16);
		clubLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		contentPane.add(clubLabel);
		clubComboBox = new JComboBox(nomiClub.toArray());
		clubComboBox.setBounds(410, 89, 96, 21);
		clubComboBox.setSelectedIndex(1);
		clubComboBox.setToolTipText("Club");
		contentPane.add(clubComboBox);
		
		inserisciButton = new JButton("Inserisci");
		inserisciButton.setEnabled(false);
		inserisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inserisciButton.setBackground(Color.ORANGE);
		inserisciButton.setFont(new Font("Dialog", Font.BOLD, 13));
		inserisciButton.setBounds(523, 310, 102, 33);
		inserisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					ContrattoDAO inserisciContrattoClub = new ContrattoDAOPostgresImpl(theController.controllerGetConnection());
					Contratto newClubContratto = new Contratto();
					Date inizioContratto, fineContratto = new Date();
					try {
						inizioContratto = new SimpleDateFormat("yyyy/MM/dd").parse(inizioContrattoTextField.getText().trim());
						fineContratto = new SimpleDateFormat("yyyy/MM/dd").parse(fineContrattoTextField.getText().trim());
						
						if(newClubContratto.setContrattoClub(inizioContratto, fineContratto, Double.parseDouble(compensoTextField.getText().trim()),  Double.parseDouble(percProcuratoreTextField.getText()), atleta, getClubFromClubName(clubComboBox.getSelectedItem().toString(), clubs)) )
							
							{
								inserisciContrattoClub.insertContrattoClub(newClubContratto);
								inserisciContrattoClub.updateAtletaProcuratore(newClubContratto);
								JOptionPane.showMessageDialog(null, "Inserimento avvenuto con successo!");
								pulisciTextBox();
							}
						
					} catch (ParseException e1) {
						JOptionPane.showMessageDialog(null, "Inserimento errato", "errore", JOptionPane.ERROR_MESSAGE);
					}
					
				
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(null, "Ricorda che il contratto non pu� iniziare dopo oggi e deve essere di almeno un anno!", "errore", JOptionPane.ERROR_MESSAGE);
				}

				
				
			}
		});
		contentPane.add(inserisciButton);
		
		lblNewLabel = new JLabel("(yyyy/mm/dd)");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));
		lblNewLabel.setBounds(8, 47, 96, 13);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("(yyyy/mm/dd)");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));
		lblNewLabel_1.setBounds(8, 86, 96, 13);
		contentPane.add(lblNewLabel_1);
		
		image = new ImageIcon("icone\\football-club128.png");
		imageLabel = new JLabel(image);	
		imageLabel.setToolTipText("Il contratto con il club");
		imageLabel.setBounds(396, 142, 128, 128);
		contentPane.add(imageLabel);
		
		panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 659, 21);
		contentPane.add(panel);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(635, 10, 24, 378);
		contentPane.add(panel_1);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(0, 353, 649, 35);
		contentPane.add(panel_2);
		
		indietroButton = new JButton("Indietro");
		indietroButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		indietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				theController.toFrameProcuratore(InserisciContrattoClubFrame.this, null, null);
			}
		});
		indietroButton.setBackground(Color.ORANGE);
		indietroButton.setFont(new Font("Dialog", Font.BOLD, 13));
		indietroButton.setBounds(8, 310, 96, 33);
		contentPane.add(indietroButton) ;
	}
	
	public Club getClubFromClubName (String clubName, ArrayList<Club> clubs){  
		for(Club club : clubs) { 
			if(club.getNome().equals(clubName))
		       return club;
		}
		return null;
	}
	
	public void pulisciTextBox() {
		
		 inizioContrattoTextField.setText("");
		 fineContrattoTextField.setText("");
		 compensoTextField.setText("");
		 percProcuratoreTextField.setText("");
		
	}
		
}
