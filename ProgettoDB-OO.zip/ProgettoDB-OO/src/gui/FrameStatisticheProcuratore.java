package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import controller.Controller;
import daos.ProcuratoreDAO;
import entity.Procuratore;
import postegresImpl.ProcuratoreDAOPostgresImpl;

public class FrameStatisticheProcuratore extends JFrame {

	//ELEMENTI GRAFICI
	private JPanel contentPane;
	private JButton buttonOperazione;
	private JLabel labelDatoStatistica;
	private JPanel menuProcuratoriPanel;
	private JScrollPane procuratoriScrollPane;
	private JPanel bottoniProcuratoriPanel;
	private GridBagLayout gbl_bottoniProcuratoriPanel;
	private JPanel panel_1;
	private JLabel copyrightLabel;
	private JPanel leftMenuProcuratoriPanel;
	private JPanel upPanel;
	private JButton toProcuratoriButton;
	private JButton toAtletiButton;
	private JButton toClubButton;
	private JButton toSponsorButton;
	private JButton toContrattiButton;
	private JButton toStatisticheProcuratoriButton;
	private JButton toFrameNazionaleButton;
	private JPanel mainPanel;
	private JLabel nomeCognomeProcuratoreLabel;
	private GridBagConstraints gbcElement;
	
	
	//UTILI
	private ArrayList<String> risultatoVista;
	private Controller theController;
	
	
	public FrameStatisticheProcuratore(Controller theController, ArrayList<Procuratore> procuratori, Procuratore proc,ProcuratoreDAO ricercaProcuratore) throws SQLException {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setTitle("Statistiche Procuratore");
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		//ASSEGNAMENTI
		this.theController = theController;
		//FINE ASSEGNAMENTI
		
		menuProcuratoriPanel = new JPanel();
		menuProcuratoriPanel.setPreferredSize(new Dimension(200, 10));
		contentPane.add(menuProcuratoriPanel, BorderLayout.WEST);
		menuProcuratoriPanel.setLayout(new BorderLayout(0, 0));
		
		procuratoriScrollPane = new JScrollPane();
		menuProcuratoriPanel.add(procuratoriScrollPane, BorderLayout.CENTER);
		
		bottoniProcuratoriPanel = new JPanel();
		procuratoriScrollPane.setViewportView(bottoniProcuratoriPanel);
		
		gbl_bottoniProcuratoriPanel = new GridBagLayout();
		gbl_bottoniProcuratoriPanel.columnWidths = new int[]{0};
		gbl_bottoniProcuratoriPanel.rowHeights = new int[]{0};
		gbl_bottoniProcuratoriPanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_bottoniProcuratoriPanel.rowWeights = new double[]{Double.MIN_VALUE};
		bottoniProcuratoriPanel.setLayout(gbl_bottoniProcuratoriPanel);
		
		panel_1 = new JPanel();
		panel_1.setForeground(Color.BLACK);
		panel_1.setPreferredSize(new Dimension(10, 39));
		panel_1.setBackground(Color.GRAY);
		contentPane.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(null);
		
		copyrightLabel = new JLabel("\u00AE2020 Raimo Vessella. All Right Reserved ");
		copyrightLabel.setForeground(Color.WHITE);
		copyrightLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		copyrightLabel.setBounds(10, 11, 298, 14);
		panel_1.add(copyrightLabel);
		
		leftMenuProcuratoriPanel = new JPanel();
		leftMenuProcuratoriPanel.setBackground(Color.GRAY);
		menuProcuratoriPanel.add(leftMenuProcuratoriPanel, BorderLayout.WEST);
		
		upPanel = new JPanel();
		upPanel.setPreferredSize(new Dimension(10, 35));
		upPanel.setBackground(Color.GRAY);
		contentPane.add(upPanel, BorderLayout.NORTH);
		upPanel.setLayout(null);
		
		toProcuratoriButton = new JButton("");
		toProcuratoriButton.setToolTipText("Procuratori");
		toProcuratoriButton.setBackground(new Color(255, 255, 255));
		toProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameProcuratore(FrameStatisticheProcuratore.this, null, null);
			}
		});
		toProcuratoriButton.setIcon(new ImageIcon("icone/businessman.png"));
		toProcuratoriButton.setFocusPainted(false);
		toProcuratoriButton.setBorderPainted(false);
		toProcuratoriButton.setBounds(12, 2, 33, 33);
		upPanel.add(toProcuratoriButton);
		
		toAtletiButton = new JButton("");
		toAtletiButton.setToolTipText("Atleti");
		toAtletiButton.setBackground(new Color(255, 255, 255));
		toAtletiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameAtleta(FrameStatisticheProcuratore.this, null, null,null);
			}
		});
		toAtletiButton.setIcon(new ImageIcon("icone/football-player.png"));
		toAtletiButton.setFocusPainted(false);
		toAtletiButton.setBorderPainted(false);
		toAtletiButton.setBounds(47, 2, 33, 33);
		upPanel.add(toAtletiButton);
		
		toClubButton = new JButton("");
		toClubButton.setToolTipText("Club");
		toClubButton.setBackground(new Color(255, 255, 255));
		toClubButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameClub(FrameStatisticheProcuratore.this,null,null);
			}
		});
		toClubButton.setIcon(new ImageIcon("icone/football-club.png"));
		toClubButton.setFocusPainted(false);
		toClubButton.setBorderPainted(false);
		toClubButton.setBounds(82, 2, 33, 33);
		upPanel.add(toClubButton);
		
		toSponsorButton = new JButton("");
		toSponsorButton.setToolTipText("Sponsor");
		toSponsorButton.setBackground(new Color(255, 255, 255));
		toSponsorButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameSponsor(FrameStatisticheProcuratore.this, null,null);
			}
		});
		toSponsorButton.setIcon(new ImageIcon("icone/nike.png"));
		toSponsorButton.setFocusPainted(false);
		toSponsorButton.setBorderPainted(false);
		toSponsorButton.setBounds(117, 2, 33, 33);
		upPanel.add(toSponsorButton);
		
		toContrattiButton = new JButton("");
		toContrattiButton.setToolTipText("Contratti");
		toContrattiButton.setBackground(new Color(255, 255, 255));
		toContrattiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameContratto(FrameStatisticheProcuratore.this, null, null, null,null);
			}
		});
		toContrattiButton.setIcon(new ImageIcon("icone/contract.png"));
		toContrattiButton.setFocusPainted(false);
		toContrattiButton.setBorderPainted(false);
		toContrattiButton.setBounds(152, 2, 33, 33);
		upPanel.add(toContrattiButton);
		
		toStatisticheProcuratoriButton = new JButton("");
		toStatisticheProcuratoriButton.setToolTipText("Statistiche Procuratori");
		toStatisticheProcuratoriButton.setBackground(new Color(255, 255, 255));
		toStatisticheProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameStatisticheProcuratore(FrameStatisticheProcuratore.this,null);
			}
		});
		toStatisticheProcuratoriButton.setIcon(new ImageIcon("icone/presentation.png"));
		toStatisticheProcuratoriButton.setFocusPainted(false);
		toStatisticheProcuratoriButton.setBorderPainted(false);
		toStatisticheProcuratoriButton.setBounds(187, 2, 33, 33);
		upPanel.add(toStatisticheProcuratoriButton);
		
		toFrameNazionaleButton = new JButton("");
		toFrameNazionaleButton.setToolTipText("Gestione Nazionali");
		toFrameNazionaleButton.setBackground(new Color(255, 255, 255));
		toFrameNazionaleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameNazionale(FrameStatisticheProcuratore.this,null);
			}
		});
		toFrameNazionaleButton.setIcon(new ImageIcon("icone/location.png"));
		toFrameNazionaleButton.setFocusPainted(false);
		toFrameNazionaleButton.setBorderPainted(false);
		toFrameNazionaleButton.setBounds(222, 2, 33, 33);
		upPanel.add(toFrameNazionaleButton);
		
		mainPanel = new JPanel();
		mainPanel.setBackground(new Color(192,192,192));
		contentPane.add(mainPanel, BorderLayout.CENTER);
		mainPanel.setLayout(null);
		
		if(proc!= null)
		
		{
			try {
				ricercaProcuratore = new ProcuratoreDAOPostgresImpl(theController.controllerGetConnection());
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
			copyrightLabel = new JLabel("PROCURATORE :");
			copyrightLabel.setBounds(10, 11, 200, 14);
			mainPanel.add(copyrightLabel);
			
			nomeCognomeProcuratoreLabel = new JLabel(proc.getNome() + " " + proc.getCognome() + " " + proc.getCodiceFiscale());
			nomeCognomeProcuratoreLabel.setBounds(300, 11, 300, 14);
			mainPanel.add(nomeCognomeProcuratoreLabel);
			
			copyrightLabel = new JLabel("TOTALE GUADAGNI :");
			copyrightLabel.setBounds(10, 41, 300, 14);
			mainPanel.add(copyrightLabel);
			
			nomeCognomeProcuratoreLabel = new JLabel(String.valueOf(proc.getTotaleGuadagni()));
			nomeCognomeProcuratoreLabel.setBounds(300, 41, 300, 14);
			mainPanel.add(nomeCognomeProcuratoreLabel);
			
			copyrightLabel = new JLabel("NUMERO DI ATLETI :");
			copyrightLabel.setBounds(10, 71, 300, 14);
			mainPanel.add(copyrightLabel);
			
			nomeCognomeProcuratoreLabel = new JLabel(ricercaProcuratore.getNumeroDiAtleti(proc));
			nomeCognomeProcuratoreLabel.setBounds(300, 71, 300, 14);
			mainPanel.add(nomeCognomeProcuratoreLabel);
			
			copyrightLabel = new JLabel("NUMERO DI CONTRATTI STIPULATI :");
			copyrightLabel.setBounds(10, 101, 300, 14);
			mainPanel.add(copyrightLabel);
			
			nomeCognomeProcuratoreLabel = new JLabel(ricercaProcuratore.getNumeroDiContratti(proc));
			nomeCognomeProcuratoreLabel.setBounds(300, 101, 300, 14);
			mainPanel.add(nomeCognomeProcuratoreLabel);
			
			copyrightLabel = new JLabel("CONTRATTI PI� REMUNERATIVI:");
			copyrightLabel.setBounds(10, 131, 300, 14);
			mainPanel.add(copyrightLabel);
			
			risultatoVista = ricercaProcuratore.getContrattiMigliori(proc);
			int counterx = 300;
			for(String stringa : risultatoVista)
			{
				copyrightLabel = new JLabel(stringa);
				copyrightLabel.setBounds(counterx, 131, 400, 14);
				mainPanel.add(copyrightLabel);
				counterx+=250;
			}
			
			copyrightLabel = new JLabel("CLUB PI� REMUNERATIVI:");
			copyrightLabel.setBounds(10, 161, 200, 14);
			mainPanel.add(copyrightLabel);
			
			risultatoVista = ricercaProcuratore.getClubMigliori(proc);
			counterx = 300;
			for(String stringa : risultatoVista)
			{
				copyrightLabel = new JLabel(stringa);
				copyrightLabel.setBounds(counterx, 161, 2000, 14);
				mainPanel.add(copyrightLabel);
				counterx+=250;
			}
			
			copyrightLabel = new JLabel("SPONSOR PI� REMUNERATIVI:");
			copyrightLabel.setBounds(10, 191, 200, 14);
			mainPanel.add(copyrightLabel);
			
			risultatoVista = ricercaProcuratore.getSponsorMigliori(proc);
			counterx = 300;
			for(String stringa : risultatoVista)
			{
				copyrightLabel = new JLabel(stringa);
				copyrightLabel.setBounds(counterx, 191, 2000, 14);
				mainPanel.add(copyrightLabel);
				counterx += 250;
			}
			
			copyrightLabel = new JLabel("ATLETI PI� REMUNERATIVI:");
			copyrightLabel.setBounds(10, 221, 200, 14);
			mainPanel.add(copyrightLabel);
			
			risultatoVista = ricercaProcuratore.getAtletiMigliori(proc);
			counterx = 300;
			for(String stringa : risultatoVista)
			{
				copyrightLabel = new JLabel(stringa);
				copyrightLabel.setBounds(counterx, 221, 2000, 14);
				mainPanel.add(copyrightLabel);
				counterx += 250;
			}
			
			
		}
		else 
		{
			copyrightLabel = new JLabel("CLICCA SU UN PROCURATORE :");
			copyrightLabel.setBounds(10, 11, 300, 14);
			mainPanel.add(copyrightLabel);
		}
			
			
		
		//FUNZIONI
		creaBottoniNazionale(bottoniProcuratoriPanel, procuratori);
	}

	public void creaBottoniNazionale(JPanel bottoniProcuratoriPanel, ArrayList<Procuratore> procuratori)
	{
		//CREAZIONE BOTTONI PROCURATORI
			int counter = 0;
			for(Procuratore p : procuratori)
			{
				buttonOperazione = new JButton(p.getNome()+" "+p.getCognome()+" ");
				buttonOperazione.setFocusPainted(false);
				buttonOperazione.setBackground(new Color(252, 191, 73));
				buttonOperazione.setBorderPainted(false);
				buttonOperazione.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							theController.toFrameStatisticheProcuratore(FrameStatisticheProcuratore.this,p );
					}
				});
				
		        gbcElement = new GridBagConstraints();
		        gbcElement.insets = new Insets(0, 0, 1, 0);
		        gbcElement.gridx = 0;
		        gbcElement.gridy = counter;
		        gbcElement.fill = GridBagConstraints.BOTH;
		        gbcElement.weighty=0;
		        
		        bottoniProcuratoriPanel.add(buttonOperazione, gbcElement);
		        counter++;
			}
			
			
	        //BUG
			labelDatoStatistica = new JLabel();
			buttonOperazione.setVisible(true);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 0, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = counter;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=1;
	        bottoniProcuratoriPanel.add(labelDatoStatistica, gbcElement);
	        //FINE BUG

	}
}
