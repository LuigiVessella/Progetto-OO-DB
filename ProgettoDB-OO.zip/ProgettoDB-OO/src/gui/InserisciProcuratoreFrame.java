package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import codiceFiscale.CodiceFiscale;
import controller.Controller;
import daos.NazionaleDAO;
import daos.PersonaDAO;
import daos.ProcuratoreDAO;
import entity.Persona;
import entity.Procuratore;
import postegresImpl.NazionaleDAOPostgresImpl;
import postegresImpl.PersonaDAOPostgresImpl;
import postegresImpl.ProcuratoreDAOPostgresImpl;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.Color;
import java.awt.Cursor;

public class InserisciProcuratoreFrame extends JFrame {

	private JPanel contentPane;
	private JTextField nomeTextField;
	private JTextField cognomeTextField;
	private JTextField dataDiNascitaTextField;
	private JTextField cittaDiNascitaTextField;
	private JLabel cittaDiNascitaLabel;
	private JTextField domicilioTextField;
	private JTextField emailTextField;
	private JLabel domicilioLabel;
	private JLabel emailLabel;
	private JButton inserisciButton;
	private JButton IndietroButton;
	private JLabel nazionalitaLabel;
	private JLabel cognomeLabel;
	private JLabel dataDiNascitaLabel;
	private JComboBox nazionaleComboBox;
	private JTextField percuntualeGettoneTextField;
	private JLabel gettoneLabel;
	private JRadioButton sessoMaschioRadioButton;
	private JRadioButton sessoFemminaRadioButton;
	private JLabel sessoLabel;
	private JLabel nomeLabel;
	private String sesso = "";
	private String codiceFiscale = "";
	private String luogoNascita = "";
	private JButton codFiscButton;
	private JTextField codiceFiscaleTextField;
	private JButton pulisciButton;
	private JLabel codFiscaleLabel;
	private JLabel imageLabel;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JLabel lblNewLabel;
	private CodiceFiscale c;
	private Controller theController;
	/**
	 * Create the frame.
	 */
	public InserisciProcuratoreFrame(Controller theController,NazionaleDAO getNomiNazioni,PersonaDAO inserimento) {
		this.theController=theController;
		setTitle("Inserimento Procuratore");
		setResizable(false);
		try {
			getNomiNazioni = new NazionaleDAOPostgresImpl(theController.controllerGetConnection());
			
		} catch (SQLException e2) {
			
			JOptionPane.showMessageDialog(null, "Controlla Nazioni!", "Errore", JOptionPane.ERROR_MESSAGE);

		}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 663, 412);
		contentPane = new JPanel() ;
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		nomeTextField = new JTextField();
		nomeTextField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		nomeTextField.setBounds(14, 54, 130, 20);
		contentPane.add(nomeTextField);
		nomeTextField.setColumns(10);
		
		cognomeTextField = new JTextField();
		cognomeTextField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		cognomeTextField.setBounds(14, 85, 130, 20);
		contentPane.add(cognomeTextField);
		cognomeTextField.setColumns(10);
		
		dataDiNascitaTextField = new JTextField("");
		dataDiNascitaTextField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		dataDiNascitaTextField.setBounds(14, 116, 130, 20);
		contentPane.add(dataDiNascitaTextField);
		dataDiNascitaTextField.setColumns(10);
		
		nomeLabel = new JLabel("NOME");
		nomeLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		nomeLabel.setBounds(154, 57, 86, 14);
		contentPane.add(nomeLabel);
		
		cognomeLabel = new JLabel("COGNOME");
		cognomeLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		cognomeLabel.setBounds(154, 88, 86, 14);
		contentPane.add(cognomeLabel);
		
		JLabel dataDiNascitaLabel = new JLabel("DATA DI NASCITA");
		dataDiNascitaLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		dataDiNascitaLabel.setBounds(154, 119, 125, 14);
		contentPane.add(dataDiNascitaLabel);
		
		cittaDiNascitaTextField = new JTextField();
		cittaDiNascitaTextField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		cittaDiNascitaTextField.setBounds(14, 145, 130, 20);
		contentPane.add(cittaDiNascitaTextField);
		cittaDiNascitaTextField.setColumns(10);
		
		cittaDiNascitaLabel = new JLabel("CITTA DI NASCITA");
		cittaDiNascitaLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		cittaDiNascitaLabel.setBounds(154, 148, 125, 14);
		contentPane.add(cittaDiNascitaLabel);
		
		domicilioTextField = new JTextField();
		domicilioTextField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		domicilioTextField.setBounds(14, 179, 130, 20);
		contentPane.add(domicilioTextField);
		domicilioTextField.setColumns(10);
		
		emailTextField = new JTextField("");
		emailTextField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		emailTextField.setBounds(14, 210, 130, 20);
		contentPane.add(emailTextField);
		emailTextField.setColumns(10);
		
		domicilioLabel = new JLabel("DOMICILIO");
		domicilioLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		domicilioLabel.setBounds(154, 182, 86, 14);
		contentPane.add(domicilioLabel);
		
		percuntualeGettoneTextField = new JTextField();
		percuntualeGettoneTextField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		percuntualeGettoneTextField.setBounds(14, 243, 130, 19);
		contentPane.add(percuntualeGettoneTextField);
		percuntualeGettoneTextField.setColumns(10);
		
		gettoneLabel = new JLabel("% GETTONE");
		gettoneLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		gettoneLabel.setBounds(154, 246, 76, 13);
		contentPane.add(gettoneLabel);
		
		emailLabel = new JLabel("EMAIL");
		emailLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		emailLabel.setBounds(154, 213, 46, 14);
		contentPane.add(emailLabel);
		
		inserisciButton = new JButton("Inserisci");
		inserisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inserisciButton.setBackground(Color.ORANGE);
		inserisciButton.setFont(new Font("Dialog", Font.BOLD, 13));
		inserisciButton.setEnabled(false);
		inserisciButton.setBounds(486, 291, 125, 31);
		inserisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(sessoMaschioRadioButton.isSelected()) { 
					sesso = "M";
				
				}
				if(sessoFemminaRadioButton.isSelected()) {
					sesso = "F";
					}
				
				
				String nome = nomeTextField.getText().trim();
				String cognome = cognomeTextField.getText().trim();
				Date dataDiNascita= new Date();
				try {
					dataDiNascita = new SimpleDateFormat("yyyy/MM/dd").parse(dataDiNascitaTextField.getText());
				} catch (ParseException e1) {
					JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

				}
				luogoNascita = cittaDiNascitaTextField.getText().trim();
				String domicilio = domicilioTextField.getText().trim();
				String email = emailTextField.getText().trim();
				double percentualeGettone = Double.parseDouble(percuntualeGettoneTextField.getText());
				String nazionale = nazionaleComboBox.getSelectedItem().toString().trim();
				Persona nuovaPersona = new Persona();
				Procuratore nuovoProcuratore = new Procuratore();
				try {
					if(nuovaPersona.setPersona(codiceFiscale, nome, cognome, dataDiNascita, luogoNascita, domicilio, email, nazionale, sesso) && nuovoProcuratore.setProcuratore(codiceFiscale, percentualeGettone) )
					{
						try {
							
							inserimento.insertPersona(nuovaPersona);
							ProcuratoreDAO inserimentoProcuratore = new ProcuratoreDAOPostgresImpl(theController.controllerGetConnection());
							inserimentoProcuratore.insertProcuratore(nuovoProcuratore);
							JOptionPane.showMessageDialog(null, "Inserimento avvenuto con successo");
							pulisciTextField();
							attivaComponenti();
						} catch (SQLException e1) {
							JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Inserimento errato", "Errore", JOptionPane.ERROR_MESSAGE);
					}
				} catch (HeadlessException e1) {
					JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

				} catch (IOException e1) {
					JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

				}
				
			}
		});
		contentPane.add(inserisciButton);
		
		IndietroButton = new JButton("Indietro");
		IndietroButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		IndietroButton.setBackground(Color.ORANGE);
		IndietroButton.setFont(new Font("Dialog", Font.BOLD, 13));
		IndietroButton.setBounds(14, 288, 108, 31);
		IndietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameProcuratore(InserisciProcuratoreFrame.this,null,null);;
			}
		});
		contentPane.add(IndietroButton);
		
		
		nazionalitaLabel = new JLabel("Nazionalit\u00E0:");
		nazionalitaLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		nazionalitaLabel.setBounds(486, 29, 125, 14);
		contentPane.add(nazionalitaLabel);
		
		try {
			nazionaleComboBox = new JComboBox(getNomiNazioni.getNomeNazionaleString().toArray());
			nazionaleComboBox.setSelectedItem("ITALIA");
			nazionaleComboBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent arg0) {
					if(!nazionaleComboBox.getSelectedItem().toString().trim().equals("ITALIA")) {
						cittaDiNascitaTextField.setEditable(false);
						luogoNascita = nazionaleComboBox.getSelectedItem().toString().trim();
						cittaDiNascitaTextField.setText(luogoNascita);
					}
					else {
						cittaDiNascitaTextField.setText("");
						cittaDiNascitaTextField.setEditable(true);
					}
				}
			});
			nazionaleComboBox.setBounds(486, 60, 115, 31);
			nazionaleComboBox.setFont(new Font("Tahoma", Font.PLAIN, 13));
		} catch (SQLException e1) {
			JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

		}
		
		nazionaleComboBox.setToolTipText("");
		contentPane.add(nazionaleComboBox);
		
		sessoMaschioRadioButton = new JRadioButton("M");
		sessoMaschioRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sessoFemminaRadioButton.setSelected(false);
			}
		});
		sessoMaschioRadioButton.setSelected(true);
		sessoMaschioRadioButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		sessoMaschioRadioButton.setBounds(358, 65, 46, 21);
		contentPane.add(sessoMaschioRadioButton);
		
		sessoFemminaRadioButton = new JRadioButton("F");
		sessoFemminaRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sessoMaschioRadioButton.setSelected(false);

			}
		});
		sessoFemminaRadioButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		sessoFemminaRadioButton.setBounds(298, 65, 45, 21);
		contentPane.add(sessoFemminaRadioButton);
		
		sessoLabel = new JLabel("Sesso:");
		sessoLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		sessoLabel.setBounds(298, 29, 45, 13);
		contentPane.add(sessoLabel);
		
		codFiscButton = new JButton("Calcola CodFiscale");
		codFiscButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		codFiscButton.setBackground(Color.ORANGE);
		codFiscButton.setFont(new Font("Dialog", Font.BOLD, 13));
		codFiscButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				disattivaComponenti();
				if(sessoMaschioRadioButton.isSelected()) { 
					sesso = "m";
				}
				
				if(sessoFemminaRadioButton.isSelected()) {
					sesso = "f";
				}
				
				c = new CodiceFiscale();
				try {
				
					codiceFiscale = c.generaCodiceFiscale(nomeTextField.getText().trim(), cognomeTextField.getText().trim(), dataDiNascitaTextField.getText().trim(), sesso,
							cittaDiNascitaTextField.getText());
					codiceFiscaleTextField.setText(codiceFiscale);
					inserisciButton.setEnabled(true);
				} catch (IOException e) {
					
					JOptionPane.showMessageDialog(null, "Inserisci bene i dati!", "errore", JOptionPane.ERROR_MESSAGE);
					attivaComponenti();
				}
				catch(NullPointerException e1) {
					JOptionPane.showMessageDialog(null, "Inserisci bene i dati!", "errore", JOptionPane.ERROR_MESSAGE);
					attivaComponenti();

				}
				catch(StringIndexOutOfBoundsException e2) {
					JOptionPane.showMessageDialog(null, "Inserisci bene i dati!", "errore", JOptionPane.ERROR_MESSAGE);
					attivaComponenti();
				}
			}
		});
		codFiscButton.setBounds(254, 291, 164, 21);
		contentPane.add(codFiscButton);
		
		codiceFiscaleTextField = new JTextField();
		codiceFiscaleTextField.setEditable(false);
		codiceFiscaleTextField.setColumns(10);
		codiceFiscaleTextField.setBounds(14, 26, 130, 19);
		contentPane.add(codiceFiscaleTextField);
		
		pulisciButton = new JButton("Pulisci");
		pulisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		pulisciButton.setBackground(Color.ORANGE);
		pulisciButton.setFont(new Font("Dialog", Font.BOLD, 13));
		pulisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				codiceFiscaleTextField.setText("");
				attivaComponenti();
			}
		});
		pulisciButton.setBounds(294, 322, 85, 21);
		contentPane.add(pulisciButton);
		
		codFiscaleLabel = new JLabel("CODICE FISCALE");
		codFiscaleLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		codFiscaleLabel.setBounds(154, 29, 101, 13);
		contentPane.add(codFiscaleLabel);
		
		ImageIcon image = new ImageIcon("icone\\businessman128.png");
		imageLabel = new JLabel(image);	
		imageLabel.setToolTipText("Il procuratore");
		imageLabel.setBounds(330, 104, 128, 128);
		contentPane.add(imageLabel);
		
		panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 649, 19);
		contentPane.add(panel);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(621, 0, 28, 388);
		contentPane.add(panel_1);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(0, 353, 649, 35);
		contentPane.add(panel_2);
		
		lblNewLabel = new JLabel("(yyyy/mm/dd)");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));
		lblNewLabel.setBounds(14, 104, 96, 13);
		contentPane.add(lblNewLabel);
	}
	
	public void attivaComponenti() {
		
		inserisciButton.setEnabled(false);
		codiceFiscaleTextField.setText("");
		nomeTextField.setEditable(true);
		cognomeTextField.setEditable(true);
		dataDiNascitaTextField.setEditable(true);
		cittaDiNascitaTextField.setEditable(true);
		domicilioTextField.setEditable(true);
		emailTextField.setEditable(true);
		nazionaleComboBox.setEnabled(true);
		percuntualeGettoneTextField.setEditable(true);
		sessoMaschioRadioButton.setEnabled(true);
		sessoFemminaRadioButton.setEnabled(true);
	}
	
	
	public void pulisciTextField() {
		codiceFiscaleTextField.setText("");
		nomeTextField.setText("");
		cognomeTextField.setText("");
		dataDiNascitaTextField.setText("");
		cittaDiNascitaTextField.setText("");
		domicilioTextField.setText("");
		emailTextField.setText("");
		percuntualeGettoneTextField.setText("");
	}
		
	
	
	public void disattivaComponenti() {
		nomeTextField.setEditable(false);
		cognomeTextField.setEditable(false);
		dataDiNascitaTextField.setEditable(false);
		cittaDiNascitaTextField.setEditable(false);
		domicilioTextField.setEditable(false);
		emailTextField.setEditable(false);
		nazionaleComboBox.setEnabled(false);
		percuntualeGettoneTextField.setEditable(false);
		sessoMaschioRadioButton.setEnabled(false);
		sessoFemminaRadioButton.setEnabled(false);
	}
	

}