package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controller.Controller;
import entity.Atleta;
import entity.Club;
import entity.Contratto;
import entity.Sponsor;

import java.awt.GridLayout;
import java.awt.Insets;



public class FrameContratto extends JFrame {
	
	
	//ELEMENTI GRAFICI
	private JPanel contentPane;
	private JButton buttonOperazione;
	private JLabel labelDatoContratto;
	private JPanel menuClubSponsorPanel;
	private JPanel leftMenuPanel;
	private JPanel panel;	
	private JScrollPane clubScrollPane;
	private JPanel bottoniClubPanel;
	private GridBagLayout gbl_bottoniClubPanel;
	private JScrollPane sponsorScrollPane;
	private JPanel bottoniSponsorPanel;
	private GridBagLayout gbl_bottoniSponsorPanel;
	private JPanel panel_1;
	private JPanel mainPanel;
	private JPanel upPanel;
	private JScrollPane listaScrollPane;
	private JLabel copyrightLabel;
	private JButton toProcuratoriButton;
	private JButton toAtletiButton;
	private JButton toClubButton;
	private JButton toSponsorButton;
	private JButton toContrattiButton;
	private JButton toStatisticheProcuratoriButton;
	private JButton toFrameNazionaleButton;
	private JLabel nomeAtletaLabel;
	private JPanel contrattiPanel;
	private GridBagLayout gbl_contrattiPanel;
	private GridBagConstraints gbcElement;
	
	
	//VINCOLI
	private String vincoloOrdine;
	private String vincoloClub;
	private String vincoloSponsor;
	
	
	//UTILI
	private Controller theController;

	
	
	public FrameContratto(Controller theController, String vincoloOrdine, String vincoloClub, String vincoloSponsor, ArrayList<Contratto> contratti, Atleta atl, 
			ArrayList<Sponsor> sponsorsArray, ArrayList<Club> clubsArray) {
		setBackground(Color.WHITE);
		
		
		setExtendedState(JFrame.MAXIMIZED_BOTH); //SCHERMO INTERO
		//setMinimumSize(new Dimension(900, 500));
		
		setTitle("Contratti");
		//ASSEGNAMENTI ATTRIBUTI

		this.theController = theController;
		this.vincoloClub = vincoloClub;
		this.vincoloOrdine = vincoloOrdine;
		this.vincoloSponsor = vincoloSponsor;

		//FINE ASSEGNAMENTI
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		menuClubSponsorPanel = new JPanel();
		menuClubSponsorPanel.setPreferredSize(new Dimension(134, 10));
		contentPane.add(menuClubSponsorPanel, BorderLayout.WEST);
		menuClubSponsorPanel.setLayout(new BorderLayout(0, 0));
		
		leftMenuPanel = new JPanel();
		leftMenuPanel.setBackground(Color.GRAY);
		menuClubSponsorPanel.add(leftMenuPanel, BorderLayout.WEST);
		
		panel = new JPanel();
		menuClubSponsorPanel.add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(2, 1, 0, 0));
		
		clubScrollPane = new JScrollPane();
		panel.add(clubScrollPane);
		
		bottoniClubPanel = new JPanel();
		clubScrollPane.setViewportView(bottoniClubPanel);
		
		gbl_bottoniClubPanel = new GridBagLayout();
		gbl_bottoniClubPanel.columnWidths = new int[]{0};
		gbl_bottoniClubPanel.rowHeights = new int[]{0};
		gbl_bottoniClubPanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_bottoniClubPanel.rowWeights = new double[]{Double.MIN_VALUE};
		bottoniClubPanel.setLayout(gbl_bottoniClubPanel);
		
		sponsorScrollPane = new JScrollPane();
		panel.add(sponsorScrollPane);
		
		bottoniSponsorPanel = new JPanel();
		sponsorScrollPane.setViewportView(bottoniSponsorPanel);
	
		gbl_bottoniSponsorPanel = new GridBagLayout();
		gbl_bottoniSponsorPanel.columnWidths = new int[]{0};
		gbl_bottoniSponsorPanel.rowHeights = new int[]{0};
		gbl_bottoniSponsorPanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_bottoniSponsorPanel.rowWeights = new double[]{Double.MIN_VALUE};
		bottoniSponsorPanel.setLayout(gbl_bottoniSponsorPanel);
		
		panel_1 = new JPanel();
		panel_1.setForeground(Color.BLACK);
		panel_1.setPreferredSize(new Dimension(10, 39));
		panel_1.setBackground(Color.GRAY);
		contentPane.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(null);
		
		copyrightLabel = new JLabel("\u00AE2020 Raimo Vessella. All Right Reserved ");
		copyrightLabel.setForeground(Color.WHITE);
		copyrightLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		copyrightLabel.setBounds(10, 11, 298, 14);
		panel_1.add(copyrightLabel);
		
		upPanel = new JPanel();
		upPanel.setPreferredSize(new Dimension(10, 35));
		upPanel.setBackground(Color.GRAY);
		contentPane.add(upPanel, BorderLayout.NORTH);
		upPanel.setLayout(null);
		
		toProcuratoriButton = new JButton("");
		toProcuratoriButton.setToolTipText("Procuratori");
		toProcuratoriButton.setBackground(new Color(255, 255, 255));
		toProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameProcuratore(FrameContratto.this, null, null);
			}
		});
		toProcuratoriButton.setIcon(new ImageIcon("icone/businessman.png"));
		toProcuratoriButton.setFocusPainted(false);
		toProcuratoriButton.setBorderPainted(false);
		toProcuratoriButton.setBounds(12, 2, 33, 33);
		upPanel.add(toProcuratoriButton);
		
		toAtletiButton = new JButton("");
		toAtletiButton.setToolTipText("Atleti");
		toAtletiButton.setBackground(new Color(255, 255, 255));
		toAtletiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameAtleta(FrameContratto.this, null, null,null);
			}
		});
		toAtletiButton.setIcon(new ImageIcon("icone/football-player.png"));
		toAtletiButton.setFocusPainted(false);
		toAtletiButton.setBorderPainted(false);
		toAtletiButton.setBounds(47, 2, 33, 33);
		upPanel.add(toAtletiButton);
		
		toClubButton = new JButton("");
		toClubButton.setToolTipText("Club");
		toClubButton.setBackground(new Color(255, 255, 255));
		toClubButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameClub(FrameContratto.this,null,null);
			}
		});
		toClubButton.setIcon(new ImageIcon("icone/football-club.png"));
		toClubButton.setFocusPainted(false);
		toClubButton.setBorderPainted(false);
		toClubButton.setBounds(82, 2, 33, 33);
		upPanel.add(toClubButton);
		
		toSponsorButton = new JButton("");
		toSponsorButton.setToolTipText("Sponsor");
		toSponsorButton.setBackground(new Color(255, 255, 255));
		toSponsorButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameSponsor(FrameContratto.this, null,null);
			}
		});
		toSponsorButton.setIcon(new ImageIcon("icone/nike.png"));
		toSponsorButton.setFocusPainted(false);
		toSponsorButton.setBorderPainted(false);
		toSponsorButton.setBounds(117, 2, 33, 33);
		upPanel.add(toSponsorButton);
		
		toContrattiButton = new JButton("");
		toContrattiButton.setToolTipText("Contratti");
		toContrattiButton.setBackground(new Color(255, 255, 255));
		toContrattiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameContratto(FrameContratto.this, null, null, null,null);
			}
		});
		toContrattiButton.setIcon(new ImageIcon("icone/contract.png"));
		toContrattiButton.setFocusPainted(false);
		toContrattiButton.setBorderPainted(false);
		toContrattiButton.setBounds(152, 2, 33, 33);
		upPanel.add(toContrattiButton);
		
		toStatisticheProcuratoriButton = new JButton("");
		toStatisticheProcuratoriButton.setToolTipText("Statistiche Procuratori");
		toStatisticheProcuratoriButton.setBackground(new Color(255, 255, 255));
		toStatisticheProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameStatisticheProcuratore(FrameContratto.this,null);
			}
		});
		toStatisticheProcuratoriButton.setIcon(new ImageIcon("icone/presentation.png"));
		toStatisticheProcuratoriButton.setFocusPainted(false);
		toStatisticheProcuratoriButton.setBorderPainted(false);
		toStatisticheProcuratoriButton.setBounds(187, 2, 33, 33);
		upPanel.add(toStatisticheProcuratoriButton);
		
		toFrameNazionaleButton = new JButton("");
		toFrameNazionaleButton.setToolTipText("Gestione Nazionali");
		toFrameNazionaleButton.setBackground(new Color(255, 255, 255));
		toFrameNazionaleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameNazionale(FrameContratto.this,null);
			}
		});
		toFrameNazionaleButton.setIcon(new ImageIcon("icone/location.png"));
		toFrameNazionaleButton.setFocusPainted(false);
		toFrameNazionaleButton.setBorderPainted(false);
		toFrameNazionaleButton.setBounds(222, 2, 33, 33);
		upPanel.add(toFrameNazionaleButton);
		
		nomeAtletaLabel = new JLabel("");
		nomeAtletaLabel.setHorizontalAlignment(SwingConstants.CENTER);
		nomeAtletaLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		
		nomeAtletaLabel.setBounds(282, 0, 320, 35);
		if(atl == null)
			nomeAtletaLabel.setVisible(false);
		else
			nomeAtletaLabel.setText("ATLETA " + atl.getNome() + " " + atl.getCognome());
		upPanel.add(nomeAtletaLabel);
		
		mainPanel = new JPanel();
		contentPane.add(mainPanel, BorderLayout.CENTER);
		mainPanel.setLayout(new BorderLayout(0, 0));
		
		listaScrollPane = new JScrollPane();
		mainPanel.add(listaScrollPane, BorderLayout.CENTER);
		
		contrattiPanel = new JPanel();
		contrattiPanel.setBackground(new Color(192, 192, 192));
		
		listaScrollPane.setViewportView(contrattiPanel);
		
		gbl_contrattiPanel = new GridBagLayout();
		gbl_contrattiPanel.columnWidths = new int[]{0};
		gbl_contrattiPanel.rowHeights = new int[]{0};
		gbl_contrattiPanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_contrattiPanel.rowWeights = new double[]{Double.MIN_VALUE};
		contrattiPanel.setLayout(gbl_contrattiPanel);
		
		//FUNZIONI
		creaBottoniClub(bottoniClubPanel, clubsArray, atl);
		creaBottoniSponsor(bottoniSponsorPanel, sponsorsArray, atl);
		creaBottoniTabella(contrattiPanel, atl);
		creaTabellaContratti(contrattiPanel, contratti, atl);
	}
	
	public void creaTabellaContratti(JPanel contrattiPanel, ArrayList<Contratto> contratti, Atleta atl)
	{
		
		int countery = 1;
		for(Contratto contratto : contratti)
		{

			gbcElement = new GridBagConstraints();
			
	        labelDatoContratto = new JLabel(String.valueOf(contratto.getCodiceContratto()));
	        labelDatoContratto.setHorizontalAlignment(SwingConstants.CENTER);
	        labelDatoContratto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty = 0;
	        contrattiPanel.add(labelDatoContratto, gbcElement);
	        
	        labelDatoContratto = new JLabel(contratto.getInizioContratto().toString());
	        labelDatoContratto.setHorizontalAlignment(SwingConstants.CENTER);
	        labelDatoContratto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 1;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty = 0;
	        contrattiPanel.add(labelDatoContratto, gbcElement);
	   
	        
	        labelDatoContratto = new JLabel(contratto.getFineContratto().toString());
	        labelDatoContratto.setHorizontalAlignment(SwingConstants.CENTER);
	        labelDatoContratto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 2;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        contrattiPanel.add(labelDatoContratto, gbcElement);
	        
	        labelDatoContratto = new JLabel(String.valueOf(contratto.getCompenso()) + "�");
	        labelDatoContratto.setHorizontalAlignment(SwingConstants.CENTER);
	        labelDatoContratto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 3;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        contrattiPanel.add(labelDatoContratto, gbcElement);
	        
	        labelDatoContratto = new JLabel(String.valueOf(contratto.getPercentualeProcuratore()) + "% / " + String.valueOf((contratto.getPercentualeProcuratore()/100) * contratto.getCompenso()) + "�");
	        labelDatoContratto.setHorizontalAlignment(SwingConstants.CENTER);
	        labelDatoContratto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 4;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        contrattiPanel.add(labelDatoContratto, gbcElement);
	              
	        
	        labelDatoContratto = new JLabel(contratto.getAtleta().getNome() + " " + contratto.getAtleta().getCognome());
	        labelDatoContratto.setHorizontalAlignment(SwingConstants.CENTER);
	        labelDatoContratto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 5;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        contrattiPanel.add(labelDatoContratto, gbcElement);
	        
	         
	        labelDatoContratto = new JLabel("");
	        if(contratto.getClub() != null) labelDatoContratto.setText(contratto.getClub().getNome());
	
	        labelDatoContratto.setHorizontalAlignment(SwingConstants.CENTER);
	        labelDatoContratto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 6;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        contrattiPanel.add(labelDatoContratto, gbcElement);
	        
	        
	       
	        labelDatoContratto = new JLabel("");
	        if(contratto.getSponsor() != null) labelDatoContratto.setText(contratto.getSponsor().getNome());
	        labelDatoContratto.setHorizontalAlignment(SwingConstants.CENTER);
	        labelDatoContratto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 7;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        contrattiPanel.add(labelDatoContratto, gbcElement); 
	    
	        
	        buttonOperazione = new JButton("...");
	        buttonOperazione.setFont(new Font("Tahoma", Font.BOLD, 11));
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						
				}
			});
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);


			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 8;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH ; 
	        gbcElement.weighty=0;
	        contrattiPanel.add(buttonOperazione, gbcElement);
	        
	        buttonOperazione = new JButton("X");
	        buttonOperazione.setFont(new Font("Tahoma", Font.BOLD, 11));
	        buttonOperazione.setToolTipText("Elimina Atleta");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int i = JOptionPane.showConfirmDialog(null, "Questo causer� la cancellazione del contratto. Procedere?", "Eliminazione", JOptionPane.YES_NO_OPTION);
					if(i == JOptionPane.YES_OPTION) {
						theController.toEliminaContratto(FrameContratto.this, contratto);					}	
						
				}
			});
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 2);
	        gbcElement.gridx = 9;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        contrattiPanel.add(buttonOperazione, gbcElement);
	        
	        //BUGORIZZONTALE
			JLabel lbl = new JLabel();
	        GridBagConstraints gbc_btn = new GridBagConstraints();
	        gbc_btn.insets = new Insets(0, 0, 0, 0);
	        gbc_btn.gridx = 10;
	        gbc_btn.gridy = countery;
	        gbc_btn.fill = GridBagConstraints.BOTH;
	        gbc_btn.weightx=1;
	        gbc_btn.weighty=0;
	        contrattiPanel.add(lbl, gbc_btn);
	        //FINE BUG
	        
	        countery++;
		}
		
		//BOTTONE INSERIMENTO
		
		if(atl != null)
		{
			buttonOperazione = new JButton("STIPULA CONTRATTO CON CLUB");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						theController.toInserisciContrattoClubFrame(FrameContratto.this,atl);
				}
			});
			buttonOperazione.addMouseListener(new MouseAdapter() {
				public void mouseEntered(MouseEvent e) {
					buttonOperazione.setBackground(Color.CYAN);
				}
				public void mouseExited(MouseEvent e) {
					buttonOperazione.setBackground(new Color(252,163,17));
				}
			});
			buttonOperazione.setFont(new Font("Tahoma", Font.BOLD, 12));
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        
			gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.gridwidth = 8;
	        gbcElement.weighty = 0;
	        countery ++;
	        contrattiPanel.add(buttonOperazione, gbcElement);
	        
	        buttonOperazione = new JButton("STIPULA CONTRATTO CON SPONSOR");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					theController.toInserisciContrattoSponsorFrame(FrameContratto.this, atl);
				}
			});
			
			buttonOperazione.addMouseListener(new MouseAdapter() {
				public void mouseEntered(MouseEvent e) {
					buttonOperazione.setBackground(Color.CYAN);
				}
				public void mouseExited(MouseEvent e) {
					buttonOperazione.setBackground(new Color(252,163,17));
				}
			});

			buttonOperazione.setFont(new Font("Tahoma", Font.BOLD, 12));
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 5, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = countery;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.gridwidth=8;
	        gbcElement.weighty=0;
	        countery ++;
	        contrattiPanel.add(buttonOperazione, gbcElement);
		}
		
        //BUGVERTICALE
		JLabel lbl = new JLabel();
        GridBagConstraints gbc_btn = new GridBagConstraints();
        gbc_btn.insets = new Insets(0, 0, 0, 0);
        gbc_btn.gridx = 0;
        gbc_btn.gridy = countery;
        gbc_btn.fill = GridBagConstraints.BOTH;
        gbc_btn.weighty=1;
        contrattiPanel.add(lbl, gbc_btn);
        //FINE BUG
		
        
	}
	
	private void creaBottoniTabella(JPanel personePanel, Atleta atl)
	{

        gbcElement = new GridBagConstraints();
        
        buttonOperazione = new JButton("CODICE CONTRATTO");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "codice_crescente")
					theController.toFrameContratto(FrameContratto.this,"codice_crescente", vincoloClub, vincoloSponsor, atl);
				else
					theController.toFrameContratto(FrameContratto.this, "codice_decrescente", vincoloClub, vincoloSponsor, atl);
	
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 0;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("INIZIO CONTRATTO");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "inizio_crescente")
					theController.toFrameContratto(FrameContratto.this, "inizio_crescente", vincoloClub, vincoloSponsor, atl);
				else
					theController.toFrameContratto(FrameContratto.this, "inizio_decrescente", vincoloClub, vincoloSponsor, atl);
	
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 1;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty = 0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("FINE CONTRATTO");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "fine_crescente")
					theController.toFrameContratto(FrameContratto.this, "fine_crescente", vincoloClub, vincoloSponsor, atl);
				else
					theController.toFrameContratto(FrameContratto.this, "fine_decrescente", vincoloClub, vincoloSponsor, atl);
		
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 2;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("COMPENSO");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "compenso_crescente")
					theController.toFrameContratto(FrameContratto.this, "compenso_crescente", vincoloClub, vincoloSponsor, atl);
				else
					theController.toFrameContratto(FrameContratto.this, "compenso_decrescente", vincoloClub, vincoloSponsor, atl);
			
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 3;
        gbcElement.gridy =0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("% PROC. / IMPORTO");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "percentuale_crescente")
					theController.toFrameContratto(FrameContratto.this, "percentuale_crescente", vincoloClub, vincoloSponsor, atl);
				else
					theController.toFrameContratto(FrameContratto.this, "percentuale_decrescente", vincoloClub, vincoloSponsor, atl);
	
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 4;
        gbcElement.gridy =0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("NOME/CODICE ATLETA");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "nome_atleta_crescente")
					theController.toFrameContratto(FrameContratto.this, "nome_atleta_crescente", vincoloClub, vincoloSponsor, atl);
				else
					theController.toFrameContratto(FrameContratto.this, "nome_atleta_decrescente", vincoloClub, vincoloSponsor, atl);
		
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 5;
        gbcElement.gridy =0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("NOME CLUB");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "nome_club_crescente")
					theController.toFrameContratto(FrameContratto.this, "nome_club_crescente", vincoloClub, vincoloSponsor, atl);
				else
					theController.toFrameContratto(FrameContratto.this, "nome_club_decrescente", vincoloClub, vincoloSponsor, atl);
	
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 6;
        gbcElement.gridy =0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        
        buttonOperazione = new JButton("NOME SPONSOR");
		buttonOperazione.setFocusPainted(false);
		buttonOperazione.setBackground(new Color(252, 163, 17));
		buttonOperazione.setBorderPainted(false);
		buttonOperazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(vincoloOrdine != "nome_sponsor_crescente")
					theController.toFrameContratto(FrameContratto.this, "nome_sponsor_crescente", vincoloClub, vincoloSponsor, atl);
				else
					theController.toFrameContratto(FrameContratto.this, "nome_sponsor_decrescente", vincoloClub, vincoloSponsor, atl);
	
			}
		});
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 5, 2);
        gbcElement.gridx = 7;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weighty=0;
        
        personePanel.add(buttonOperazione, gbcElement);
        

        //BUGORIZZONTALE
		JLabel lbl = new JLabel();
        gbcElement = new GridBagConstraints();
        gbcElement.insets = new Insets(0, 0, 0, 0);
        gbcElement.gridx = 10;
        gbcElement.gridy = 0;
        gbcElement.fill = GridBagConstraints.BOTH;
        gbcElement.weightx=1;
        gbcElement.weighty=0;
        personePanel.add(lbl, gbcElement);
        //FINE BUG
		
	}
	
	public void creaBottoniSponsor(JPanel bottoniSponsorPanel, ArrayList<Sponsor> sponsorsArray, Atleta atl)
	{
		//CREAZIONE BOTTONI NAZIONE
			int counter = 0;
			for(Sponsor s: sponsorsArray)
			{
				buttonOperazione = new JButton(s.getNome());
				buttonOperazione.setFocusPainted(false);
				buttonOperazione.setBackground(new Color(252, 163, 17));
				buttonOperazione.setBorderPainted(false);
				buttonOperazione.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							theController.toFrameContratto(FrameContratto.this, vincoloOrdine, vincoloClub, s.getNome(), atl);
					}
				});
		        gbcElement = new GridBagConstraints();
		        gbcElement.insets = new Insets(0, 0, 1, 0);
		        gbcElement.gridx = 0;
		        gbcElement.gridy = counter;
		        gbcElement.fill = GridBagConstraints.BOTH;
		        gbcElement.weighty = 0;
		        
		        bottoniSponsorPanel.add(buttonOperazione, gbcElement);
		        counter++;
			}
			
			
	        //BUG
			JLabel lbl = new JLabel();
			buttonOperazione.setVisible(true);
	        GridBagConstraints gbc_btn = new GridBagConstraints();
	        gbc_btn.insets = new Insets(0, 0, 0, 0);
	        gbc_btn.gridx = 0;
	        gbc_btn.gridy = counter;
	        gbc_btn.fill = GridBagConstraints.BOTH;
	        gbc_btn.weighty=1;
	        bottoniSponsorPanel.add(lbl, gbc_btn);
	        //FINE BUG
			//
	}
	
	public void creaBottoniClub(JPanel bottoniClubPanel, ArrayList<Club> clubsArray, Atleta atl)
	{
		//CREAZIONE BOTTONI NAZIONE
			int counter = 0;
			for(Club c : clubsArray)
			{
				buttonOperazione = new JButton(c.getNome());
				buttonOperazione.setFocusPainted(false);
				buttonOperazione.setBackground(new Color(252, 163, 17));
				buttonOperazione.setBorderPainted(false);
				buttonOperazione.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							theController.toFrameContratto(FrameContratto.this, vincoloOrdine, c.getNome(), vincoloSponsor,atl);
					}
				});
		        gbcElement = new GridBagConstraints();
		        gbcElement.insets = new Insets(0, 0, 1, 0);
		        gbcElement.gridx = 0;
		        gbcElement.gridy = counter;
		        gbcElement.fill = GridBagConstraints.BOTH;
		        gbcElement.weighty=0;
		        
		        bottoniClubPanel.add(buttonOperazione, gbcElement);
		        counter++;
			}
			
			
	        //BUG
			labelDatoContratto = new JLabel();
			buttonOperazione.setVisible(true);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 0, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = counter;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty = 1;
	        bottoniClubPanel.add(labelDatoContratto, gbcElement);
	        //FINE BUG

	}
	
}
