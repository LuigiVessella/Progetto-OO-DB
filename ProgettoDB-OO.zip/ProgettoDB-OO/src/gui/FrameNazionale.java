package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import controller.Controller;
import daos.NazionaleDAO;
import daos.ProcuratoreDAO;
import entity.Nazionale;
import postegresImpl.NazionaleDAOPostgresImpl;
import javax.swing.JTextField;

public class FrameNazionale extends JFrame {

	
	//ELEMENTI GRAFICI
	private JPanel contentPane;
	private JButton buttonOperazione;
	private JLabel labelDatoNazionale;
	private JPanel menuNazioniPanel;
	private JScrollPane nazioniScrollPane;
	private JPanel bottoniNazionaliPanel;
	private GridBagLayout gbl_bottoniNazionaliPanel;
	private JPanel leftMenuNazioniPanel;
	private JPanel upPanel;
	private JPanel panel_1;
	private JLabel copyrightLabel;
	private JButton toProcuratoriButton;
	private JButton toAtletiButton;
	private JButton toClubButton;
	private JButton toSponsorButton;
	private JButton toContrattiButton;
	private JButton toStatisticheProcuratoriButton;
	private JButton toFrameNazionaleButton;
	private JPanel mainPanel;
	private JScrollPane listaScrollPane;
	private JPanel nazionaliPanel;
	private GridBagConstraints gbcElement;
	private JButton eliminaNazionaleButton;
	private JButton modificaGettoneButton;
	
	//UTILI
	private String vincoloNazione;
	
	private Controller theController;
	private JTextField textField;


	//DAO
	
	
	
	public FrameNazionale(Controller theController, String vincoloNazione, ArrayList<Nazionale> nazioni, Nazionale nazione, NazionaleDAO ricercaNazionale) throws SQLException {
		
		//ASSEGNAMENTI
		this.vincoloNazione = vincoloNazione;
		this.theController = theController;
		//FINE ASSEGNAMENTI
		
		setBackground(Color.WHITE);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setTitle("Nazionali");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		menuNazioniPanel = new JPanel();
		menuNazioniPanel.setPreferredSize(new Dimension(134, 10));
		contentPane.add(menuNazioniPanel, BorderLayout.WEST);
		menuNazioniPanel.setLayout(new BorderLayout(0, 0));
		
		
		
		nazioniScrollPane = new JScrollPane();
		menuNazioniPanel.add(nazioniScrollPane, BorderLayout.CENTER);
		
		bottoniNazionaliPanel = new JPanel();
		nazioniScrollPane.setViewportView(bottoniNazionaliPanel);
		
		gbl_bottoniNazionaliPanel = new GridBagLayout();
		gbl_bottoniNazionaliPanel.columnWidths = new int[]{0};
		gbl_bottoniNazionaliPanel.rowHeights = new int[]{0};
		gbl_bottoniNazionaliPanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_bottoniNazionaliPanel.rowWeights = new double[]{Double.MIN_VALUE};
		bottoniNazionaliPanel.setLayout(gbl_bottoniNazionaliPanel);
		
		leftMenuNazioniPanel = new JPanel();
		leftMenuNazioniPanel.setBackground(Color.GRAY);
		menuNazioniPanel.add(leftMenuNazioniPanel, BorderLayout.WEST);
		
		upPanel = new JPanel();
		upPanel.setPreferredSize(new Dimension(10, 35));
		upPanel.setBackground(Color.GRAY);
		contentPane.add(upPanel, BorderLayout.NORTH);
		upPanel.setLayout(null);
		
		panel_1 = new JPanel();
		panel_1.setForeground(Color.BLACK);
		panel_1.setPreferredSize(new Dimension(10, 39));
		panel_1.setBackground(Color.GRAY);
		contentPane.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(null);
		
		copyrightLabel = new JLabel("\u00AE2020 Raimo Vessella. All Right Reserved ");
		copyrightLabel.setForeground(Color.WHITE);
		copyrightLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		copyrightLabel.setBounds(10, 11, 298, 14);
		panel_1.add(copyrightLabel);
		
		toProcuratoriButton = new JButton("");
		toProcuratoriButton.setToolTipText("Procuratori");
		toProcuratoriButton.setBackground(new Color(255, 255, 255));
		toProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameProcuratore(FrameNazionale.this, null, null);
			}
		});
		toProcuratoriButton.setIcon(new ImageIcon("icone/businessman.png"));
		toProcuratoriButton.setFocusPainted(false);
		toProcuratoriButton.setBorderPainted(false);
		toProcuratoriButton.setBounds(12, 2, 33, 33);
		upPanel.add(toProcuratoriButton);
		
		toAtletiButton = new JButton("");
		toAtletiButton.setToolTipText("Atleti");
		toAtletiButton.setBackground(new Color(255, 255, 255));
		toAtletiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameAtleta(FrameNazionale.this, null,null,null);
			}
		});
		toAtletiButton.setIcon(new ImageIcon("icone/football-player.png"));
		toAtletiButton.setFocusPainted(false);
		toAtletiButton.setBorderPainted(false);
		toAtletiButton.setBounds(47, 2, 33, 33);
		upPanel.add(toAtletiButton);
		
		toClubButton = new JButton("");
		toClubButton.setToolTipText("Club");
		toClubButton.setBackground(new Color(255, 255, 255));
		toClubButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameClub(FrameNazionale.this,null,null);
			}
		});
		toClubButton.setIcon(new ImageIcon("icone/football-club.png"));
		toClubButton.setFocusPainted(false);
		toClubButton.setBorderPainted(false);
		toClubButton.setBounds(82, 2, 33, 33);
		upPanel.add(toClubButton);
		
		toSponsorButton = new JButton("");
		toSponsorButton.setToolTipText("Sponsor");
		toSponsorButton.setBackground(new Color(255, 255, 255));
		toSponsorButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameSponsor(FrameNazionale.this, null,null);
			}
		});
		toSponsorButton.setIcon(new ImageIcon("icone/nike.png"));
		toSponsorButton.setFocusPainted(false);
		toSponsorButton.setBorderPainted(false);
		toSponsorButton.setBounds(117, 2, 33, 33);
		upPanel.add(toSponsorButton);
		
		toContrattiButton = new JButton("");
		toContrattiButton.setToolTipText("Contratti");
		toContrattiButton.setBackground(new Color(255, 255, 255));
		toContrattiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameContratto(FrameNazionale.this, null, null, null,null);
			}
		});
		toContrattiButton.setIcon(new ImageIcon("icone/contract.png"));
		toContrattiButton.setFocusPainted(false);
		toContrattiButton.setBorderPainted(false);
		toContrattiButton.setBounds(152, 2, 33, 33);
		upPanel.add(toContrattiButton);
		
		toStatisticheProcuratoriButton = new JButton("");
		toStatisticheProcuratoriButton.setToolTipText("Statistiche Procuratori");
		toStatisticheProcuratoriButton.setBackground(new Color(255, 255, 255));
		toStatisticheProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameStatisticheProcuratore(FrameNazionale.this,null);
			}
		});
		toStatisticheProcuratoriButton.setIcon(new ImageIcon("icone/presentation.png"));
		toStatisticheProcuratoriButton.setFocusPainted(false);
		toStatisticheProcuratoriButton.setBorderPainted(false);
		toStatisticheProcuratoriButton.setBounds(187, 2, 33, 33);
		upPanel.add(toStatisticheProcuratoriButton);
		
		toFrameNazionaleButton = new JButton("");
		toFrameNazionaleButton.setToolTipText("Gestione Nazionali");
		toFrameNazionaleButton.setBackground(new Color(255, 255, 255));
		toFrameNazionaleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameNazionale(FrameNazionale.this,null);
			}
		});
		toFrameNazionaleButton.setIcon(new ImageIcon("icone/location.png"));
		toFrameNazionaleButton.setFocusPainted(false);
		toFrameNazionaleButton.setBorderPainted(false);
		toFrameNazionaleButton.setBounds(222, 2, 33, 33);
		upPanel.add(toFrameNazionaleButton);
		
		mainPanel = new JPanel();
		contentPane.add(mainPanel, BorderLayout.CENTER);
		mainPanel.setLayout(new BorderLayout(0, 0));
		
		listaScrollPane = new JScrollPane();
		mainPanel.add(listaScrollPane, BorderLayout.CENTER);
		
		nazionaliPanel = new JPanel();
		nazionaliPanel.setBackground(new Color(192, 192, 192));
		listaScrollPane.setViewportView(nazionaliPanel);
		nazionaliPanel.setLayout(null);

		if(vincoloNazione != null)
		{
			try {
				nazione = ricercaNazionale.getNazionale(vincoloNazione);
			} catch (SQLException e1) {
				
				JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

			}
			
			copyrightLabel = new JLabel("NAZIONE :");
			copyrightLabel.setBounds(10, 11, 200, 14);
			nazionaliPanel.add(copyrightLabel);
			
			labelDatoNazionale = new JLabel(nazione.getNome());
			labelDatoNazionale.setBounds(300, 11, 200, 14);
			nazionaliPanel.add(labelDatoNazionale);
			
			copyrightLabel = new JLabel("GETTONE :");
			copyrightLabel.setBounds(10, 41, 200, 14);
			nazionaliPanel.add(copyrightLabel);
			
			labelDatoNazionale = new JLabel(String.valueOf(nazione.getGettone()));
			labelDatoNazionale.setBounds(300, 41, 200, 14);
			nazionaliPanel.add(labelDatoNazionale);
			//TODO
			
			copyrightLabel = new JLabel("NUMERO DI PROCURATORI :");
			copyrightLabel.setBounds(10, 71, 200, 14);
			nazionaliPanel.add(copyrightLabel);
			
			labelDatoNazionale = new JLabel(String.valueOf(ricercaNazionale.getNumeroDiProcuratori(vincoloNazione)));
			labelDatoNazionale.setBounds(300, 71, 200, 14);
			nazionaliPanel.add(labelDatoNazionale);
			
			copyrightLabel = new JLabel("NUMERO DI ATLETI :");
			copyrightLabel.setBounds(10, 101, 200, 14);
			nazionaliPanel.add(copyrightLabel);
			
			labelDatoNazionale = new JLabel(String.valueOf(ricercaNazionale.getNumeroDiAtleti(vincoloNazione)));
			labelDatoNazionale.setBounds(300, 101, 200, 14);
			nazionaliPanel.add(labelDatoNazionale);
			
			textField = new JTextField();
			textField.setBounds(10, 131, 200, 30);
			nazionaliPanel.add(textField);
			textField.setColumns(10);
			
			modificaGettoneButton = new JButton("MODIFICA GETTONE");
			modificaGettoneButton.setBounds(300, 131, 200, 30);
			modificaGettoneButton.setBackground(new Color(252, 163, 17));

			modificaGettoneButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						ricercaNazionale.modificaGettone(vincoloNazione,Double.parseDouble(textField.getText().trim()));
					} catch (NumberFormatException | SQLException e1) {
						JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

					}
					theController.toFrameNazionale(FrameNazionale.this,vincoloNazione);
				}
			});
			nazionaliPanel.add(modificaGettoneButton);
			
			eliminaNazionaleButton = new JButton("ELIMINA NAZIONE");
			eliminaNazionaleButton.setBounds(10, 181, 200, 30);
			eliminaNazionaleButton.setBackground(new Color(252, 163, 17));

			eliminaNazionaleButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						int i = JOptionPane.showConfirmDialog(null, "Questo causer� la cancellazione degli atleti e dei procuratori della nazione. Procedere?", "Eliminazione", JOptionPane.YES_NO_OPTION);
						if(i == JOptionPane.YES_OPTION) {
							ricercaNazionale.eliminaNazionale(vincoloNazione);
							theController.toFrameNazionale(FrameNazionale.this,null);
						}
						
					} catch (SQLException e1) {
						JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);
					}
				}
			});
			nazionaliPanel.add(eliminaNazionaleButton);
				
		}
		else
		{
			copyrightLabel = new JLabel("CLICCA SU UNA NAZIONE :");
			copyrightLabel.setBounds(10, 11, 300, 14);
			nazionaliPanel.add(copyrightLabel);
		}
		//FUNZIONI
		creaBottoniNazionale(bottoniNazionaliPanel,nazioni);
		
	}
	
	public void creaBottoniNazionale(JPanel bottoniNazionaliPanel,ArrayList<Nazionale> nazioni)
	{
		//CREAZIONE BOTTONI NAZIONE
			int counter = 0;
			for(Nazionale nazione : nazioni)
			{
				buttonOperazione = new JButton(nazione.getNome());
				buttonOperazione.setFocusPainted(false);
				buttonOperazione.setBackground(new Color(252, 163, 17));
				buttonOperazione.setBorderPainted(false);
				buttonOperazione.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							theController.toFrameNazionale(FrameNazionale.this, nazione.getNome());
					}
				});
		        gbcElement = new GridBagConstraints();
		        gbcElement.insets = new Insets(0, 0, 1, 0);
		        gbcElement.gridx = 0;
		        gbcElement.gridy = counter;
		        gbcElement.fill = GridBagConstraints.BOTH;
		        gbcElement.weighty=0;
		        
		        bottoniNazionaliPanel.add(buttonOperazione, gbcElement);
		        counter++;
			}
			//BOTTONE INSERIMENTO
			buttonOperazione = new JButton("+");
			buttonOperazione.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						theController.toInserisciNazionaleFrame(FrameNazionale.this);
				}
			});
			buttonOperazione.setFocusPainted(false);
			buttonOperazione.setBackground(new Color(252, 163, 17));
			buttonOperazione.setBorderPainted(false);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 1, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = counter;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty=0;
	        counter ++;
	        bottoniNazionaliPanel.add(buttonOperazione, gbcElement);
			
	        //BUG
			labelDatoNazionale = new JLabel();
			buttonOperazione.setVisible(true);
	        gbcElement = new GridBagConstraints();
	        gbcElement.insets = new Insets(0, 0, 0, 0);
	        gbcElement.gridx = 0;
	        gbcElement.gridy = counter;
	        gbcElement.fill = GridBagConstraints.BOTH;
	        gbcElement.weighty = 1;
	        bottoniNazionaliPanel.add(labelDatoNazionale, gbcElement);
	        //FINE BUG
			//
	}
}
