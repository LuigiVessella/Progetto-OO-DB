package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import controller.Controller;
import daos.ClubDAO;
import daos.NazionaleDAO;
import entity.Club;
import postegresImpl.ClubDAOPostgresImpl;
import postegresImpl.NazionaleDAOPostgresImpl;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class InserisciClubFrame extends JFrame {

	private JPanel contentPane;
	
	private JTextField nomeTextField;
	private JTextField presidenteTextField;
	private JTextField dataTextField;
	private JTextField cittaTextField;
	
	private JLabel dataLabel;
	private JLabel presidenteLabel;
	private JLabel nomeClubLabel;
	private JLabel lblNewLabel;
	private JButton inserisciButton;
	private JButton IndietroButton;

	private JLabel CittaLabel;

	private JComboBox NazionaleComboBox;
	private JLabel imageLabel;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JLabel lblNewLabel_1;
	private Controller theController;
	/**
	 * Create the frame.
	 */
	public InserisciClubFrame(Controller theController,NazionaleDAO getNomiNazioni) {
		this.theController=theController;
		try {
			getNomiNazioni = new NazionaleDAOPostgresImpl(theController.controllerGetConnection());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		setResizable(false);
		setTitle("Inserimento Club");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,  663, 412);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		nomeTextField = new JTextField();
		nomeTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				cittaTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(nomeTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});

		nomeTextField.setBounds(10, 54, 100, 19);
		contentPane.add(nomeTextField);
		nomeTextField.setColumns(10);
		
		nomeClubLabel = new JLabel("NOME CLUB");
		nomeClubLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		nomeClubLabel.setBounds(120, 53, 98, 19);
		contentPane.add(nomeClubLabel);
		
		presidenteTextField = new JTextField();
		presidenteTextField.setEditable(false);
		presidenteTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				dataTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(presidenteTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		presidenteTextField.setBounds(10, 174, 100, 19);
		contentPane.add(presidenteTextField);
		presidenteTextField.setColumns(10);
		
		presidenteLabel = new JLabel("PRESIDENTE");
		presidenteLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		presidenteLabel.setBounds(120, 174, 83, 16);
		contentPane.add(presidenteLabel);
		
		dataTextField = new JTextField();
		dataTextField.setEditable(false);
		dataTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				inserisciButton.setEnabled(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(dataTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		dataTextField.setBounds(10, 223, 100, 19);
		contentPane.add(dataTextField);
		dataTextField.setColumns(10);
		
		dataLabel = new JLabel("DATA FONDAZIONE");
		dataLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		dataLabel.setBounds(120, 222, 125, 19);
		contentPane.add(dataLabel);
		
		inserisciButton = new JButton("Inserisci");
		inserisciButton.setEnabled(false);
		inserisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inserisciButton.setBackground(Color.ORANGE);
		inserisciButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		inserisciButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0)   {
				
				if(nomeTextField.getText().trim() == "" || presidenteTextField.getText().trim() == "" || cittaTextField.getText().trim() == "")
					JOptionPane.showMessageDialog(null, "Inserimento errato, rivedere i valori", "Errore", JOptionPane.ERROR_MESSAGE);
				else {
					String nomeClub = nomeTextField.getText().trim();
					String presidente = presidenteTextField.getText().trim();
					String citta = cittaTextField.getText().trim();
					String nazionale = NazionaleComboBox.getSelectedItem().toString();
					
					
					
					Date fondazione = new Date();
					
					Club nuovoClub = new Club();
					
					try {
						fondazione = new SimpleDateFormat("yyyy/MM/dd").parse(dataTextField.getText());
					} catch (ParseException e) {
						JOptionPane.showMessageDialog(null, "Inserimento errato, rivedere i valori", "Errore", JOptionPane.ERROR_MESSAGE);
	
					}
					
					if(nuovoClub.setClub(nomeClub, presidente, fondazione,citta,nazionale)) {
						try {
							ClubDAO inserimento = new ClubDAOPostgresImpl(theController.controllerGetConnection());
							inserimento.insertClub(nuovoClub);
							JOptionPane.showMessageDialog(null, "Inserimento avvenuto con successo");
						} catch (SQLException e) {
							JOptionPane.showMessageDialog(null, "Inserimento errato, rivedere i valori", "Errore", JOptionPane.ERROR_MESSAGE);
	
						}
						
					}
					else {
						JOptionPane.showMessageDialog(null, "Inserimento errato, rivedere i valori", "Errore", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		
		inserisciButton.setBounds(485, 314, 125, 35);
		contentPane.add(inserisciButton);
		
		IndietroButton = new JButton("Indietro");
		IndietroButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		IndietroButton.setBackground(Color.ORANGE);
		IndietroButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		IndietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameClub(InserisciClubFrame.this, null, null);
			}
		});
		IndietroButton.setBounds(10, 314, 118, 35);
		contentPane.add(IndietroButton);
		
		cittaTextField = new JTextField();
		cittaTextField.setEditable(false);
		cittaTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				presidenteTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(cittaTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		cittaTextField.setBounds(10, 111, 100, 20);
		contentPane.add(cittaTextField);
		cittaTextField.setColumns(10);
		
		CittaLabel = new JLabel("CITT\u00C0");
		CittaLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		CittaLabel.setBounds(120, 113, 46, 14);
		contentPane.add(CittaLabel);
		
		
		
		lblNewLabel = new JLabel("Nazionale:");
		lblNewLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		lblNewLabel.setBounds(430, 42, 100, 14);
		contentPane.add(lblNewLabel);
		
		try {
			NazionaleComboBox = new JComboBox(getNomiNazioni.getNomeNazionaleString().toArray());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
		}
		NazionaleComboBox.setToolTipText("");
		NazionaleComboBox.setBounds(430, 76, 98, 22);
		contentPane.add(NazionaleComboBox);
		
		ImageIcon image = new ImageIcon("icone\\football-club128.png");
		imageLabel = new JLabel(image);	
		imageLabel.setToolTipText("Il Club");
		imageLabel.setBounds(415, 161, 128, 128);
		contentPane.add(imageLabel);
		
		panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 659, 32);
		contentPane.add(panel);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(623, 25, 36, 363);
		contentPane.add(panel_1);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(0, 359, 624, 29);
		contentPane.add(panel_2);
		
		lblNewLabel_1 = new JLabel("(yyyy/mm/dd)");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));
		lblNewLabel_1.setBounds(10, 203, 96, 13);
		contentPane.add(lblNewLabel_1);
		
	}
	
	public void pulisciCaselle() {
		nomeTextField.setText("");
		presidenteTextField.setText("");
		dataTextField.setText("");
		cittaTextField.setText("");
	}
}
