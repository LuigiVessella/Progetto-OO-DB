package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controller.Controller;
import daos.NazionaleDAO;
import entity.Club;
import entity.Nazionale;
import entity.Sponsor;

public class FrameSponsor extends JFrame {

	private JPanel contentPane;
	private JButton btn;
	private JLabel lbl;
	private String vincoloNazione;
	private String vincoloOrdine;
	private String vincoloRicerca;
	private JPanel menuNazioniPanel;
	private JScrollPane nazioniScrollPane;
	private JPanel bottoniNazionaliPanel;
	private GridBagLayout gbl_bottoniNazionaliPanel;
	private JPanel panel_1;
	private JLabel lblNewLabel;
	private JPanel leftMenuNazioniPanel;
	private JPanel upPanel;
	private JButton toProcuratoriButton;
	private JButton toAtletiButton ;
	private JButton toClubButton;
	private JButton toSponsorButton;
	private JButton toContrattiButton;
	private JButton toStatisticheProcuratoriButton;
	private JButton toFrameNazionaleButton;
	private JPanel mainPanel;
	private JScrollPane listaScrollPane;
	private JPanel sponsorsPanel;
	private GridBagLayout gbl_sponsorsPanel;
	private GridBagConstraints gbc_element;
	
	
	
	private Controller theController;
	
	
	public FrameSponsor(Controller theController,String vincoloNazione,String vincoloOrdine,ArrayList<Sponsor> sponsors,ArrayList<Nazionale> nazioni) {
		setBackground(Color.WHITE);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setTitle("Sponsors");
		
		
		//ASSEGNAMENTI
		this.vincoloNazione=vincoloNazione;
		this.vincoloOrdine=vincoloOrdine;
		this.theController=theController;
		//FINE ASSEGNAMENTI
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		menuNazioniPanel = new JPanel();
		menuNazioniPanel.setPreferredSize(new Dimension(134, 10));
		contentPane.add(menuNazioniPanel, BorderLayout.WEST);
		menuNazioniPanel.setLayout(new BorderLayout(0, 0));
		
		nazioniScrollPane = new JScrollPane();
		menuNazioniPanel.add(nazioniScrollPane, BorderLayout.CENTER);
		
		bottoniNazionaliPanel = new JPanel();
		nazioniScrollPane.setViewportView(bottoniNazionaliPanel);
		gbl_bottoniNazionaliPanel = new GridBagLayout();
		gbl_bottoniNazionaliPanel.columnWidths = new int[]{0};
		gbl_bottoniNazionaliPanel.rowHeights = new int[]{0};
		gbl_bottoniNazionaliPanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_bottoniNazionaliPanel.rowWeights = new double[]{Double.MIN_VALUE};
		bottoniNazionaliPanel.setLayout(gbl_bottoniNazionaliPanel);
		
		panel_1 = new JPanel();
		panel_1.setForeground(Color.BLACK);
		panel_1.setPreferredSize(new Dimension(10, 39));
		panel_1.setBackground(Color.GRAY);
		contentPane.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(null);
		
		lblNewLabel = new JLabel("\u00AE2020 Raimo Vessella. All Right Reserved ");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setBounds(10, 11, 298, 14);
		panel_1.add(lblNewLabel);
		
		leftMenuNazioniPanel = new JPanel();
		leftMenuNazioniPanel.setBackground(Color.GRAY);
		menuNazioniPanel.add(leftMenuNazioniPanel, BorderLayout.WEST);
		
		upPanel = new JPanel();
		upPanel.setPreferredSize(new Dimension(10, 35));
		upPanel.setBackground(Color.GRAY);
		contentPane.add(upPanel, BorderLayout.NORTH);
		upPanel.setLayout(null);
		
		toProcuratoriButton = new JButton("");
		toProcuratoriButton.setToolTipText("Procuratori");
		toProcuratoriButton.setBackground(new Color(255, 255, 255));
		toProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameProcuratore(FrameSponsor.this, null, null);
			}
		});
		toProcuratoriButton.setIcon(new ImageIcon("icone/businessman.png"));
		toProcuratoriButton.setFocusPainted(false);
		toProcuratoriButton.setBorderPainted(false);
		toProcuratoriButton.setBounds(12, 2, 33, 33);
		upPanel.add(toProcuratoriButton);
		
		toAtletiButton = new JButton("");
		toAtletiButton.setToolTipText("Atleti");
		toAtletiButton.setBackground(new Color(255, 255, 255));
		toAtletiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameAtleta(FrameSponsor.this, null, null,null);
			}
		});
		toAtletiButton.setIcon(new ImageIcon("icone/football-player.png"));
		toAtletiButton.setFocusPainted(false);
		toAtletiButton.setBorderPainted(false);
		toAtletiButton.setBounds(47, 2, 33, 33);
		upPanel.add(toAtletiButton);
		
		toClubButton = new JButton("");
		toClubButton.setToolTipText("Club");
		toClubButton.setBackground(new Color(255, 255, 255));
		toClubButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameClub(FrameSponsor.this,null,null);
			}
		});
		toClubButton.setIcon(new ImageIcon("icone/football-club.png"));
		toClubButton.setFocusPainted(false);
		toClubButton.setBorderPainted(false);
		toClubButton.setBounds(82, 2, 33, 33);
		upPanel.add(toClubButton);
		
		toSponsorButton = new JButton("");
		toSponsorButton.setToolTipText("Sponsor");
		toSponsorButton.setBackground(new Color(255, 255, 255));
		toSponsorButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameSponsor(FrameSponsor.this, null,null);
			}
		});
		toSponsorButton.setIcon(new ImageIcon("icone/nike.png"));
		toSponsorButton.setFocusPainted(false);
		toSponsorButton.setBorderPainted(false);
		toSponsorButton.setBounds(117, 2, 33, 33);
		upPanel.add(toSponsorButton);
		
		toContrattiButton = new JButton("");
		toContrattiButton.setToolTipText("Contratti");
		toContrattiButton.setBackground(new Color(255, 255, 255));
		toContrattiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameContratto(FrameSponsor.this, null, null, null,null);
			}
		});
		toContrattiButton.setIcon(new ImageIcon("icone/contract.png"));
		toContrattiButton.setFocusPainted(false);
		toContrattiButton.setBorderPainted(false);
		toContrattiButton.setBounds(152, 2, 33, 33);
		upPanel.add(toContrattiButton);
		
		toStatisticheProcuratoriButton = new JButton("");
		toStatisticheProcuratoriButton.setToolTipText("Statistiche Procuratori");
		toStatisticheProcuratoriButton.setBackground(new Color(255, 255, 255));
		toStatisticheProcuratoriButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameStatisticheProcuratore(FrameSponsor.this,null);
			}
		});
		toStatisticheProcuratoriButton.setIcon(new ImageIcon("icone/presentation.png"));
		toStatisticheProcuratoriButton.setFocusPainted(false);
		toStatisticheProcuratoriButton.setBorderPainted(false);
		toStatisticheProcuratoriButton.setBounds(187, 2, 33, 33);
		upPanel.add(toStatisticheProcuratoriButton);
		
		toFrameNazionaleButton = new JButton("");
		toFrameNazionaleButton.setToolTipText("Gestione Nazionali");
		toFrameNazionaleButton.setBackground(new Color(255, 255, 255));
		toFrameNazionaleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameNazionale(FrameSponsor.this,null);
			}
		});
		toFrameNazionaleButton.setIcon(new ImageIcon("icone/location.png"));
		toFrameNazionaleButton.setFocusPainted(false);
		toFrameNazionaleButton.setBorderPainted(false);
		toFrameNazionaleButton.setBounds(222, 2, 33, 33);
		upPanel.add(toFrameNazionaleButton);
		
		mainPanel = new JPanel();
		mainPanel.setBackground(new Color(192,192,192));
		contentPane.add(mainPanel, BorderLayout.CENTER);
		mainPanel.setLayout(new BorderLayout(0, 0));
		
		listaScrollPane = new JScrollPane();
		mainPanel.add(listaScrollPane, BorderLayout.CENTER);
		
		sponsorsPanel = new JPanel();
		sponsorsPanel.setBackground(new Color(192,192,192));
		listaScrollPane.setViewportView(sponsorsPanel);
		gbl_sponsorsPanel = new GridBagLayout();
		gbl_sponsorsPanel.columnWidths = new int[]{0};
		gbl_sponsorsPanel.rowHeights = new int[]{0};
		gbl_sponsorsPanel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_sponsorsPanel.rowWeights = new double[]{Double.MIN_VALUE};
		sponsorsPanel.setLayout(gbl_sponsorsPanel);
		
		//FUNZIONI
		creaBottoniNazionale(bottoniNazionaliPanel,nazioni);
		creaBottoniTabella(sponsorsPanel);
		creaTabellaSponsors(sponsorsPanel,sponsors);
		
		//FINE FUNZIONI
		
		
	}

	
	public void creaTabellaSponsors(JPanel sponsorspanel,ArrayList<Sponsor> sponsors)
	{
		
		int countery=1;
		for(Sponsor sponsor: sponsors)
		{
			lbl = new JLabel(sponsor.getNome());
			lbl.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			lbl.setHorizontalAlignment(SwingConstants.CENTER);
			gbc_element = new GridBagConstraints();
	        gbc_element.insets = new Insets(0, 0, 5, 2);
	        gbc_element.gridx = 0;
	        gbc_element.gridy = countery;
	        gbc_element.fill = GridBagConstraints.BOTH;
	        gbc_element.weighty=0;
	        sponsorspanel.add(lbl, gbc_element);
	        
	        
	        lbl = new JLabel(sponsor.getNazionale());
	        lbl.setHorizontalAlignment(SwingConstants.CENTER);
	        lbl.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			gbc_element = new GridBagConstraints();
	        gbc_element.insets = new Insets(0, 0, 5, 2);
	        gbc_element.gridx = 1;
	        gbc_element.gridy = countery;
	        gbc_element.fill = GridBagConstraints.BOTH;
	        gbc_element.weighty=0;
	        sponsorspanel.add(lbl, gbc_element);
	        
	              
	        btn = new JButton("...");
	        btn.setFont(new Font("Tahoma", Font.BOLD, 11));
			btn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						theController.toFrameAtleta(FrameSponsor.this, null, null, null);
				}
			});
			btn.setFocusPainted(false);
			btn.setBackground(new Color(252, 163, 17));
			btn.setBorderPainted(false);
	        gbc_element = new GridBagConstraints();
	        gbc_element.insets = new Insets(0, 0, 5, 2);
	        gbc_element.gridx = 2;
	        gbc_element.gridy = countery;
	        gbc_element.fill = GridBagConstraints.BOTH;
	        gbc_element.weighty=0;
	        sponsorspanel.add(btn, gbc_element);
	        
	        btn = new JButton("X");
	        btn.setFont(new Font("Tahoma", Font.BOLD, 11));
	        btn.setToolTipText("Elimina Sponsor");
			btn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int i = JOptionPane.showConfirmDialog(null, "Questo causer� la cancellazione del procuratore, procedere?", "Eliminazione", JOptionPane.YES_NO_OPTION);
					if(i == JOptionPane.YES_OPTION) {
						theController.toEliminaSponsor(FrameSponsor.this,sponsor);					}
						
				}
			});
			btn.setFocusPainted(false);
			btn.setBackground(new Color(252, 163, 17));
			btn.setBorderPainted(false);
	        gbc_element = new GridBagConstraints();
	        gbc_element.insets = new Insets(0, 0, 5, 2);
	        gbc_element.gridx = 3;
	        gbc_element.gridy = countery;
	        gbc_element.fill = GridBagConstraints.BOTH;
	        gbc_element.weighty=0;
	        sponsorspanel.add(btn, gbc_element);
	        
	        //BUGORIZZONTALE
			JLabel lbl = new JLabel();
	        gbc_element = new GridBagConstraints();
	        gbc_element.insets = new Insets(0, 0, 0, 0);
	        gbc_element.gridx = 4;
	        gbc_element.gridy = countery;
	        gbc_element.fill = GridBagConstraints.BOTH;
	        gbc_element.weightx=1;
	        gbc_element.weighty=0;
	        sponsorspanel.add(lbl, gbc_element);
	        //FINE BUG
	        
	        countery++;
		}
		
		//BOTTONE INSERIMENTO
		btn = new JButton("INSERISCI NUOVO SPONSOR");
		btn.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					try {
						theController.toInserisciSponsorFrame(FrameSponsor.this);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			}
		});
		btn.setFocusPainted(false);
		btn.setBackground(new Color(252, 163, 17));
		btn.setBorderPainted(false);
        gbc_element = new GridBagConstraints();
        gbc_element.insets = new Insets(0, 0, 5, 0);
        gbc_element.gridx = 0;
        gbc_element.gridy = countery;
        gbc_element.fill = GridBagConstraints.BOTH;
        gbc_element.gridwidth=2;
        gbc_element.weighty=0;
        countery ++;
        sponsorspanel.add(btn, gbc_element);
		
        //BUGVERTICALE
		lbl = new JLabel();
        gbc_element = new GridBagConstraints();
        gbc_element.insets = new Insets(0, 0, 0, 0);
        gbc_element.gridx = 0;
        gbc_element.gridy = countery;
        gbc_element.fill = GridBagConstraints.BOTH;
        gbc_element.weighty=1;
        sponsorspanel.add(lbl, gbc_element);
        //FINE BUG
		//
        
	}
	
	private void creaBottoniTabella(JPanel sponsorspanel)
	{
		btn = new JButton("NOME");
		btn.setFocusPainted(false);
		btn.setBackground(new Color(252, 163, 17));
		btn.setBorderPainted(false);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "nome_crescente")
					theController.toFrameSponsor(FrameSponsor.this, vincoloNazione,"nome_crescente");
				else 
					theController.toFrameSponsor(FrameSponsor.this, vincoloNazione,"nome_decrescente");

			}
		});
        gbc_element = new GridBagConstraints();
        gbc_element.insets = new Insets(0, 0, 5, 2);
        gbc_element.gridx = 0;
        gbc_element.gridy =0;
        gbc_element.fill = GridBagConstraints.BOTH;
        gbc_element.weighty=0;
        
        sponsorspanel.add(btn, gbc_element);
        
        btn = new JButton("NAZIONALE");
		btn.setFocusPainted(false);
		btn.setBackground(new Color(252, 163, 17));
		btn.setBorderPainted(false);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(vincoloOrdine != "nazione_crescente")
					theController.toFrameSponsor(FrameSponsor.this, vincoloNazione,"nazione_crescente");
				else 
					theController.toFrameSponsor(FrameSponsor.this, vincoloNazione,"nazione_decrescente");

			}
		});
        gbc_element = new GridBagConstraints();
        gbc_element.insets = new Insets(0, 0, 5, 2);
        gbc_element.gridx = 1;
        gbc_element.gridy =0;
        gbc_element.fill = GridBagConstraints.BOTH;
        gbc_element.weighty=0;
        
        sponsorspanel.add(btn, gbc_element);
        
   
        
        //BUGORIZZONTALE
		lbl = new JLabel();
        gbc_element = new GridBagConstraints();
        gbc_element.insets = new Insets(0, 0, 0, 0);
        gbc_element.gridx = 4	;
        gbc_element.gridy = 0;
        gbc_element.fill = GridBagConstraints.BOTH;
        gbc_element.weightx=1;
        gbc_element.weighty=0;
        sponsorspanel.add(lbl, gbc_element);
        //FINE BUG
		
	}
	
	public void creaBottoniNazionale(JPanel bottoniNazionaliPanel,ArrayList<Nazionale> nazioni)
	{
		//CREAZIONE BOTTONI NAZIONE
			int counter=0;
			for(Nazionale nazione : nazioni)
			{
				btn = new JButton(nazione.getNome());
				btn.setFocusPainted(false);
				btn.setBackground(new Color(252, 163, 17));
				btn.setBorderPainted(false);
				btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							theController.toFrameSponsor(FrameSponsor.this, nazione.getNome(), vincoloOrdine);
					}
				});
		        gbc_element = new GridBagConstraints();
		        gbc_element.insets = new Insets(0, 0, 1, 0);
		        gbc_element.gridx = 0;
		        gbc_element.gridy = counter;
		        gbc_element.fill = GridBagConstraints.BOTH;
		        gbc_element.weighty=0;
		        
		        bottoniNazionaliPanel.add(btn, gbc_element);
		        counter++;
			}
			//BOTTONE INSERIMENTO
			btn = new JButton("+");
			btn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						theController.toInserisciNazionaleFrame(FrameSponsor.this);
				}
			});
			btn.setFocusPainted(false);
			btn.setBackground(new Color(252, 163, 17));
			btn.setBorderPainted(false);
	        gbc_element = new GridBagConstraints();
	        gbc_element.insets = new Insets(0, 0, 1, 0);
	        gbc_element.gridx = 0;
	        gbc_element.gridy = counter;
	        gbc_element.fill = GridBagConstraints.BOTH;
	        gbc_element.weighty=0;
	        counter ++;
	        bottoniNazionaliPanel.add(btn, gbc_element);
			
	        //BUG
			lbl = new JLabel();
			btn.setVisible(true);
	        gbc_element = new GridBagConstraints();
	        gbc_element.insets = new Insets(0, 0, 0, 0);
	        gbc_element.gridx = 0;
	        gbc_element.gridy = counter;
	        gbc_element.fill = GridBagConstraints.BOTH;
	        gbc_element.weighty=1;
	        bottoniNazionaliPanel.add(lbl, gbc_element);
	        //FINE BUG
			//
	}
	
	
}
