package gui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.postgresql.util.PSQLException;

import codiceFiscale.CodiceFiscale;
import controller.Controller;
import daos.AtletaDAO;
import daos.NazionaleDAO;
import daos.PersonaDAO;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import entity.*;
import postegresImpl.AtletaDAOPostgresImpl;
import postegresImpl.NazionaleDAOPostgresImpl;
import postegresImpl.PersonaDAOPostgresImpl;

import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JRadioButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.Color;
import java.awt.Cursor;

public class InserisciAtletaFrame extends JFrame {

	private JPanel contentPane;
	private JTextField nomeTextField;
	private JTextField cognomeTextField;
	private JTextField dataDiNascitaTextField;
	private JTextField cittaDiNascitaTextField;
	private JLabel cittaDiNascitaLabel;
	private JTextField domicilioTextField;
	private JTextField emailTextField;
	private JLabel domicilioLabel;
	private JLabel emailLabel;
	private JButton inserisciButton;
	private JButton indietroButton;
	private JTextField nazionalitaTextField;
	private JLabel nazionalitaLabel;
	private JLabel nomeLabel;
	private JLabel cognomeLabel;
	private JComboBox nazionaleComboBox;
	private JComboBox ruoloComboBox;
	private JLabel ruoloLabel;
	private JRadioButton sessoMaschioRadioButton;
	private JRadioButton sessoFemminaRadioButton;
	private JLabel sessoLabel;
	private JTextField codiceFiscaleTextField;
	private JButton codFiscButton;
	private JLabel dataDiNascitaLabel;
	private ImageIcon image;
	
	private String sesso = "";
	private String codiceFiscale = "";
	private String luogoNascita = "";
	private JButton pulisciButton;
	private JLabel codFiscaleLabel;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JLabel imageLabel;
	private JLabel lblNewLabel;
	private Controller theController;
	private CodiceFiscale c;
	
	public InserisciAtletaFrame(Controller theController, Procuratore p, NazionaleDAO getNomiNazioni, PersonaDAO inserimento) {
		this.theController=theController;
		setBackground(Color.BLACK);
		setResizable(false);
		setTitle("Inserimento Atleta");
		
		try {
			getNomiNazioni = new NazionaleDAOPostgresImpl(theController.controllerGetConnection());

			
		} catch (SQLException e2) {
			
			e2.printStackTrace();
		}
		
	
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 663, 412);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(229, 229, 229));
		
		
		nomeTextField = new JTextField();
		nomeTextField.setBounds(10, 56, 117, 20);
		contentPane.add(nomeTextField);
		nomeTextField.setColumns(10);
		
		cognomeTextField = new JTextField();
		cognomeTextField.setBounds(10, 86, 117, 20);
		contentPane.add(cognomeTextField);
		cognomeTextField.setColumns(10);
		
		dataDiNascitaTextField = new JTextField();
		dataDiNascitaTextField.setBounds(10, 118, 117, 20);
		contentPane.add(dataDiNascitaTextField);
		dataDiNascitaTextField.setColumns(10);
		
		nomeLabel = new JLabel("NOME");
		nomeLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		nomeLabel.setBounds(132, 59, 86, 14);
		contentPane.add(nomeLabel);
		
		cognomeLabel = new JLabel("COGNOME");
		cognomeLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		cognomeLabel.setBounds(132, 91, 86, 14);
		contentPane.add(cognomeLabel);
		
		dataDiNascitaLabel = new JLabel("DATA DI NASCITA");
		dataDiNascitaLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		dataDiNascitaLabel.setBounds(132, 121, 109, 14);
		contentPane.add(dataDiNascitaLabel);
		
		cittaDiNascitaTextField = new JTextField();
		cittaDiNascitaTextField.setBounds(10, 147, 117, 20);
		contentPane.add(cittaDiNascitaTextField);
		cittaDiNascitaTextField.setColumns(10);
		
		cittaDiNascitaLabel = new JLabel("CITTA DI NASCITA");
		cittaDiNascitaLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		cittaDiNascitaLabel.setBounds(132, 150, 109, 14);
		contentPane.add(cittaDiNascitaLabel);
		
		domicilioTextField = new JTextField();
		domicilioTextField.setBounds(10, 178, 117, 20);
		contentPane.add(domicilioTextField);
		domicilioTextField.setColumns(10);
		
		emailTextField = new JTextField();
		emailTextField.setBounds(10, 212, 117, 20);
		contentPane.add(emailTextField);
		emailTextField.setColumns(10);
		
		domicilioLabel = new JLabel("DOMICILIO");
		domicilioLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		domicilioLabel.setBounds(132, 181, 86, 14);
		contentPane.add(domicilioLabel);
		
		emailLabel = new JLabel("EMAIL");
		emailLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		emailLabel.setBounds(132, 215, 46, 14);
		contentPane.add(emailLabel);

		inserisciButton = new JButton("Inserisci");
		inserisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inserisciButton.setBackground(Color.ORANGE);
		inserisciButton.setFont(new Font("Dialog", Font.BOLD, 13));
		inserisciButton.setEnabled(false);
		inserisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(sessoMaschioRadioButton.isSelected()) { 
					sesso = "m";
				
				}
				if(sessoFemminaRadioButton.isSelected()) {

					sesso = "f";
					}
				
				
				String nome = nomeTextField.getText().trim();
				String cognome = cognomeTextField.getText().trim();
				Date dataDiNascita = new Date();
				try {
					dataDiNascita = new SimpleDateFormat("yyyy/MM/dd").parse(dataDiNascitaTextField.getText());
				} catch (ParseException e1) {
				
					e1.printStackTrace();
				}
				luogoNascita = cittaDiNascitaTextField.getText().trim();
				System.out.println(luogoNascita);
				String domicilio = domicilioTextField.getText().trim();
				String email = emailTextField.getText().trim();
				String ruolo = ruoloComboBox.getSelectedItem().toString().trim();
				Persona nuovaPersona = new Persona();
				String nazionale = nazionaleComboBox.getSelectedItem().toString();
				
				try {
					if(nuovaPersona.setPersona(codiceFiscale, nome, cognome, dataDiNascita, luogoNascita, domicilio, email, nazionale, sesso))
					{
						try {
							inserimento.insertPersona(nuovaPersona);
							AtletaDAO inserimentoAtleta = new AtletaDAOPostgresImpl(theController.controllerGetConnection());
							inserimentoAtleta.insertAtleta(nuovaPersona.getCodiceFiscale(), p, ruolo);
							
							JOptionPane.showMessageDialog(null, "Inserimento avvenuto con successo");
							
							pulisciTextField();
							attivaComponenti();
						} catch (PSQLException e1 ) {
							JOptionPane.showMessageDialog(null, "Inserimento errato", "errore", JOptionPane.ERROR_MESSAGE);

						}
						catch(SQLException e2) {
							JOptionPane.showMessageDialog(null, "Inserimento errato", "errore", JOptionPane.ERROR_MESSAGE);

						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Inserimento errato", "errore", JOptionPane.ERROR_MESSAGE);
					}
				} catch (HeadlessException e1) {
					JOptionPane.showMessageDialog(null, "Inserimento errato", "errore", JOptionPane.ERROR_MESSAGE);

				} catch (IOException e1) {
					
					JOptionPane.showMessageDialog(null, "Inserimento errato", "errore", JOptionPane.ERROR_MESSAGE);

				}
				
			}
		});
		inserisciButton.setBounds(466, 267, 100, 23);
		contentPane.add(inserisciButton);
		
		indietroButton = new JButton("Indietro");
		indietroButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		indietroButton.setBackground(Color.ORANGE);
		indietroButton.setFont(new Font("Dialog", Font.BOLD, 13));
		indietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameProcuratore(InserisciAtletaFrame.this, null, null);
			}
		});
		indietroButton.setBounds(21, 267, 89, 23);
		contentPane.add(indietroButton);
		
		
		
		
		nazionalitaLabel = new JLabel("Nazionalit\u00E0:");
		nazionalitaLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		nazionalitaLabel.setBounds(466, 29, 125, 14);
		contentPane.add(nazionalitaLabel);
		
		try {
			nazionaleComboBox = new JComboBox(getNomiNazioni.getNomeNazionaleString().toArray());
			nazionaleComboBox.setSelectedItem("ITALIA");
			nazionaleComboBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent arg0) {
					if(!nazionaleComboBox.getSelectedItem().toString().trim().equals("ITALIA")) {
						cittaDiNascitaTextField.setEditable(false);
						luogoNascita = nazionaleComboBox.getSelectedItem().toString().trim();
						cittaDiNascitaTextField.setText(luogoNascita);
					}
					else {
						cittaDiNascitaTextField.setText("");
						cittaDiNascitaTextField.setEditable(true);
					}
				}
			});
			nazionaleComboBox.setFont(new Font("Dialog", Font.BOLD, 13));
		} catch (SQLException e1) {
			JOptionPane.showMessageDialog(null, "Inserisci correttamente i dati!", "errore", JOptionPane.ERROR_MESSAGE);
		}

		nazionaleComboBox.setToolTipText("");
		nazionaleComboBox.setBounds(466, 53, 98, 22);
		contentPane.add(nazionaleComboBox);
		
		String ruoli[] = {"Portiere", "Difensore", "Centrocampista", "Attaccante"};
		ruoloComboBox = new JComboBox(ruoli);
		ruoloComboBox.setFont(new Font("Dialog", Font.BOLD, 13));
		ruoloComboBox.setBounds(466, 143, 98, 24);
		contentPane.add(ruoloComboBox);
		
		ruoloLabel = new JLabel("Ruolo:");
		ruoloLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		ruoloLabel.setBounds(466, 121, 45, 13);
		contentPane.add(ruoloLabel);
		
		sessoMaschioRadioButton = new JRadioButton("M");
		sessoMaschioRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sessoFemminaRadioButton.setSelected(false);
			}
		});
		sessoMaschioRadioButton.setSelected(true);
		sessoMaschioRadioButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		sessoMaschioRadioButton.setBounds(333, 54, 51, 21);
		contentPane.add(sessoMaschioRadioButton);
		
		sessoFemminaRadioButton = new JRadioButton("F");
		sessoFemminaRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sessoMaschioRadioButton.setSelected(false);
			}
		});
		sessoFemminaRadioButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		sessoFemminaRadioButton.setBounds(282, 54, 39, 21);
		contentPane.add(sessoFemminaRadioButton);
		
		sessoLabel = new JLabel("Sesso:");
		sessoLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		sessoLabel.setBounds(282, 30, 45, 13);
		contentPane.add(sessoLabel);
		
		codiceFiscaleTextField = new JTextField();
		codiceFiscaleTextField.setEditable(false);
		codiceFiscaleTextField.setBounds(10, 27, 130, 19);
		contentPane.add(codiceFiscaleTextField);
		codiceFiscaleTextField.setColumns(10);

		codFiscButton = new JButton("Calcola CodFiscale");
		codFiscButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		codFiscButton.setBackground(Color.ORANGE);
		codFiscButton.setFont(new Font("Dialog", Font.BOLD, 13));
		codFiscButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				disattivaComponenti();
				if(sessoMaschioRadioButton.isSelected()) { 
					sesso = "m";
				
				}
				if(sessoFemminaRadioButton.isSelected()) {

					sesso = "f";
					}
				c = new CodiceFiscale();
				try {
					
					codiceFiscale = c.generaCodiceFiscale(nomeTextField.getText().trim(), cognomeTextField.getText().trim(), dataDiNascitaTextField.getText().trim(), sesso,
							cittaDiNascitaTextField.getText());
					codiceFiscaleTextField.setText(codiceFiscale);
					inserisciButton.setEnabled(true);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Inserisci bene i dati!", "errore", JOptionPane.ERROR_MESSAGE);
					attivaComponenti();
				}
				catch(NullPointerException e1) {
					JOptionPane.showMessageDialog(null, "Inserisci bene i dati!", "errore", JOptionPane.ERROR_MESSAGE);
					attivaComponenti();
				}
				catch(StringIndexOutOfBoundsException e2) {
					JOptionPane.showMessageDialog(null, "Inserisci bene i dati!", "errore", JOptionPane.ERROR_MESSAGE);
					attivaComponenti();
				}
			}
		});
		codFiscButton.setBounds(226, 267, 169, 21);
		contentPane.add(codFiscButton);
		
		pulisciButton = new JButton("Pulisci");
		pulisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		pulisciButton.setBackground(Color.ORANGE);
		pulisciButton.setFont(new Font("Dialog", Font.BOLD, 13));
		pulisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				codiceFiscaleTextField.setText("");
				attivaComponenti();
			}
		});
		pulisciButton.setBounds(268, 299, 85, 21);
		contentPane.add(pulisciButton);
		
		codFiscaleLabel = new JLabel("CODICE FISCALE");
		codFiscaleLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		codFiscaleLabel.setBounds(150, 30, 109, 13);
		contentPane.add(codFiscaleLabel);
		
		panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 659, 20);
		contentPane.add(panel);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(640, 17, 19, 371);
		contentPane.add(panel_1);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(0, 368, 649, 20);
		contentPane.add(panel_2);
		image = new ImageIcon("icone\\football-player128.png");
		imageLabel = new JLabel(image);
		imageLabel.setToolTipText("L'Atleta");
		imageLabel.setBounds(268, 104, 128, 128);
		contentPane.add(imageLabel);
		
		lblNewLabel = new JLabel("(yyyy/mm/dd)");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));
		lblNewLabel.setBounds(10, 104, 96, 13);
		contentPane.add(lblNewLabel);
		
		
	}
	
	public void attivaComponenti() {
		
		inserisciButton.setEnabled(false);
		codiceFiscaleTextField.setText("");
		nomeTextField.setEditable(true);
		cognomeTextField.setEditable(true);
		dataDiNascitaTextField.setEditable(true);
		cittaDiNascitaTextField.setEditable(true);
		domicilioTextField.setEditable(true);
		emailTextField.setEditable(true);
		nazionaleComboBox.setEnabled(true);
		ruoloComboBox.setEnabled(true);
		sessoMaschioRadioButton.setEnabled(true);
		sessoFemminaRadioButton.setEnabled(true);
	}
		
	
	
	public void disattivaComponenti() {
		nomeTextField.setEditable(false);
		cognomeTextField.setEditable(false);
		dataDiNascitaTextField.setEditable(false);
		cittaDiNascitaTextField.setEditable(false);
		domicilioTextField.setEditable(false);
		emailTextField.setEditable(false);
		nazionaleComboBox.setEnabled(false);
		ruoloComboBox.setEnabled(false);
		sessoMaschioRadioButton.setEnabled(false);
		sessoFemminaRadioButton.setEnabled(false);
	}
	
	public void pulisciTextField() {
		codiceFiscaleTextField.setText("");
		nomeTextField.setText("");
		cognomeTextField.setText("");
		dataDiNascitaTextField.setText("");
		cittaDiNascitaTextField.setText("");
		domicilioTextField.setText("");
		emailTextField.setText("");
		
	}
}
