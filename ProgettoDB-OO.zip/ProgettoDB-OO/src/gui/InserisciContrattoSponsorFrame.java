package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.Controller;
import daos.ContrattoDAO;
import entity.Atleta;
import entity.Club;
import entity.Contratto;
import entity.Sponsor;
import postegresImpl.ContrattoDAOPostgresImpl;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
public class InserisciContrattoSponsorFrame extends JFrame {

	private JPanel contentPane;
	
	private JTextField inizioContrattoTextField;
	private JTextField fineContrattoTextField;
	private JTextField compensoTextField;
	private JTextField percProcuratoreTextField;
	private JComboBox sponsorComboBox;
	private JLabel inizioContrattoLabel;
	private JLabel fineContrattoLabel;
	private JLabel compensoLabel;
	private JLabel percentualeLabel;
	private JLabel sponsorLabel;
	private JButton inserisciButton;
	private JButton indietroButton;
	private JLabel imageLabel;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private Controller theController;

	/**
	 * Create the frame.
	 */
	public InserisciContrattoSponsorFrame(Controller theController, ArrayList<Sponsor> sponsors, Atleta atleta) {
		this.theController=theController;
		setTitle("Inserisci Contratto Sponsor");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 663, 412);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		inizioContrattoTextField = new JTextField();
		inizioContrattoTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				fineContrattoTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(inizioContrattoTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		inizioContrattoTextField.setBounds(10, 55, 96, 19);
		contentPane.add(inizioContrattoTextField);
		inizioContrattoTextField.setColumns(10) ;
		
		fineContrattoTextField = new JTextField();
		fineContrattoTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				compensoTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(fineContrattoTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		fineContrattoTextField.setEditable(false);
		fineContrattoTextField.setBounds(10, 106, 96, 19);
		contentPane.add(fineContrattoTextField);
		fineContrattoTextField.setColumns(10);
		
		compensoTextField = new JTextField();
		compensoTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				percProcuratoreTextField.setEditable(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(compensoTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		compensoTextField.setEditable(false);
		compensoTextField.setBounds(10, 161, 96, 19);
		contentPane.add(compensoTextField);
		compensoTextField.setColumns(10);
		
		percProcuratoreTextField = new JTextField();
		percProcuratoreTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				inserisciButton.setEnabled(true);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				if(percProcuratoreTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		percProcuratoreTextField.setEditable(false);
		percProcuratoreTextField.setBounds(10, 211, 96, 19);
		contentPane.add(percProcuratoreTextField);
		percProcuratoreTextField.setColumns(10);
		
		ArrayList<String> nomiSponsor = new ArrayList<String>();
		for(Sponsor sponsor: sponsors) {
			nomiSponsor.add(sponsor.getNome());
		}
		
		sponsorComboBox = new JComboBox(nomiSponsor.toArray());
		sponsorComboBox.setBounds(423, 78, 86, 21);
		contentPane.add(sponsorComboBox);
		
		inizioContrattoLabel = new JLabel("INIZIO CONTRATTO");
		inizioContrattoLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		inizioContrattoLabel.setBounds(116, 57, 131, 13);
		contentPane.add(inizioContrattoLabel);
		
		fineContrattoLabel = new JLabel("FINE CONTRATTO");
		fineContrattoLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		fineContrattoLabel.setBounds(116, 108, 116, 13);
		contentPane.add(fineContrattoLabel);
		
		compensoLabel = new JLabel("COMPENSO");
		compensoLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		compensoLabel.setBounds(116, 163, 86, 13);
		contentPane.add(compensoLabel);
		
		percentualeLabel = new JLabel("PERCENTUALE PROCURATORE");
		percentualeLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		percentualeLabel.setBounds(116, 213, 179, 13);
		contentPane.add(percentualeLabel);
		
		sponsorLabel = new JLabel("Sponsor:");
		sponsorLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		sponsorLabel.setBounds(423, 57, 67, 13);
		contentPane.add(sponsorLabel);
		
		inserisciButton = new JButton("Inserisci");
		inserisciButton.setEnabled(false);
		inserisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inserisciButton.setToolTipText("Il contratto con lo sponsor");
		inserisciButton.setBackground(Color.ORANGE);
		inserisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					ContrattoDAO inserisciContrattoSponsor = new ContrattoDAOPostgresImpl(theController.controllerGetConnection());
					Contratto newSponsorContratto = new Contratto();
					Date inizioContratto, fineContratto = new Date();
					try {
						inizioContratto = new SimpleDateFormat("yyyy/MM/dd").parse(inizioContrattoTextField.getText().trim());
						fineContratto = new SimpleDateFormat("yyyy/MM/dd").parse(fineContrattoTextField.getText().trim());
						
						if(newSponsorContratto.setContrattoSponsor(inizioContratto, fineContratto, Double.parseDouble(compensoTextField.getText().trim()),  Double.parseDouble(percProcuratoreTextField.getText()), atleta, getSponsorFromSponsorName(sponsorComboBox.getSelectedItem().toString(), sponsors)))
						{
							inserisciContrattoSponsor.insertContrattoSponsor(newSponsorContratto);
							inserisciContrattoSponsor.updateAtletaProcuratore(newSponsorContratto);
							JOptionPane.showMessageDialog(null, "Inserimento avvenuto con successo!");
							pulisciCaselle();
						}
					} catch (ParseException e1) {
						JOptionPane.showMessageDialog(null, "Inserimento errato", "errore", JOptionPane.ERROR_MESSAGE);

					}
					
				
				} catch (SQLException e) {
					
					JOptionPane.showMessageDialog(null, "Ricorda che il contratto non pu� iniziare dopo oggi e deve essere di almeno un anno!", "errore", JOptionPane.ERROR_MESSAGE);

				}
				
				
			}
		});
		inserisciButton.setFont(new Font("Dialog", Font.BOLD, 13));
		inserisciButton.setBounds(491, 329, 108, 31);
		contentPane.add(inserisciButton);
		
		indietroButton = new JButton("Indietro");
		indietroButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		indietroButton.setToolTipText("Il contratto con lo sponsor");
		indietroButton.setFont(new Font("Dialog", Font.BOLD, 13));
		indietroButton.setBackground(Color.ORANGE);
		indietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				theController.toFrameProcuratore(InserisciContrattoSponsorFrame.this, null, null);
			}
		});
		indietroButton.setBounds(21, 331, 105, 27);
		contentPane.add(indietroButton);
		
		ImageIcon image = new ImageIcon("icone\\tshirt128.png");
		imageLabel = new JLabel(image);	
		imageLabel.setBounds(402, 146, 128, 128);
		contentPane.add(imageLabel);
		
		panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 659, 20);
		contentPane.add(panel);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(630, 10, 29, 378);
		contentPane.add(panel_1);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(0, 370, 633, 18);
		contentPane.add(panel_2);
		
		lblNewLabel = new JLabel("(yyyy/mm/dd)");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));
		lblNewLabel.setBounds(10, 40, 96, 13);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("(yyyy/mm/dd)");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));
		lblNewLabel_1.setBounds(10, 86, 96, 13);
		contentPane.add(lblNewLabel_1);
		
		
	}
	
	public Sponsor getSponsorFromSponsorName (String sponsorName, ArrayList<Sponsor> sponsors){  
		for(Sponsor sponsor : sponsors) { 
			if(sponsor.getNome().equals(sponsorName))
		       return sponsor;
		}
		return null;
	}
	
	public void pulisciCaselle() {
		
		inizioContrattoTextField.setText("");
		fineContrattoTextField.setText("");
		compensoTextField.setText("");
		percProcuratoreTextField.setText("");
	}
}
