package gui;



import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.Controller;
import daos.NazionaleDAO;
import daos.SponsorDAO;
import entity.Sponsor;
import postegresImpl.NazionaleDAOPostgresImpl;
import postegresImpl.SponsorDAOPostgresImpl;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;

public class InserisciSponsorFrame extends JFrame {

	private JPanel contentPane;
	private JTextField nomeTextField;
	private JButton inserisciButton;
	private JLabel nomeLabel;
	private JButton indietroButton;
	private ImageIcon image;

	private JComboBox NazionaleComboBox;
	private JLabel lblNewLabel;
	private JLabel imageLabel;
	private Controller theController;
	
	/**
	 * Create the frame.
	 */
	public InserisciSponsorFrame(Controller theController, NazionaleDAO getNomiNazioni) {
		this.theController=theController;
		setResizable(false);
		try {
			getNomiNazioni = new NazionaleDAOPostgresImpl(theController.controllerGetConnection());

			
		} catch (SQLException e2) {
			
			e2.printStackTrace();
		}
		
		setTitle("Inserimento Sponsor");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 542, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		nomeTextField = new JTextField();
		nomeTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				inserisciButton.setEnabled(true);

			}

			@Override
			public void keyReleased(KeyEvent e) {
				if(nomeTextField.getText().isEmpty()) inserisciButton.setEnabled(false);
			}
		});
		nomeTextField.setBounds(20, 42, 120, 23);
		contentPane.add(nomeTextField);
		nomeTextField.setColumns(10);
		
		inserisciButton = new JButton("Inserisci");
		inserisciButton.setEnabled(false);
		inserisciButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inserisciButton.setBackground(Color.ORANGE);
		inserisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nome = nomeTextField.getText();
				Sponsor nuovoSponsor = new Sponsor();
				String nazionale= NazionaleComboBox.getSelectedItem().toString();
				if(nuovoSponsor.setSponsor(nome,nazionale)) {
					try {
						SponsorDAO inserimento = new SponsorDAOPostgresImpl(theController.controllerGetConnection());
						inserimento.inserisciSponsor(nuovoSponsor);
						JOptionPane.showMessageDialog(null, "Inserimento avvenuto con successo!");
					} catch (SQLException e) {
						JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

						e.printStackTrace();
					} catch (ParseException e) {
						JOptionPane.showMessageDialog(null, "Controlla i dati inseriti!", "Errore", JOptionPane.ERROR_MESSAGE);

					}
					
				}
				else JOptionPane.showMessageDialog(null, "Inserimento errato, rivedere i valori");
			}
		});
		inserisciButton.setFont(new Font("Dialog", Font.BOLD, 13));
		inserisciButton.setBounds(382, 231, 129, 38);
		contentPane.add(inserisciButton);
		
		nomeLabel = new JLabel("NOME ");
		nomeLabel.setFont(new Font("Microsoft Tai Le", Font.ITALIC, 13));
		nomeLabel.setBounds(150, 42, 86, 23);
		contentPane.add(nomeLabel);
		
		indietroButton = new JButton("Indietro");
		indietroButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		indietroButton.setFont(new Font("Dialog", Font.BOLD, 13));
		indietroButton.setBackground(Color.ORANGE);
		indietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theController.toFrameSponsor(InserisciSponsorFrame.this, null, null);
			}
		});
		indietroButton.setBounds(10, 231, 108, 38);
		contentPane.add(indietroButton);
		
		
		try {
			NazionaleComboBox = new JComboBox(getNomiNazioni.getNomeNazionaleString().toArray());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
		}
		NazionaleComboBox.setToolTipText("");
		NazionaleComboBox.setBounds(382, 65, 98, 22);
		contentPane.add(NazionaleComboBox);
		
		lblNewLabel = new JLabel("Nazione:");
		lblNewLabel.setFont(new Font("Tahoma", Font.ITALIC, 13));
		lblNewLabel.setBounds(382, 42, 86, 13);
		contentPane.add(lblNewLabel);
		
		image = new ImageIcon("icone\\tshirt128.png");
		imageLabel = new JLabel(image);	
		imageLabel.setToolTipText("Lo sponsor");
		imageLabel.setBounds(205, 94, 128, 128);
		contentPane.add(imageLabel);
		
	}
	
	public void pulisciCaselle() {
		nomeTextField.setText("");
	}
}
